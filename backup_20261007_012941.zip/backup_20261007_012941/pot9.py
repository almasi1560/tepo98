#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MIHOMO INDUSTRIAL ENGINE ULTIMATE V6
============================
Final industrial Termux converter for Mihomo / Clash Meta.

Design principles
-----------------
- Exactly ONE static proxy group: Select🔰 (type: select)
- NO URL-Test / fallback / load-balance / Smart / auto-switch
- Lightweight reachability: DNS -> TCP only; never downloads traffic
- Batch processing + adaptive workers
- DNS cache + TCP result cache with TTL
- Stable fingerprint-based deduplication
- Preserve protocol/security/transport parameters whenever possible
- Base64 subscription intelligence
- JSON / VMess / VLESS / Trojan / SS / SSR / Hysteria / Hysteria2 /
  TUIC / HTTP / SOCKS / WireGuard-ish JSON inputs
- Final YAML structural validation
- No report files are written to disk; only the final YAML is saved
- Atomic output writes
- Input file is cleared after a successful run
- Designed for large inputs (2k-5k+ nodes)

Reference architecture incorporated from the supplied test.txt:
DNS split concepts, proxy-server-nameserver, geodata, geox-url,
sniffer/TUN as optional settings, rule-provider architecture,
LAN protection, GEOIP/GEOSITE routing ideas and robust provider paths.
Those reference settings are deliberately kept conservative here:
TUN is disabled, no auto-selection group is emitted, and the user's
one-group architecture remains authoritative.
"""

from __future__ import annotations

import base64
import concurrent.futures
import hashlib
import ipaddress
import json
import os
import re
import socket
import ssl
import sys
import shutil
import subprocess
import tempfile
import copy
import threading
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

# ----------------------------- CONSTANTS -----------------------------

ENGINE_VERSION = "INDUSTRIAL-ULTIMATE-V6"
GROUP_NAME = "Select🔰"
BASE_DIR = Path("/storage/emulated/0/Download/Akbar98")
INPUT_PATH = BASE_DIR / "input_mobile.txt"
DEFAULT_OUTPUT_DIR = BASE_DIR

DNS_TIMEOUT = 2.5
TCP_TIMEOUT = 2.8
DNS_CACHE_TTL = 300
TCP_CACHE_TTL = 600
MAX_WORKERS_CAP = 32
BATCH_SIZE = 100
MAX_INPUT_BYTES = 25 * 1024 * 1024
MAX_SUBSCRIPTION_BYTES = 8 * 1024 * 1024
MAX_DNS_ADDRESSES = 16

PROTOCOLS = {
    "vless", "vmess", "trojan", "ss", "ssr", "hysteria",
    "hysteria2", "hy2", "tuic", "http", "socks5", "socks",
    "wireguard", "anytls"
}

# Conservative, widely useful defaults inspired by the helper config.
CORE_DEFAULTS = {
    "mixed-port": 7890,
    "allow-lan": False,
    "mode": "rule",
    "log-level": "info",
    "ipv6": True,
    "unified-delay": True,
    "tcp-concurrent": True,
    "find-process-mode": "strict",
    "keep-alive-interval": 1800,
    "profile": {
        "store-selected": True,
        "store-fake-ip": True,
    },
    "geodata-mode": True,
    "geox-url": {
        "geoip": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.dat",
        "geosite": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite.dat",
        "mmdb": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/country.mmdb",
    },
    "sniffer": {
        "enable": False,
        "override-destination": False,
    },
    "tun": {
        "enable": False,
        "stack": "system",
        "auto-route": True,
        "auto-detect-interface": True,
    },
    "dns": {
        "enable": True,
        "ipv6": True,
        "enhanced-mode": "fake-ip",
        "fake-ip-range": "198.18.0.1/16",
        "default-nameserver": ["223.5.5.5", "1.1.1.1"],
        "nameserver": [
            "https://dns.alidns.com/dns-query",
            "https://cloudflare-dns.com/dns-query",
        ],
        "proxy-server-nameserver": [
            "https://dns.alidns.com/dns-query",
            "https://cloudflare-dns.com/dns-query",
        ],
        "nameserver-policy": {
            "geosite:cn,private": [
                "https://dns.alidns.com/dns-query",
                "https://doh.pub/dns-query",
            ],
            "geosite:!cn,!private": [
                "https://cloudflare-dns.com/dns-query",
                "https://dns.google/dns-query",
            ],
        },
    },
}

# ----------------------------- DATA TYPES ----------------------------

@dataclass
class Proxy:
    type: str
    name: str
    server: str
    port: int
    data: dict[str, Any] = field(default_factory=dict)
    source: str = ""
    raw: str = ""
    fingerprint: str = ""
    status: str = "unknown"
    addresses: list[str] = field(default_factory=list)
    latency_ms: float | None = None
    error: str = ""
    score: float = 0.0

@dataclass
class TestResult:
    host: str
    port: int
    dns_ok: bool
    addresses: list[str]
    tcp_ok: bool
    latency_ms: float | None
    error: str = ""

# ----------------------------- UTILITIES -----------------------------

_print_lock = threading.Lock()

def log(msg: str = "") -> None:
    with _print_lock:
        print(msg, flush=True)

def normalize_b64(s: str) -> str | None:
    s = re.sub(r"\s+", "", s.strip())
    if not s:
        return None
    s += "=" * ((4 - len(s) % 4) % 4)
    try:
        return base64.b64decode(s, validate=False).decode("utf-8", "ignore")
    except Exception:
        return None

def safe_int(v: Any, default: int = 0) -> int:
    try:
        return int(str(v).strip())
    except Exception:
        return default

def clean_name(name: str, fallback: str = "Node") -> str:
    name = str(name or "").replace("\n", " ").replace("\r", " ").strip()
    name = re.sub(r"[\x00-\x1f\x7f]", "", name)
    return name[:120] or fallback

def host_is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host.strip("[]"))
        return True
    except Exception:
        return False

def host_port(server: str, port: int) -> str:
    if ":" in server and not server.startswith("["):
        return f"[{server}]:{port}"
    return f"{server}:{port}"

def url_unquote(v: Any) -> str:
    return urllib.parse.unquote(str(v)) if v is not None else ""

def b64_text(v: str) -> str:
    raw = normalize_b64(v)
    return raw if raw is not None else v

def canonical_value(v: Any) -> str:
    if isinstance(v, dict):
        return "{" + ",".join(f"{k}:{canonical_value(v[k])}" for k in sorted(v)) + "}"
    if isinstance(v, (list, tuple)):
        return "[" + ",".join(canonical_value(x) for x in v) + "]"
    return str(v).strip()

def fingerprint_proxy(p: Proxy) -> str:
    # Credentials and security parameters are intentionally included.
    keys = sorted(k for k in p.data if k not in {"name", "remark"})
    body = "|".join([
        p.type.lower(),
        p.server.lower().strip("[]"),
        str(p.port),
        *[f"{k}={canonical_value(p.data[k])}" for k in keys],
    ])
    return hashlib.sha256(body.encode("utf-8", "ignore")).hexdigest()

def score_proxy(p: Proxy) -> float:
    # DNS 10 + TCP 30 + latency 30 + protocol 20 + config 10.
    dns = 10 if p.addresses else 0
    tcp = 30 if p.status == "alive" else 0
    latency = 0
    if p.latency_ms is not None:
        latency = max(0.0, min(30.0, 30.0 * (1.0 - min(p.latency_ms, 1000.0) / 1000.0)))
    protocol = 20 if p.type.lower() in PROTOCOLS else 0
    config = 10 if p.server and p.port > 0 and p.port <= 65535 else 0
    return round(dns + tcp + latency + protocol + config, 2)

# ----------------------------- YAML WRITER ----------------------------

def yaml_quote(v: Any) -> str:
    """Return a YAML-safe scalar representation."""
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int) and not isinstance(v, bool):
        return str(v)
    if isinstance(v, float):
        if math.isfinite(v):
            return repr(v)
        return json.dumps(str(v), ensure_ascii=False)
    return json.dumps(str(v), ensure_ascii=False)


def yaml_dump(obj: Any, indent: int = 0) -> str:
    """Serialize the supported config tree as conservative block YAML.

    Only mappings, sequences and scalar values are emitted. Every string is
    double-quoted with JSON escaping, which is also valid YAML escaping. This
    avoids ambiguous YAML tokens such as ':', '#', '[', ']', '&', '*', '?',
    Unicode emoji, IPv6 literals and proxy URLs.
    """
    if indent < 0:
        raise ValueError("indent must be non-negative")

    def emit(value: Any, level: int) -> list[str]:
        pad = " " * (level * 2)
        if isinstance(value, dict):
            if not value:
                return [pad + "{}"]
            lines: list[str] = []
            for key, val in value.items():
                k = yaml_quote(key)
                if isinstance(val, (dict, list, tuple)):
                    if isinstance(val, (list, tuple)) and len(val) == 0:
                        lines.append(f"{pad}{k}: []")
                    elif isinstance(val, dict) and len(val) == 0:
                        lines.append(f"{pad}{k}: {{}}")
                    else:
                        lines.append(f"{pad}{k}:")
                        lines.extend(emit(val, level + 1))
                else:
                    lines.append(f"{pad}{k}: {yaml_quote(val)}")
            return lines
        if isinstance(value, (list, tuple)):
            if not value:
                return [pad + "[]"]
            lines: list[str] = []
            for val in value:
                if isinstance(val, (dict, list, tuple)):
                    if isinstance(val, (list, tuple)) and len(val) == 0:
                        lines.append(f"{pad}- []")
                    elif isinstance(val, dict) and len(val) == 0:
                        lines.append(f"{pad}- {{}}")
                    else:
                        lines.append(f"{pad}-")
                        lines.extend(emit(val, level + 1))
                else:
                    lines.append(f"{pad}- {yaml_quote(val)}")
            return lines
        return [pad + yaml_quote(value)]

    return "\n".join(emit(obj, indent))


def validate_serialized_yaml(text: str) -> None:
    """Validate the exact serialized document before it reaches FlClash."""
    if not text.strip():
        raise RuntimeError("Generated YAML is empty")

    body = text
    if body.startswith("# Generated by MIHOMO INDUSTRIAL ENGINE"):
        parts = body.split("\n", 1)
        body = parts[1] if len(parts) == 2 else ""

    parsed: Any
    try:
        import yaml  # Optional dependency on Termux; normally present only when installed.
        parsed = yaml.safe_load(body)
    except ImportError:
        # If PyYAML is unavailable, the actual Mihomo validator below remains
        # authoritative when the mihomo binary is installed. Structural checks
        # on the in-memory cfg are still performed before serialization.
        parsed = None
    except Exception as exc:
        mark = getattr(exc, "problem_mark", None)
        if mark is not None:
            raise RuntimeError(
                f"Generated YAML validation failed at line {mark.line + 1}, "
                f"column {mark.column + 1}: {getattr(exc, 'problem', str(exc))}"
            ) from exc
        raise RuntimeError(f"Generated YAML validation failed: {exc}") from exc

    if parsed is not None:
        if not isinstance(parsed, dict):
            raise RuntimeError("Generated YAML root must be a mapping/object")
        if "global-client-fingerprint" in parsed:
            raise RuntimeError("Deprecated global-client-fingerprint must not be emitted")
        structural = validate_config(parsed)
        if structural:
            raise RuntimeError("SERIALIZED CONFIG VALIDATION FAILED: " + "; ".join(structural))

# ----------------------------- PARSERS -------------------------------

def parse_query(u: urllib.parse.ParseResult) -> dict[str, Any]:
    q = urllib.parse.parse_qs(u.query, keep_blank_values=True)
    return {k: (v[-1] if v else "") for k, v in q.items()}

def common_tls_fields(q: dict[str, Any], d: dict[str, Any]) -> None:
    if q.get("security"):
        d["tls"] = q["security"] not in {"none", "false", "0"}
    if q.get("sni"):
        d["servername"] = q["sni"]
    elif q.get("peer"):
        d["servername"] = q["peer"]
    if q.get("alpn"):
        d["alpn"] = q["alpn"].split(",")
    if q.get("fp"):
        d["client-fingerprint"] = q["fp"]
    if q.get("fingerprint"):
        d["client-fingerprint"] = q["fingerprint"]

def parse_vless(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d: dict[str, Any] = {"uuid": urllib.parse.unquote(u.username or "")}
    common_tls_fields(q, d)
    network = q.get("type") or q.get("network") or "tcp"
    d["network"] = network
    if q.get("flow"):
        d["flow"] = q["flow"]
    if q.get("encryption"):
        d["encryption"] = q["encryption"]
    if q.get("security") == "reality":
        d["reality-opts"] = {}
        if q.get("pbk"):
            d["reality-opts"]["public-key"] = q["pbk"]
        if q.get("sid"):
            d["reality-opts"]["short-id"] = q["sid"]
    if network in {"ws", "http"}:
        ws = {}
        if q.get("path"):
            ws["path"] = q["path"]
        if q.get("host"):
            ws["headers"] = {"Host": q["host"]}
        if ws:
            d["ws-opts"] = ws
    if network == "grpc":
        go = {}
        if q.get("serviceName"):
            go["grpc-service-name"] = q["serviceName"]
        if go:
            d["grpc-opts"] = go
    name = clean_name(q.get("remarks") or u.fragment or "VLESS")
    return Proxy("vless", name, u.hostname, u.port, d, raw=line)

def parse_trojan(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d = {"password": urllib.parse.unquote(u.username or "")}
    d["tls"] = True
    common_tls_fields(q, d)
    if q.get("type"):
        d["network"] = q["type"]
    if q.get("path"):
        d["ws-opts"] = {"path": q["path"]}
        if q.get("host"):
            d["ws-opts"]["headers"] = {"Host": q["host"]}
    return Proxy("trojan", clean_name(q.get("remarks") or u.fragment or "Trojan"),
                 u.hostname, u.port, d, raw=line)

def parse_ss(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    userinfo = u.username or ""
    password_part = u.password or ""
    method = ""
    password = ""
    if userinfo and password_part:
        method, password = userinfo, password_part
    elif userinfo:
        decoded = normalize_b64(userinfo)
        if decoded and ":" in decoded:
            method, password = decoded.split(":", 1)
        elif ":" in userinfo:
            method, password = userinfo.split(":", 1)
    d = {"cipher": url_unquote(method), "password": url_unquote(password)}
    q = parse_query(u)
    if q.get("udp"):
        d["udp"] = str(q["udp"]).lower() in {"1", "true", "yes"}
    if q.get("plugin"):
        # Keep plugin data in the form understood by Mihomo when possible.
        plugin = q["plugin"]
        parts = plugin.split(";")
        d["plugin"] = parts[0]
        opts = {}
        for part in parts[1:]:
            if "=" in part:
                k, v = part.split("=", 1)
                opts[k] = v
        if opts:
            d["plugin-opts"] = opts
    return Proxy("ss", clean_name(u.fragment or "SS"), u.hostname, u.port, d, raw=line)

def parse_hysteria(line: str, proto: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d: dict[str, Any] = {}
    user = urllib.parse.unquote(u.username or "")
    if proto == "hysteria2":
        if user:
            d["password"] = user
        if q.get("obfs"):
            d["obfs"] = q["obfs"]
        if q.get("obfs-password"):
            d["obfs-password"] = q["obfs-password"]
    else:
        if user:
            d["auth-str"] = user
        if q.get("protocol"):
            d["protocol"] = q["protocol"]
        if q.get("up"):
            d["up"] = q["up"]
        if q.get("down"):
            d["down"] = q["down"]
    if q.get("sni"):
        d["sni"] = q["sni"]
    if q.get("alpn"):
        d["alpn"] = q["alpn"].split(",")
    if q.get("skip-cert-verify") is not None and q.get("skip-cert-verify") != "":
        d["skip-cert-verify"] = str(q["skip-cert-verify"]).lower() in {"1", "true", "yes"}
    if q.get("insecure") is not None and q.get("insecure") != "":
        d["skip-cert-verify"] = str(q["insecure"]).lower() in {"1", "true", "yes"}
    if q.get("fingerprint"):
        d["fingerprint"] = q["fingerprint"]
    if q.get("name-cert-verify"):
        d["name-cert-verify"] = q["name-cert-verify"]
    if q.get("ports"):
        d["ports"] = q["ports"]
    if q.get("hop-interval"):
        d["hop-interval"] = safe_int(q["hop-interval"], 0)
    return Proxy(proto, clean_name(q.get("remarks") or u.fragment or proto.upper()),
                 u.hostname, u.port, d, raw=line)

def parse_tuic(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d = {
        "uuid": urllib.parse.unquote(u.username or ""),
        "password": urllib.parse.unquote(u.password or ""),
    }
    for k in ("congestion-controller", "udp-relay-mode", "sni"):
        if q.get(k):
            d[k] = q[k]
    if q.get("disable-sni") is not None and q.get("disable-sni") != "":
        d["disable-sni"] = str(q["disable-sni"]).lower() in {"1", "true", "yes"}
    if q.get("reduce-rtt") is not None and q.get("reduce-rtt") != "":
        d["reduce-rtt"] = str(q["reduce-rtt"]).lower() in {"1", "true", "yes"}
    if q.get("skip-cert-verify") is not None and q.get("skip-cert-verify") != "":
        d["skip-cert-verify"] = str(q["skip-cert-verify"]).lower() in {"1", "true", "yes"}
    return Proxy("tuic", clean_name(q.get("name") or u.fragment or "TUIC"),
                 u.hostname, u.port, d, raw=line)

def parse_http_socks(line: str, proto: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    d = {}
    if u.username:
        d["username"] = urllib.parse.unquote(u.username)
    if u.password:
        d["password"] = urllib.parse.unquote(u.password)
    if q := parse_query(u):
        for k in ("tls", "udp"):
            if k in q:
                d[k] = str(q[k]).lower() in {"1", "true", "yes"}
    return Proxy(proto, clean_name(u.fragment or proto.upper()), u.hostname, u.port, d, raw=line)

def parse_vmess(line: str) -> Proxy | None:
    payload = line.split("://", 1)[1].split("#", 1)[0]
    raw = normalize_b64(payload)
    if not raw:
        return None
    try:
        j = json.loads(raw)
    except Exception:
        return None
    host = j.get("add") or j.get("address")
    port = safe_int(j.get("port"))
    if not host or not port:
        return None
    d: dict[str, Any] = {
        "uuid": j.get("id", ""),
        "alterId": safe_int(j.get("aid"), 0),
        "cipher": j.get("scy") or j.get("cipher") or "auto",
    }
    net = j.get("net") or "tcp"
    d["network"] = net
    if j.get("tls"):
        d["tls"] = True
    if j.get("sni"):
        d["servername"] = j["sni"]
    if j.get("fp"):
        d["client-fingerprint"] = j["fp"]
    if j.get("scy") and str(j.get("scy")).lower() not in {"auto", "none"}:
        d["cipher"] = j.get("scy")
    if j.get("aid") is not None:
        d["alterId"] = safe_int(j.get("aid"), 0)
    if j.get("alpn"):
        d["alpn"] = j["alpn"].split(",") if isinstance(j["alpn"], str) else j["alpn"]
    if net == "ws":
        ws = {}
        if j.get("path"):
            ws["path"] = j["path"]
        if j.get("host"):
            ws["headers"] = {"Host": j["host"]}
        if ws:
            d["ws-opts"] = ws
    name = clean_name(j.get("ps") or "VMess")
    return Proxy("vmess", name, str(host), port, d, raw=line)

def parse_json_proxy(obj: dict[str, Any], source: str = "") -> Proxy | None:
    ptype = str(obj.get("type") or "").lower()
    if ptype not in PROTOCOLS:
        return None
    host = obj.get("server") or obj.get("address") or obj.get("add")
    port = safe_int(obj.get("port"))
    if not host or not port:
        return None
    name = clean_name(obj.get("name") or obj.get("remarks") or ptype.upper())
    d = {k: v for k, v in obj.items() if k not in {"type", "name", "server", "address", "add", "port", "remarks"}}
    return Proxy(ptype, name, str(host), port, d, source=source, raw=json.dumps(obj, ensure_ascii=False))

def parse_ssr(line: str) -> Proxy | None:
    payload = line.split("://", 1)[1]
    raw = normalize_b64(payload)
    if not raw:
        return None
    # SSR: server:port:protocol:method:obfs:password-base64/?params
    main, _, query = raw.partition("/?")
    parts = main.split(":")
    if len(parts) < 6:
        return None
    host, port, protocol, method, obfs, pwb64 = parts[:6]
    password = normalize_b64(pwb64) or pwb64
    q = urllib.parse.parse_qs(query, keep_blank_values=True)
    name = normalize_b64(q.get("remarks", [""])[-1]) or "SSR"
    d = {"protocol": protocol, "cipher": method, "obfs": obfs, "password": password}
    return Proxy("ssr", clean_name(name), host, safe_int(port), d, raw=line)


def parse_anytls(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d: dict[str, Any] = {"password": urllib.parse.unquote(u.username or "")}
    if q.get("sni"):
        d["servername"] = q["sni"]
    if q.get("skip-cert-verify") is not None:
        d["skip-cert-verify"] = str(q["skip-cert-verify"]).lower() in {"1", "true", "yes"}
    if q.get("alpn"):
        d["alpn"] = q["alpn"].split(",")
    if q.get("fingerprint"):
        d["fingerprint"] = q["fingerprint"]
    return Proxy("anytls", clean_name(q.get("remarks") or u.fragment or "AnyTLS"),
                 u.hostname, u.port, d, raw=line)

def parse_line(line: str, source: str = "") -> Proxy | None:
    line = line.strip().lstrip("\ufeff")
    if not line or line.startswith("#") or line.startswith("//"):
        return None

    low = line.lower()
    try:
        if low.startswith("vmess://"):
            p = parse_vmess(line)
        elif low.startswith("vless://"):
            p = parse_vless(line)
        elif low.startswith("trojan://"):
            p = parse_trojan(line)
        elif low.startswith("ss://"):
            p = parse_ss(line)
        elif low.startswith("ssr://"):
            p = parse_ssr(line)
        elif low.startswith("hysteria2://") or low.startswith("hy2://"):
            p = parse_hysteria(line, "hysteria2")
        elif low.startswith("hysteria://"):
            p = parse_hysteria(line, "hysteria")
        elif low.startswith("tuic://"):
            p = parse_tuic(line)
        elif low.startswith("anytls://"):
            p = parse_anytls(line)
        elif low.startswith("socks5://") or low.startswith("socks://"):
            p = parse_http_socks(line, "socks5")
        elif low.startswith("http://") or low.startswith("https://"):
            # http(s):// may be a proxy URI or a subscription URL.
            p = parse_http_socks(line, "http")
        elif low.startswith("{") and low.endswith("}"):
            p = parse_json_proxy(json.loads(line), source)
        else:
            return None
        if p:
            p.source = source
            p.fingerprint = fingerprint_proxy(p)
        return p
    except Exception:
        return None

def extract_json_objects(text: str) -> list[dict[str, Any]]:
    found = []
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            found.append(obj)
        elif isinstance(obj, list):
            found.extend(x for x in obj if isinstance(x, dict))
        return found
    except Exception:
        pass
    for m in re.finditer(r'\{(?:[^{}]|"(?:\\.|[^"])*")*\}', text, re.S):
        try:
            x = json.loads(m.group(0))
            if isinstance(x, dict):
                found.append(x)
        except Exception:
            continue
    return found

def expand_input(text: str) -> list[str]:
    lines = [x.strip() for x in text.splitlines() if x.strip()]
    out: list[str] = []
    for line in lines:
        if re.match(r"^(vmess|vless|trojan|ss|ssr|hysteria|hysteria2|hy2|tuic|anytls|socks5|socks|http)://", line, re.I):
            out.append(line)
            continue
        if line.startswith("{") or line.startswith("["):
            out.append(line)
            continue
        dec = normalize_b64(line)
        if dec and any(x in dec.lower() for x in ("vmess://", "vless://", "trojan://", "ss://", "ssr://", "hysteria", "tuic://", "anytls://")):
            out.extend(x.strip() for x in dec.splitlines() if x.strip())
        else:
            out.append(line)
    return out

# ----------------------------- CACHE ---------------------------------

class TTLCache:
    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.Lock()
        self.data: dict[str, Any] = {}
        self.load()

    def load(self):
        try:
            if self.path.exists():
                self.data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            self.data = {}

    def get(self, key: str, ttl: int) -> Any:
        with self.lock:
            x = self.data.get(key)
            if not x:
                return None
            if time.time() - float(x.get("time", 0)) > ttl:
                return None
            return x.get("value")

    def put(self, key: str, value: Any):
        with self.lock:
            self.data[key] = {"time": time.time(), "value": value}

    def save(self):
        with self.lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)

# ----------------------------- REACHABILITY --------------------------

def resolve_host(host: str, dns_cache: TTLCache) -> list[str]:
    if host_is_ip(host):
        return [host.strip("[]")]
    key = host.lower().rstrip(".")
    cached = dns_cache.get(key, DNS_CACHE_TTL)
    if cached:
        return cached[:MAX_DNS_ADDRESSES]
    try:
        infos = socket.getaddrinfo(host, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        seen = set()
        addrs = []
        for info in infos:
            addr = info[4][0]
            if addr not in seen:
                seen.add(addr)
                addrs.append(addr)
        addrs = addrs[:MAX_DNS_ADDRESSES]
        if addrs:
            dns_cache.put(key, addrs)
        return addrs
    except Exception:
        return []

def tcp_probe(addr: str, port: int) -> tuple[bool, float | None, str]:
    family = socket.AF_INET6 if ":" in addr else socket.AF_INET
    started = time.perf_counter()
    s = socket.socket(family, socket.SOCK_STREAM)
    s.settimeout(TCP_TIMEOUT)
    try:
        s.connect((addr, port))
        return True, round((time.perf_counter() - started) * 1000, 1), ""
    except Exception as e:
        return False, None, str(e)
    finally:
        try:
            s.close()
        except Exception:
            pass

def infer_ip_version(addresses: list[str]) -> str | None:
    if not addresses:
        return None
    v4 = any("." in a for a in addresses)
    v6 = any(":" in a for a in addresses)
    if v4 and not v6:
        return "ipv4"
    if v6 and not v4:
        return "ipv6"
    return "dual"

def test_proxy(p: Proxy, dns_cache: TTLCache, tcp_cache: TTLCache) -> TestResult:
    addresses = resolve_host(p.server, dns_cache)
    if not addresses:
        return TestResult(p.server, p.port, False, [], False, None, "DNS failed")
    key = f"{p.server.lower()}:{p.port}|" + ",".join(sorted(addresses))
    cached = tcp_cache.get(key, TCP_CACHE_TTL)
    if cached and cached.get("ok"):
        return TestResult(p.server, p.port, True, addresses, True, cached.get("latency_ms"), "cache")

    best: float | None = None
    errors: list[str] = []
    max_addr_workers = min(4, len(addresses))
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_addr_workers) as ex:
        futures = [ex.submit(tcp_probe, addr, p.port) for addr in addresses]
        for fut in concurrent.futures.as_completed(futures):
            ok, latency, err = fut.result()
            if ok and (best is None or (latency or 999999) < best):
                best = latency
            elif err:
                errors.append(err)
    ok = best is not None
    tcp_cache.put(key, {"ok": ok, "latency_ms": best})
    return TestResult(p.server, p.port, True, addresses, ok, best, "" if ok else (errors[0] if errors else "TCP failed"))

def available_memory_mb() -> int:
    try:
        meminfo = Path("/proc/meminfo").read_text(encoding="utf-8", errors="ignore")
        m = re.search(r"^MemAvailable:\s+(\d+)\s+kB", meminfo, re.M)
        if m:
            return int(m.group(1)) // 1024
    except Exception:
        pass
    return 0

def resource_worker_cap() -> int:
    cpu = os.cpu_count() or 4
    mem = available_memory_mb()
    cap = min(MAX_WORKERS_CAP, max(4, cpu * 2))
    if mem and mem < 1024:
        cap = min(cap, 8)
    elif mem and mem < 2048:
        cap = min(cap, 16)
    return max(4, cap)

def mihomo_binary() -> str | None:
    candidates = [
        os.environ.get("MIHOMO_BIN", ""),
        shutil.which("mihomo") or "",
        shutil.which("mihomo-linux-arm64") or "",
        shutil.which("mihomo-linux-armv7") or "",
        shutil.which("mihomo-linux-amd64") or "",
        shutil.which("clash-meta") or "",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    return None

def validate_with_mihomo(path: Path) -> tuple[bool, str]:
    binary = mihomo_binary()
    if not binary:
        return True, "Mihomo binary not found; internal validation only"
    try:
        proc = subprocess.run(
            [binary, "-t", "-f", str(path)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, timeout=30, check=False
        )
        out = (proc.stdout or "").strip()
        if proc.returncode == 0:
            return True, out or "configuration test successful"
        return False, out[-4000:] or f"mihomo exited with code {proc.returncode}"
    except Exception as exc:
        return False, f"Mihomo validation error: {exc}"

def adaptive_workers(n: int) -> int:
    if n <= 50:
        base = 4
    elif n <= 100:
        base = 8
    elif n <= 500:
        base = 16
    elif n <= 2000:
        base = 24
    else:
        base = MAX_WORKERS_CAP
    return min(base, resource_worker_cap())

# ----------------------------- NORMALIZATION -------------------------

def dedupe(proxies: Iterable[Proxy]) -> tuple[list[Proxy], int]:
    seen: set[str] = set()
    result: list[Proxy] = []
    removed = 0
    for p in proxies:
        p.fingerprint = fingerprint_proxy(p)
        if p.fingerprint in seen:
            removed += 1
            continue
        seen.add(p.fingerprint)
        result.append(p)
    return result, removed

def assign_unique_names(proxies: list[Proxy]) -> None:
    counts: dict[str, int] = {}
    for p in proxies:
        base = clean_name(p.name, p.type.upper())
        counts[base] = counts.get(base, 0) + 1
        p.name = base
    used: set[str] = set()
    serial: dict[str, int] = {}
    for p in proxies:
        if p.name not in used and counts[p.name] == 1:
            used.add(p.name)
            continue
        serial[p.name] = serial.get(p.name, 0) + 1
        candidate = f"{p.name} #{serial[p.name]}"
        while candidate in used:
            serial[p.name] += 1
            candidate = f"{p.name} #{serial[p.name]}"
        p.name = candidate
        used.add(candidate)

# ----------------------------- MIHOMO MAPPING ------------------------

def sanitize_proxy_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): sanitize_proxy_value(v) for k, v in value.items() if v is not None and v != ""}
    if isinstance(value, list):
        return [sanitize_proxy_value(v) for v in value]
    return value

def normalize_proxy_for_mihomo(p: Proxy) -> None:
    p.data = sanitize_proxy_value(p.data)
    # Normalize common URI booleans that often arrive as strings.
    for key in ("tls", "udp", "skip-cert-verify", "disable-sni", "reduce-rtt", "tfo", "mptcp"):
        if key in p.data and isinstance(p.data[key], str):
            p.data[key] = p.data[key].lower() in {"1", "true", "yes", "on"}
    if "alpn" in p.data and isinstance(p.data["alpn"], str):
        p.data["alpn"] = [x.strip() for x in p.data["alpn"].split(",") if x.strip()]

def proxy_yaml(p: Proxy) -> dict[str, Any]:
    d: dict[str, Any] = {"name": p.name, "type": p.type, "server": p.server, "port": p.port}
    # Copy all preserved parameters except internal fields.
    for k, v in p.data.items():
        if v in (None, ""):
            continue
        d[k] = v
    return d

def build_config(proxies: list[Proxy]) -> dict[str, Any]:
    for p in proxies:
        normalize_proxy_for_mihomo(p)
    cfg = copy.deepcopy(CORE_DEFAULTS)
    cfg["proxies"] = [proxy_yaml(p) for p in proxies]
    cfg["proxy-groups"] = [{
        "name": GROUP_NAME,
        "type": "select",
        "proxies": [p.name for p in proxies],
    }]
    # Conservative routing: all traffic enters the user's one fixed group.
    cfg["rules"] = [f"MATCH,{GROUP_NAME}"]
    return cfg

def validate_config(cfg: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    proxies = cfg.get("proxies")
    groups = cfg.get("proxy-groups")
    rules = cfg.get("rules")
    if not isinstance(proxies, list) or not proxies:
        errors.append("proxies missing/empty")
        return errors

    names: list[str] = []
    for idx, p in enumerate(proxies, 1):
        if not isinstance(p, dict):
            errors.append(f"proxy[{idx}] is not an object")
            continue
        name = p.get("name")
        ptype = str(p.get("type") or "").lower()
        server = p.get("server")
        port = p.get("port")
        if not isinstance(name, str) or not name:
            errors.append(f"proxy[{idx}] missing name")
        else:
            names.append(name)
        if ptype not in PROTOCOLS:
            errors.append(f"proxy[{idx}] unsupported type: {ptype}")
        if not isinstance(server, str) or not server.strip():
            errors.append(f"proxy[{idx}] missing server")
        try:
            port_i = int(port)
            if not 1 <= port_i <= 65535:
                raise ValueError
        except Exception:
            errors.append(f"proxy[{idx}] invalid port")

    if len(names) != len(set(names)):
        errors.append("duplicate proxy names")
    if not isinstance(groups, list) or len(groups) != 1:
        errors.append("proxy-groups must contain exactly one group")
    else:
        g = groups[0]
        if not isinstance(g, dict):
            errors.append("proxy group is not an object")
        else:
            if g.get("name") != GROUP_NAME:
                errors.append("group name mismatch")
            if g.get("type") != "select":
                errors.append("group type must be select")
            refs = g.get("proxies", [])
            if not isinstance(refs, list) or not refs:
                errors.append("select group has no proxies")
            else:
                missing = [x for x in refs if x not in names]
                if missing:
                    errors.append(f"invalid group refs: {len(missing)}")
    if rules != [f"MATCH,{GROUP_NAME}"]:
        errors.append("rules must contain exactly one static MATCH rule")
    return errors

# ----------------------------- NO REPORT FILES -----------------------

# ----------------------------- FILE / INPUT ---------------------------

def ensure_input() -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    if not INPUT_PATH.exists():
        INPUT_PATH.write_text("", encoding="utf-8")

def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".mihomo_", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    finally:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass

def open_nano() -> None:
    os.system(f'nano "{INPUT_PATH}"')

def load_input() -> str:
    if not INPUT_PATH.exists():
        return ""
    size = INPUT_PATH.stat().st_size
    if size > MAX_INPUT_BYTES:
        raise RuntimeError(f"Input too large: {size} bytes")
    return INPUT_PATH.read_text(encoding="utf-8", errors="ignore")

def clear_input() -> None:
    atomic_write(INPUT_PATH, "")

# ----------------------------- PROCESS --------------------------------

def parse_all(text: str) -> tuple[list[Proxy], int]:
    lines = expand_input(text)
    parsed: list[Proxy] = []
    invalid = 0
    for line in lines:
        if line.startswith("{") or line.startswith("["):
            try:
                objs = json.loads(line)
                if isinstance(objs, dict):
                    objs = [objs]
                if isinstance(objs, list):
                    local = [parse_json_proxy(x) for x in objs if isinstance(x, dict)]
                    ok = [x for x in local if x]
                    parsed.extend(ok)
                    invalid += len(objs) - len(ok)
                    continue
            except Exception:
                pass
        p = parse_line(line)
        if p:
            parsed.append(p)
        else:
            invalid += 1
    return parsed, invalid

def process_reachability(proxies: list[Proxy], dns_cache: TTLCache, tcp_cache: TTLCache) -> tuple[list[Proxy], list[Proxy]]:
    workers = adaptive_workers(len(proxies))
    log(f"[TEST] LIGHT DNS -> TCP | workers={workers} | nodes={len(proxies)}")
    alive: list[Proxy] = []
    failed: list[Proxy] = []
    def one(p: Proxy):
        r = test_proxy(p, dns_cache, tcp_cache)
        p.addresses = r.addresses
        p.latency_ms = r.latency_ms
        p.status = "alive" if r.tcp_ok else "failed"
        if r.tcp_ok:
            version = infer_ip_version(r.addresses)
            if version:
                p.data.setdefault("ip-version", version)
        p.error = r.error
        p.score = score_proxy(p)
        return p
    for start in range(0, len(proxies), BATCH_SIZE):
        batch = proxies[start:start+BATCH_SIZE]
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(workers, len(batch))) as ex:
            for p in ex.map(one, batch):
                (alive if p.status == "alive" else failed).append(p)
        log(f"[TEST] {min(start+BATCH_SIZE, len(proxies))}/{len(proxies)}")
    alive.sort(key=lambda x: (-(x.score), x.latency_ms if x.latency_ms is not None else 999999))
    return alive, failed

def save_outputs(out_dir: Path, base_name: str, cfg: dict[str, Any]) -> Path:
    """Validate and atomically publish ONLY the final YAML file."""
    yaml_path = out_dir / f"{base_name}.yaml"
    yml = "# Generated by MIHOMO INDUSTRIAL ENGINE ULTIMATE-V6 - strict block YAML\n" + yaml_dump(cfg) + "\n"
    validate_serialized_yaml(yml)

    out_dir.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".mihomo_validate_", dir=str(out_dir))
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(yml)
            f.flush()
            os.fsync(f.fileno())
        ok, detail = validate_with_mihomo(tmp_path)
        if not ok:
            raise RuntimeError("Mihomo validation failed: " + detail)
        written = tmp_path.read_text(encoding="utf-8")
        validate_serialized_yaml(written)
        os.replace(tmp_path, yaml_path)
        return yaml_path
    finally:
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass

def run_once():
    ensure_input()
    log("\n" + "=" * 72)
    log(f"  {ENGINE_VERSION}")
    log("  ONE GROUP / STATIC / SELECT🔰 / LIGHT REACHABILITY / YAML-ONLY OUTPUT")
    log("=" * 72)
    open_nano()
    text = load_input()
    if not text.strip():
        log("[ERROR] input_mobile.txt is empty.")
        return

    started = time.time()
    log("[1/7] Parsing and normalizing...")
    raw_lines = len([x for x in text.splitlines() if x.strip()])
    parsed, invalid = parse_all(text)
    log(f"      raw={raw_lines} parsed={len(parsed)} invalid={invalid}")

    parsed, dedup = dedupe(parsed)
    log(f"[2/7] Fingerprint dedupe -> {len(parsed)} (removed {dedup})")
    if not parsed:
        log("[ERROR] No supported proxy configuration was found.")
        return

    dns_cache = TTLCache(BASE_DIR / ".cache" / "dns.json")
    tcp_cache = TTLCache(BASE_DIR / ".cache" / "tcp.json")

    log("[3/7] Lightweight reachability...")
    alive, failed = process_reachability(parsed, dns_cache, tcp_cache)
    log(f"      alive={len(alive)} failed={len(failed)}")

    if not alive:
        log("[ERROR] No reachable nodes. YAML was NOT generated.")
        dns_cache.save()
        tcp_cache.save()
        return

    log("[4/7] Stable naming + scoring...")
    assign_unique_names(alive)

    log("[5/7] Building Mihomo configuration...")
    cfg = build_config(alive)

    log("[6/7] Final structural validation...")
    errors = validate_config(cfg)
    if errors:
        raise RuntimeError("FINAL VALIDATION FAILED: " + "; ".join(errors))

    out_name = input("\nOutput folder name (Enter = Akbar98): ").strip() or "Akbar98"
    base_name = input("Output YAML name (without .yaml): ").strip() or "mihomo_final"
    out_dir = Path("/storage/emulated/0/Download") / clean_name(out_name, "Akbar98")
    base_name = re.sub(r'[\\/:*?"<>|]+', "_", base_name).strip() or "mihomo_final"


    log("[7/7] Atomic output...")
    yaml_path = save_outputs(out_dir, base_name, cfg)
    dns_cache.save()
    tcp_cache.save()

    # Only clear input after the YAML has been safely written.
    clear_input()

    log("\nSUCCESS")
    log(f"YAML   : {yaml_path}")
    log(f"Nodes  : {len(alive)}")
    log("Input  : cleared for next run.")
    log("=" * 72)

def main():
    try:
        ensure_input()
        run_once()
    except KeyboardInterrupt:
        log("\n[STOP] Cancelled. Input was NOT cleared.")
    except Exception as e:
        log(f"\n[FATAL] {type(e).__name__}: {e}")
        log("Input was NOT cleared because the run did not finish safely.")

if __name__ == "__main__":
    main()

