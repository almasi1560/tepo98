#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
"""
MIHOMO FULL INDUSTRIAL ENGINE V7
Full outbound/group/provider builder for Termux.

- Full group engine: select / url-test / fallback / load-balance
- Legacy relay builder is available but disabled by default because current
  Mihomo documentation marks relay deprecated in favor of dialer-proxy.
- Proxy providers: http / file / inline
- URI + Base64 + JSON + YAML input
- VLESS / VMess / Trojan / SS / SSR / Hysteria / Hysteria2 / TUIC /
  HTTP / SOCKS5 / WireGuard / AnyTLS / Snell structured nodes
- No automatic ping, DNS probe, TCP probe, HTTP speed test, or download test.
- No report files.
- Input is emptied before nano and again after successful output.
- Atomic YAML write and structural validation.
"""

from __future__ import annotations

import base64
import copy
import hashlib
import ipaddress
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.parse
from pathlib import Path
from typing import Any


ENGINE_VERSION = "MIHOMO-FULL-INDUSTRIAL-V7"

BASE_DIR = Path("/storage/emulated/0/Download/Akbar98")
INPUT_PATH = BASE_DIR / "input.txt"
DOWNLOAD_DIR = Path("/storage/emulated/0/Download")

# Full group architecture for this version.
ENABLE_SELECT = True
ENABLE_URL_TEST = True
ENABLE_FALLBACK = True
ENABLE_LOAD_BALANCE = True

# Relay is supported by the builder, but current Mihomo documentation marks
# relay deprecated in favor of dialer-proxy.
ENABLE_LEGACY_RELAY = False

DEFAULT_RULE_GROUP = "Select🔰"
HEALTH_URL = "https://www.gstatic.com/generate_204"
HEALTH_INTERVAL = 300
HEALTH_TIMEOUT = 5000

MAX_INPUT_BYTES = 25 * 1024 * 1024
MAX_NODES = 10000

SUPPORTED_TYPES = {
    "vless",
    "vmess",
    "trojan",
    "ss",
    "ssr",
    "hysteria",
    "hysteria2",
    "hy2",
    "tuic",
    "http",
    "socks",
    "socks5",
    "wireguard",
    "anytls",
    "snell",
}

BOOL_KEYS = {
    "udp",
    "tls",
    "skip-cert-verify",
    "disable-sni",
    "reduce-rtt",
    "fast-open",
    "tfo",
    "mptcp",
    "global-padding",
    "authenticated-length",
    "reuse",
    "udp-over-tcp",
}

INT_KEYS = {
    "port",
    "alterId",
    "heartbeat-interval",
    "request-timeout",
    "max-udp-relay-packet-size",
    "max-open-streams",
    "idle-session-check-interval",
    "idle-session-timeout",
    "min-idle-session",
    "recv-window",
    "recv-window-conn",
    "max-failed-times",
    "timeout",
    "interval",
    "size-limit",
    "routing-mark",
}


def log(value: Any = "") -> None:
    print(str(value), flush=True)


def clean_name(value: Any, fallback: str = "Node") -> str:
    value = str(value or "").replace("\r", " ").replace("\n", " ").strip()
    value = re.sub(r"[\x00-\x1f\x7f]", "", value)
    return value[:120] or fallback


def safe_int(value: Any, default: Any = 0) -> Any:
    try:
        return int(str(value).strip())
    except Exception:
        return default


def bool_value(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {
        "1", "true", "yes", "on", "enable", "enabled"
    }


def b64decode_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None

    value = re.sub(r"\s+", "", value.strip())
    if not value:
        return None

    value += "=" * ((4 - len(value) % 4) % 4)

    for decoder in (base64.urlsafe_b64decode, base64.b64decode):
        try:
            return decoder(value).decode("utf-8")
        except Exception:
            pass

    return None


def unquote(value: Any) -> str:
    return urllib.parse.unquote(str(value or ""))


def parse_qs(url: urllib.parse.ParseResult) -> dict[str, str]:
    raw = urllib.parse.parse_qs(url.query, keep_blank_values=True)
    return {
        key: unquote(values[-1]) if values else ""
        for key, values in raw.items()
    }


def split_host_port(host: Any, port: Any = 0) -> tuple[str, int]:
    host = str(host or "").strip()
    port = safe_int(port, 0)

    if host.startswith("[") and "]" in host:
        end = host.index("]")
        inside = host[1:end]
        rest = host[end + 1:]
        if rest.startswith(":") and not port:
            port = safe_int(rest[1:], 0)
        return inside, port

    # Only split simple host:port. Raw IPv6 is kept intact.
    if host.count(":") == 1 and not port:
        left, right = host.rsplit(":", 1)
        if right.isdigit():
            return left, int(right)

    return host, port


def canonical(value: Any) -> str:
    if isinstance(value, dict):
        return "{" + ",".join(
            f"{key}:{canonical(value[key])}" for key in sorted(value)
        ) + "}"

    if isinstance(value, (list, tuple)):
        return "[" + ",".join(canonical(item) for item in value) + "]"

    return str(value).strip()


def normalize_common(data: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}

    for key, value in data.items():
        if value is None or value == "":
            continue

        key = str(key)

        if key in BOOL_KEYS:
            result[key] = bool_value(value)

        elif key in INT_KEYS:
            integer = safe_int(value, None)
            result[key] = integer if integer is not None else value

        else:
            result[key] = value

    return result


def fingerprint(node_data: dict[str, Any]) -> str:
    data = copy.deepcopy(node_data)
    data.pop("name", None)

    body = json.dumps(
        data,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )

    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def tls_fields(
    query: dict[str, str],
    data: dict[str, Any],
    servername_key: str = "servername",
) -> None:
    if query.get("security"):
        security = query["security"].lower()

        if security in {"tls", "reality", "true", "1"}:
            data["tls"] = True
        elif security in {"none", "false", "0"}:
            data["tls"] = False

    for source in ("sni", "servername", "peer"):
        if query.get(source):
            data[servername_key] = query[source]
            break

    if query.get("alpn"):
        data["alpn"] = [
            item for item in query["alpn"].split(",") if item
        ]

    if query.get("fp"):
        data["client-fingerprint"] = query["fp"]

    if query.get("client-fingerprint"):
        data["client-fingerprint"] = query["client-fingerprint"]

    if query.get("fingerprint"):
        data["fingerprint"] = query["fingerprint"]

    if "skip-cert-verify" in query:
        data["skip-cert-verify"] = bool_value(
            query["skip-cert-verify"]
        )

    if "insecure" in query:
        data["skip-cert-verify"] = bool_value(query["insecure"])


def transport_fields(
    query: dict[str, str],
    data: dict[str, Any],
    network: str,
) -> None:
    data["network"] = network

    if network in {"ws", "http"}:
        ws: dict[str, Any] = {}

        if query.get("path"):
            ws["path"] = query["path"]

        if query.get("host"):
            ws["headers"] = {"Host": query["host"]}

        if query.get("headers"):
            try:
                headers = json.loads(query["headers"])
                if isinstance(headers, dict):
                    ws["headers"] = headers
            except Exception:
                pass

        if ws:
            data["ws-opts"] = ws

    elif network == "grpc":
        grpc: dict[str, Any] = {}

        for source in (
            "serviceName",
            "service-name",
            "grpc-service-name",
        ):
            if query.get(source):
                grpc["grpc-service-name"] = query[source]
                break

        if query.get("mode"):
            grpc["grpc-mode"] = query["mode"]

        if grpc:
            data["grpc-opts"] = grpc

    elif network == "h2":
        h2: dict[str, Any] = {}

        if query.get("path"):
            h2["path"] = query["path"]

        if query.get("host"):
            h2["host"] = [
                item for item in query["host"].split(",") if item
            ]

        if h2:
            data["h2-opts"] = h2


def make_node(
    proxy_type: str,
    name: Any,
    server: Any,
    port: Any,
    data: dict[str, Any],
) -> dict[str, Any]:
    server, port = split_host_port(server, port)

    try:
        port = int(port)
    except Exception:
        port = 0

    normalized = normalize_common(data)

    normalized["server"] = str(server)
    normalized["port"] = port
    normalized["name"] = clean_name(
        name,
        proxy_type.upper(),
    )

    if proxy_type == "socks5":
        proxy_type = "socks"

    if proxy_type == "hy2":
        proxy_type = "hysteria2"

    normalized["type"] = proxy_type

    return normalized


def parse_vmess(line: str) -> dict[str, Any] | None:
    try:
        payload = line.split("://", 1)[1].split("#", 1)[0]
        decoded = b64decode_text(payload)
        if not decoded:
            return None

        obj = json.loads(decoded)
    except Exception:
        return None

    host = (
        obj.get("add")
        or obj.get("address")
        or obj.get("server")
    )

    port = safe_int(obj.get("port"), 0)

    if not host or not (1 <= port <= 65535):
        return None

    data: dict[str, Any] = {
        "uuid": obj.get("id", ""),
        "alterId": safe_int(obj.get("aid"), 0),
        "cipher": obj.get("scy") or obj.get("cipher") or "auto",
        "network": obj.get("net") or "tcp",
    }

    if obj.get("tls"):
        data["tls"] = True

    if obj.get("sni"):
        data["servername"] = obj["sni"]

    if obj.get("fp"):
        data["client-fingerprint"] = obj["fp"]

    if obj.get("alpn"):
        data["alpn"] = (
            obj["alpn"].split(",")
            if isinstance(obj["alpn"], str)
            else obj["alpn"]
        )

    if obj.get("packet-encoding"):
        data["packet-encoding"] = obj["packet-encoding"]

    if obj.get("global-padding") is not None:
        data["global-padding"] = bool_value(
            obj["global-padding"]
        )

    if obj.get("authenticated-length") is not None:
        data["authenticated-length"] = bool_value(
            obj["authenticated-length"]
        )

    transport_query = {
        str(key): unquote(value)
        for key, value in obj.items()
        if value is not None
    }

    transport_fields(
        transport_query,
        data,
        data["network"],
    )

    for key in (
        "reality-opts",
        "shadow-tls-opts",
        "restls-opts",
        "jls-opts",
        "tlsmirror-opts",
        "smux",
    ):
        if isinstance(obj.get(key), dict):
            data[key] = obj[key]

    return make_node(
        "vmess",
        obj.get("ps") or "VMess",
        host,
        port,
        data,
    )


def parse_vless(line: str) -> dict[str, Any] | None:
    try:
        url = urllib.parse.urlparse(line)
    except Exception:
        return None

    host = url.hostname
    port = url.port

    if not host or not port:
        return None

    query = parse_qs(url)
    data: dict[str, Any] = {
        "uuid": unquote(url.username)
    }

    network = (
        query.get("type")
        or query.get("network")
        or "tcp"
    )

    tls_fields(query, data)
    transport_fields(query, data, network)

    for key in (
        "flow",
        "encryption",
        "packet-encoding",
    ):
        if query.get(key):
            data[key] = query[key]

    if query.get("security") == "reality":
        reality: dict[str, Any] = {}

        if query.get("pbk"):
            reality["public-key"] = query["pbk"]

        if query.get("sid"):
            reality["short-id"] = query["sid"]

        if reality:
            data["reality-opts"] = reality

    return make_node(
        "vless",
        query.get("remarks") or url.fragment or "VLESS",
        host,
        port,
        data,
    )


def parse_trojan(line: str) -> dict[str, Any] | None:
    try:
        url = urllib.parse.urlparse(line)
    except Exception:
        return None

    if not url.hostname or not url.port:
        return None

    query = parse_qs(url)

    data: dict[str, Any] = {
        "password": unquote(url.username),
        "tls": True,
    }

    tls_fields(query, data, "sni")

    network = (
        query.get("type")
        or query.get("network")
        or "tcp"
    )

    transport_fields(query, data, network)

    for key in (
        "udp",
        "skip-cert-verify",
        "name-cert-verify",
        "client-fingerprint",
        "fingerprint",
    ):
        if key in query:
            data[key] = (
                bool_value(query[key])
                if key == "udp"
                else query[key]
            )

    if query.get("flow"):
        data["flow"] = query["flow"]

    if query.get("pbk") or query.get("sid"):
        reality: dict[str, Any] = {}

        if query.get("pbk"):
            reality["public-key"] = query["pbk"]

        if query.get("sid"):
            reality["short-id"] = query["sid"]

        data["reality-opts"] = reality

    return make_node(
        "trojan",
        query.get("remarks") or url.fragment or "Trojan",
        url.hostname,
        url.port,
        data,
    )


def parse_ss(line: str) -> dict[str, Any] | None:
    try:
        url = urllib.parse.urlparse(line)
    except Exception:
        return None

    if not url.hostname or not url.port:
        return None

    user = url.username or ""
    password_part = url.password or ""

    method = ""
    password = ""

    if user and password_part:
        method = unquote(user)
        password = unquote(password_part)

    else:
        decoded = b64decode_text(user)

        if decoded and ":" in decoded:
            method, password = decoded.split(":", 1)

        elif ":" in user:
            method, password = user.split(":", 1)

    data: dict[str, Any] = {
        "cipher": method,
        "password": password,
    }

    query = parse_qs(url)

    if "udp" in query:
        data["udp"] = bool_value(query["udp"])

    if query.get("plugin"):
        parts = query["plugin"].split(";")
        data["plugin"] = parts[0]

        options: dict[str, str] = {}

        for part in parts[1:]:
            if "=" in part:
                key, value = part.split("=", 1)
                options[key] = value

        if options:
            data["plugin-opts"] = options

    return make_node(
        "ss",
        url.fragment or "SS",
        url.hostname,
        url.port,
        data,
    )


def parse_ssr(line: str) -> dict[str, Any] | None:
    decoded = b64decode_text(line.split("://", 1)[1])

    if not decoded:
        return None

    main, _, query_text = decoded.partition("/?")
    parts = main.split(":")

    if len(parts) < 6:
        return None

    host, port, protocol, cipher, obfs, password_b64 = parts[:6]

    query = urllib.parse.parse_qs(
        query_text,
        keep_blank_values=True,
    )

    password = (
        b64decode_text(password_b64)
        or password_b64
    )

    remarks = (
        b64decode_text(query.get("remarks", [""])[-1])
        or "SSR"
    )

    data = {
        "protocol": protocol,
        "cipher": cipher,
        "obfs": obfs,
        "password": password,
    }

    for source, target in (
        ("obfsparam", "obfs-param"),
        ("protoparam", "protocol-param"),
    ):
        if query.get(source):
            data[target] = (
                b64decode_text(query[source][-1])
                or query[source][-1]
            )

    return make_node(
        "ssr",
        remarks,
        host,
        safe_int(port, 0),
        data,
    )


def parse_hysteria(
    line: str,
    proxy_type: str,
) -> dict[str, Any] | None:
    try:
        url = urllib.parse.urlparse(line)
    except Exception:
        return None

    if not url.hostname or not url.port:
        return None

    query = parse_qs(url)
    data: dict[str, Any] = {}

    if proxy_type == "hysteria2":
        if url.username:
            data["password"] = unquote(url.username)

        for key in (
            "ports",
            "hop-interval",
            "up",
            "down",
            "obfs",
            "obfs-password",
            "obfs-min-packet-size",
            "obfs-max-packet-size",
            "bbr-profile",
            "sni",
            "name-cert-verify",
            "fingerprint",
            "handshake-timeout",
        ):
            if query.get(key):
                data[key] = query[key]

    else:
        if url.username:
            data["auth-str"] = unquote(url.username)

        for key in (
            "protocol",
            "up",
            "down",
            "obfs",
            "sni",
            "name-cert-verify",
            "fingerprint",
            "recv-window",
            "recv-window-conn",
            "ports",
            "fast-open",
        ):
            if query.get(key):
                data[key] = query[key]

    if query.get("alpn"):
        data["alpn"] = query["alpn"].split(",")

    if "skip-cert-verify" in query:
        data["skip-cert-verify"] = bool_value(
            query["skip-cert-verify"]
        )

    if "insecure" in query:
        data["skip-cert-verify"] = bool_value(
            query["insecure"]
        )

    return make_node(
        proxy_type,
        query.get("remarks") or url.fragment or proxy_type.upper(),
        url.hostname,
        url.port,
        data,
    )


def parse_tuic(line: str) -> dict[str, Any] | None:
    try:
        url = urllib.parse.urlparse(line)
    except Exception:
        return None

    if not url.hostname or not url.port:
        return None

    query = parse_qs(url)
    data: dict[str, Any] = {}

    if url.username:
        data["uuid"] = unquote(url.username)

    if url.password:
        data["password"] = unquote(url.password)

    for key in (
        "token",
        "ip",
        "heartbeat-interval",
        "alpn",
        "disable-sni",
        "reduce-rtt",
        "request-timeout",
        "udp-relay-mode",
        "congestion-controller",
        "bbr-profile",
        "max-udp-relay-packet-size",
        "fast-open",
        "skip-cert-verify",
        "name-cert-verify",
        "max-open-streams",
        "sni",
    ):
        if key in query and query[key] != "":
            data[key] = query[key]

    if isinstance(data.get("alpn"), str):
        data["alpn"] = data["alpn"].split(",")

    return make_node(
        "tuic",
        query.get("name") or url.fragment or "TUIC",
        url.hostname,
        url.port,
        data,
    )


def parse_http_socks(
    line: str,
    proxy_type: str,
) -> dict[str, Any] | None:
    try:
        url = urllib.parse.urlparse(line)
    except Exception:
        return None

    if not url.hostname or not url.port:
        return None

    data: dict[str, Any] = {}

    if url.username:
        data["username"] = unquote(url.username)

    if url.password:
        data["password"] = unquote(url.password)

    query = parse_qs(url)

    if proxy_type == "http" and (
        url.scheme.lower() == "https"
        or "tls" in query
    ):
        data["tls"] = True

    for key in (
        "tls",
        "udp",
        "skip-cert-verify",
        "name-cert-verify",
        "sni",
    ):
        if key in query:
            data[key] = (
                bool_value(query[key])
                if key in {"tls", "udp", "skip-cert-verify"}
                else query[key]
            )

    return make_node(
        proxy_type,
        url.fragment or proxy_type.upper(),
        url.hostname,
        url.port,
        data,
    )


def parse_anytls(line: str) -> dict[str, Any] | None:
    try:
        url = urllib.parse.urlparse(line)
    except Exception:
        return None

    if not url.hostname or not url.port:
        return None

    query = parse_qs(url)

    data: dict[str, Any] = {
        "password": unquote(url.username)
    }

    for key in (
        "client-fingerprint",
        "client-metadata",
        "idle-session-check-interval",
        "idle-session-timeout",
        "min-idle-session",
        "sni",
        "alpn",
        "skip-cert-verify",
        "name-cert-verify",
        "fingerprint",
    ):
        if query.get(key) != "":
            data[key] = query[key]

    if isinstance(data.get("alpn"), str):
        data["alpn"] = data["alpn"].split(",")

    return make_node(
        "anytls",
        query.get("remarks") or url.fragment or "AnyTLS",
        url.hostname,
        url.port,
        data,
    )


def parse_uri(line: str) -> dict[str, Any] | None:
    low = line.lower()

    if low.startswith("vmess://"):
        return parse_vmess(line)

    if low.startswith("vless://"):
        return parse_vless(line)

    if low.startswith("trojan://"):
        return parse_trojan(line)

    if low.startswith("ss://"):
        return parse_ss(line)

    if low.startswith("ssr://"):
        return parse_ssr(line)

    if low.startswith("hysteria2://"):
        return parse_hysteria(line, "hysteria2")

    if low.startswith("hy2://"):
        return parse_hysteria(line, "hysteria2")

    if low.startswith("hysteria://"):
        return parse_hysteria(line, "hysteria")

    if low.startswith("tuic://"):
        return parse_tuic(line)

    if low.startswith("anytls://"):
        return parse_anytls(line)

    if low.startswith("socks5://"):
        return parse_http_socks(line, "socks")

    if low.startswith("socks://"):
        return parse_http_socks(line, "socks")

    return None


def parse_node_dict(
    obj: dict[str, Any],
) -> dict[str, Any] | None:
    if not isinstance(obj, dict):
        return None

    proxy_type = str(obj.get("type") or "").lower()

    if proxy_type not in SUPPORTED_TYPES:
        return None

    if proxy_type == "socks5":
        proxy_type = "socks"

    if proxy_type == "hy2":
        proxy_type = "hysteria2"

    server = (
        obj.get("server")
        or obj.get("address")
        or obj.get("add")
        or obj.get("host")
    )

    port = safe_int(obj.get("port"), 0)

    if not server or not (1 <= port <= 65535):
        return None

    data = copy.deepcopy(obj)

    for key in (
        "name",
        "type",
        "server",
        "address",
        "add",
        "host",
        "port",
        "remarks",
    ):
        data.pop(key, None)

    return make_node(
        proxy_type,
        obj.get("name") or obj.get("remarks") or proxy_type.upper(),
        server,
        port,
        data,
    )


def walk_structured(
    obj: Any,
    result: list[dict[str, Any]],
) -> None:
    if isinstance(obj, dict):
        parsed = parse_node_dict(obj)

        if parsed:
            result.append(parsed)

        for value in obj.values():
            if isinstance(value, (dict, list)):
                walk_structured(value, result)

    elif isinstance(obj, list):
        for item in obj:
            walk_structured(item, result)


def parse_structured(text: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []

    try:
        obj = json.loads(text)
        walk_structured(obj, result)

        if result:
            return result
    except Exception:
        pass

    try:
        import yaml

        obj = yaml.safe_load(text)
        walk_structured(obj, result)

    except Exception:
        pass

    return result


def parse_all(text: str) -> list[dict[str, Any]]:
    nodes: list[dict[str, Any]] = []

    # Structured config first.
    nodes.extend(parse_structured(text))

    for raw_line in text.splitlines():
        line = raw_line.strip().lstrip("\ufeff")

        if not line or line.startswith("#"):
            continue

        if line.startswith("{") or line.startswith("["):
            continue

        parsed = parse_uri(line)

        if parsed:
            nodes.append(parsed)
            continue

        decoded = b64decode_text(line)

        if decoded and re.search(
            r"(?:vmess|vless|trojan|ss|ssr|hysteria|tuic|anytls)://",
            decoded,
            re.I,
        ):
            for sub_line in decoded.splitlines():
                parsed = parse_uri(sub_line.strip())

                if parsed:
                    nodes.append(parsed)

    return nodes


def dedupe(
    nodes: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    seen: set[str] = set()
    result: list[dict[str, Any]] = []

    for node_data in nodes:
        fp = fingerprint(node_data)

        if fp in seen:
            continue

        seen.add(fp)
        result.append(node_data)

    return result


def unique_names(nodes: list[dict[str, Any]]) -> None:
    used: dict[str, int] = {}

    for node_data in nodes:
        base = clean_name(
            node_data.get("name"),
            str(node_data.get("type", "NODE")).upper(),
        )

        used[base] = used.get(base, 0) + 1

        if used[base] == 1:
            node_data["name"] = base
        else:
            node_data["name"] = f"{base} {used[base]}"


def validate_node(
    node_data: dict[str, Any],
) -> list[str]:
    errors: list[str] = []

    proxy_type = node_data.get("type")
    server = node_data.get("server")
    port = node_data.get("port")

    if proxy_type not in SUPPORTED_TYPES:
        errors.append(f"unsupported type {proxy_type}")

    if not server:
        errors.append("missing server")

    if not isinstance(port, int) or not (1 <= port <= 65535):
        errors.append("invalid port")

    if proxy_type in {"vless", "vmess"}:
        if not node_data.get("uuid"):
            errors.append("missing uuid")

    if proxy_type == "trojan":
        if not node_data.get("password"):
            errors.append("missing password")

    if proxy_type == "ss":
        if not node_data.get("cipher"):
            errors.append("missing ss cipher")
        if not node_data.get("password"):
            errors.append("missing ss password")

    if proxy_type == "ssr":
        if not node_data.get("cipher"):
            errors.append("missing ssr cipher")
        if not node_data.get("password"):
            errors.append("missing ssr password")

    if proxy_type == "tuic":
        if not (
            node_data.get("token")
            or (
                node_data.get("uuid")
                and node_data.get("password")
            )
        ):
            errors.append(
                "TUIC requires token or uuid+password"
            )

    if proxy_type == "hysteria2":
        if not node_data.get("password"):
            errors.append("missing hysteria2 password")

    if proxy_type == "hysteria":
        if not (
            node_data.get("auth-str")
            or node_data.get("auth")
        ):
            errors.append("missing hysteria auth")

    if proxy_type == "anytls":
        if not node_data.get("password"):
            errors.append("missing anytls password")

    if proxy_type == "snell":
        if not node_data.get("psk"):
            errors.append("missing snell psk")

    return errors


def yaml_scalar(value: Any) -> str:
    if value is None:
        return "null"

    if isinstance(value, bool):
        return "true" if value else "false"

    if isinstance(value, (int, float)):
        return str(value)

    return json.dumps(
        str(value),
        ensure_ascii=False,
    )


def yaml_dump(
    obj: Any,
    level: int = 0,
) -> list[str]:
    pad = "  " * level

    if isinstance(obj, dict):
        if not obj:
            return [pad + "{}"]

        lines: list[str] = []

        for key, value in obj.items():
            yaml_key = yaml_scalar(key)

            if isinstance(value, dict):
                if not value:
                    lines.append(
                        f"{pad}{yaml_key}: {{}}"
                    )
                else:
                    lines.append(
                        f"{pad}{yaml_key}:"
                    )
                    lines.extend(
                        yaml_dump(value, level + 1)
                    )

            elif isinstance(value, list):
                if not value:
                    lines.append(
                        f"{pad}{yaml_key}: []"
                    )
                else:
                    lines.append(
                        f"{pad}{yaml_key}:"
                    )
                    lines.extend(
                        yaml_dump(value, level + 1)
                    )

            else:
                lines.append(
                    f"{pad}{yaml_key}: "
                    f"{yaml_scalar(value)}"
                )

        return lines

    if isinstance(obj, list):
        if not obj:
            return [pad + "[]"]

        lines: list[str] = []

        for value in obj:
            if isinstance(value, dict):
                if not value:
                    lines.append(pad + "- {}")
                    continue

                items = list(value.items())
                first_key, first_value = items[0]

                if isinstance(first_value, dict):
                    lines.append(
                        f"{pad}- {yaml_scalar(first_key)}:"
                    )
                    lines.extend(
                        yaml_dump(first_value, level + 2)
                    )

                elif isinstance(first_value, list):
                    lines.append(
                        f"{pad}- {yaml_scalar(first_key)}:"
                    )
                    lines.extend(
                        yaml_dump(first_value, level + 2)
                    )

                else:
                    lines.append(
                        f"{pad}- {yaml_scalar(first_key)}: "
                        f"{yaml_scalar(first_value)}"
                    )

                continuation_pad = "  " * (level + 1)

                for key, nested in items[1:]:
                    yaml_key = yaml_scalar(key)

                    if isinstance(nested, (dict, list)):
                        lines.append(
                            f"{continuation_pad}{yaml_key}:"
                        )
                        lines.extend(
                            yaml_dump(nested, level + 2)
                        )
                    else:
                        lines.append(
                            f"{continuation_pad}{yaml_key}: "
                            f"{yaml_scalar(nested)}"
                        )

            elif isinstance(value, list):
                lines.append(pad + "-")
                lines.extend(
                    yaml_dump(value, level + 1)
                )

            elif isinstance(value, dict):
                lines.append(pad + "-")
                lines.extend(
                    yaml_dump(value, level + 1)
                )

            else:
                lines.append(
                    pad + "- " + yaml_scalar(value)
                )

        return lines

    return [pad + yaml_scalar(obj)]


def validate_yaml_text(text: str) -> list[str]:
    try:
        import yaml
        parsed = yaml.safe_load(text)

        if not isinstance(parsed, dict):
            return ["YAML root is not mapping"]

        return validate_config(parsed)

    except ImportError:
        # The in-memory configuration was already structurally validated.
        # If PyYAML is absent, native Mihomo validation is used when available.
        return []

    except Exception as exc:
        return [f"YAML syntax: {exc}"]


def group_common(
    name: str,
    group_type: str,
    nodes: list[str],
) -> dict[str, Any]:
    return {
        "name": name,
        "type": group_type,
        "proxies": nodes,
        "url": HEALTH_URL,
        "interval": HEALTH_INTERVAL,
        "lazy": True,
        "timeout": HEALTH_TIMEOUT,
    }


def build_groups(
    names: list[str],
) -> list[dict[str, Any]]:
    groups: list[dict[str, Any]] = []

    if ENABLE_SELECT:
        groups.append(
            {
                "name": "Select🔰",
                "type": "select",
                "proxies": ["DIRECT"] + names,
            }
        )

    if ENABLE_URL_TEST:
        groups.append(
            group_common(
                "Auto⚡",
                "url-test",
                names,
            )
        )

    if ENABLE_FALLBACK:
        groups.append(
            group_common(
                "Fallback🛡",
                "fallback",
                names,
            )
        )

    if ENABLE_LOAD_BALANCE:
        load_balance = group_common(
            "Balance⚖",
            "load-balance",
            names,
        )
        load_balance["strategy"] = "consistent-hashing"
        groups.append(load_balance)

    if ENABLE_LEGACY_RELAY and len(names) >= 2:
        groups.append(
            {
                "name": "Relay🔗",
                "type": "relay",
                "proxies": names[:2],
            }
        )

    return groups


def build_default_rules() -> list[str]:
    return [f"MATCH,{DEFAULT_RULE_GROUP}"]


def extract_top_level_sections(
    text: str,
) -> dict[str, Any]:
    result: dict[str, Any] = {}

    try:
        import yaml

        obj = yaml.safe_load(text)

        if isinstance(obj, dict):
            for key in (
                "proxy-providers",
                "rule-providers",
                "rules",
                "dns",
                "tun",
                "sniffer",
                "profile",
                "geodata-mode",
                "geox-url",
            ):
                if key in obj:
                    result[key] = obj[key]

    except Exception:
        pass

    return result


def normalize_provider(
    name: str,
    provider: Any,
) -> dict[str, Any] | None:
    if not isinstance(provider, dict):
        return None

    provider_type = str(
        provider.get("type") or ""
    ).lower()

    if provider_type not in {
        "http",
        "file",
        "inline",
    }:
        return None

    result = copy.deepcopy(provider)

    if provider_type == "http" and not result.get("url"):
        return None

    if provider_type == "file" and not result.get("path"):
        return None

    return result


def build_config(
    nodes: list[dict[str, Any]],
    source_text: str = "",
) -> dict[str, Any]:
    unique_names(nodes)

    names = [
        node_data["name"]
        for node_data in nodes
    ]

    config: dict[str, Any] = {
        "mixed-port": 7890,
        "allow-lan": False,
        "mode": "rule",
        "log-level": "info",
        "ipv6": True,
        "unified-delay": True,
        "tcp-concurrent": True,
        "find-process-mode": "strict",
        "proxies": nodes,
        "proxy-groups": build_groups(names),
        "rules": build_default_rules(),
    }

    # Preserve valid top-level sections found in an imported YAML config.
    extra = extract_top_level_sections(source_text)

    for key, value in extra.items():
        if key == "proxy-providers":
            if not isinstance(value, dict):
                continue

            providers: dict[str, Any] = {}

            for provider_name, provider in value.items():
                normalized = normalize_provider(
                    str(provider_name),
                    provider,
                )

                if normalized:
                    providers[
                        clean_name(
                            provider_name,
                            "provider",
                        )
                    ] = normalized

            if providers:
                config[key] = providers

        elif key == "rules":
            if isinstance(value, list) and value:
                config["rules"] = copy.deepcopy(value)

                if not any(
                    str(item).startswith("MATCH,")
                    for item in value
                ):
                    config["rules"].append(
                        f"MATCH,{DEFAULT_RULE_GROUP}"
                    )

        else:
            config[key] = copy.deepcopy(value)

    return config


def validate_config(
    config: dict[str, Any],
) -> list[str]:
    errors: list[str] = []

    if not isinstance(config, dict):
        return ["root is not mapping"]

    nodes = config.get("proxies", [])

    if not isinstance(nodes, list) or not nodes:
        errors.append("proxies is empty")

    names: list[str] = []

    for node_data in nodes:
        if not isinstance(node_data, dict):
            errors.append("proxy item is not mapping")
            continue

        names.append(node_data.get("name"))

        errors.extend(
            [
                f"{node_data.get('name', '?')}: {error}"
                for error in validate_node(node_data)
            ]
        )

    if len(names) != len(set(names)):
        errors.append("duplicate proxy names")

    groups = config.get("proxy-groups", [])

    if not isinstance(groups, list) or not groups:
        errors.append("proxy-groups is empty")

    group_names = {
        group.get("name")
        for group in groups
        if isinstance(group, dict)
    }

    allowed_refs = (
        set(names)
        | group_names
        | {"DIRECT", "REJECT", "COMPATIBLE", "GLOBAL"}
    )

    for group in groups:
        if not isinstance(group, dict):
            errors.append("group item is not mapping")
            continue

        group_name = group.get("name")
        group_type = group.get("type")

        if not group_name or not group_type:
            errors.append("group missing name/type")
            continue

        if group_type not in {
            "select",
            "url-test",
            "fallback",
            "load-balance",
            "relay",
        }:
            errors.append(
                f"unsupported group type {group_type}"
            )

        refs = group.get("proxies", [])

        if not isinstance(refs, list) or not refs:
            errors.append(
                f"group {group_name} empty"
            )

        else:
            for ref in refs:
                if ref not in allowed_refs:
                    errors.append(
                        f"group {group_name}: "
                        f"missing ref {ref}"
                    )

        if group_type in {
            "url-test",
            "fallback",
            "load-balance",
        }:
            if not group.get("url"):
                errors.append(
                    f"group {group_name}: missing url"
                )

            if (
                not isinstance(
                    group.get("interval"),
                    int,
                )
                or group["interval"] <= 0
            ):
                errors.append(
                    f"group {group_name}: "
                    f"invalid interval"
                )

    rules = config.get("rules")

    if not isinstance(rules, list) or not rules:
        errors.append("rules empty")

    return errors


def atomic_write(
    path: Path,
    text: str,
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fd, temp_name = tempfile.mkstemp(
        prefix=".mihomo_",
        dir=str(path.parent),
    )

    try:
        with os.fdopen(
            fd,
            "w",
            encoding="utf-8",
        ) as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())

        os.replace(temp_name, path)

    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass


def clear_input() -> None:
    BASE_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )
    atomic_write(INPUT_PATH, "")


def open_editor() -> None:
    BASE_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Every run starts with a completely empty input file.
    clear_input()

    nano = shutil.which("nano")

    if nano:
        subprocess.call(
            [nano, str(INPUT_PATH)]
        )
        return

    log(
        "[WARN] nano not found; "
        "paste configs and press Ctrl-D."
    )

    try:
        data = sys.stdin.read()
        atomic_write(INPUT_PATH, data)
    except Exception:
        pass


def load_input() -> str:
    if not INPUT_PATH.exists():
        return ""

    size = INPUT_PATH.stat().st_size

    if size > MAX_INPUT_BYTES:
        raise RuntimeError(
            "input.txt is larger than 25 MiB"
        )

    return INPUT_PATH.read_text(
        encoding="utf-8",
        errors="ignore",
    )


def output_path() -> Path:
    folder = (
        input(
            "Output folder in Download [Akbar98]: "
        ).strip()
        or "Akbar98"
    )

    name = (
        input(
            "Output YAML name [mihomo_full]: "
        ).strip()
        or "mihomo_full"
    )

    folder = clean_name(
        folder,
        "Akbar98",
    )

    name = re.sub(
        r'[\\/:*?"<>|]+',
        "_",
        name,
    ).strip()

    if not name:
        name = "mihomo_full"

    if not name.endswith(".yaml"):
        name += ".yaml"

    return DOWNLOAD_DIR / folder / name


def main() -> None:
    log("=" * 72)
    log(ENGINE_VERSION)
    log("FULL OUTBOUND + GROUP + PROVIDER ENGINE")
    log(
        "NO automatic ping / DNS probe / TCP probe / "
        "download test"
    )
    log("=" * 72)

    try:
        open_editor()

        text = load_input()

        if not text.strip():
            log(
                "[ERROR] input.txt is empty. "
                "Nothing generated."
            )
            return

        raw_count = len(
            [
                line
                for line in text.splitlines()
                if line.strip()
            ]
        )

        nodes = parse_all(text)

        if len(nodes) > MAX_NODES:
            nodes = nodes[:MAX_NODES]

        before = len(nodes)
        nodes = dedupe(nodes)
        removed = before - len(nodes)

        unique_names(nodes)

        log(
            f"[PARSE] lines={raw_count} "
            f"nodes={len(nodes)} deduped={removed}"
        )

        valid: list[dict[str, Any]] = []
        invalid = 0

        for node_data in nodes:
            if not validate_node(node_data):
                valid.append(node_data)
            else:
                invalid += 1

        log(
            f"[VALIDATE] valid={len(valid)} "
            f"invalid={invalid}"
        )

        if not valid:
            log(
                "[ERROR] No valid supported nodes found. "
                "Input preserved."
            )
            return

        config = build_config(
            valid,
            text,
        )

        errors = validate_config(config)

        if errors:
            log(
                "[ERROR] FINAL CONFIG VALIDATION FAILED:"
            )

            for error in errors[:60]:
                log("  - " + error)

            return

        yaml_text = (
            "# Generated by "
            "MIHOMO FULL INDUSTRIAL ENGINE V7\n"
            + "\n".join(yaml_dump(config))
            + "\n"
        )

        yaml_errors = validate_yaml_text(
            yaml_text
        )

        if yaml_errors:
            log(
                "[ERROR] SERIALIZED YAML "
                "VALIDATION FAILED:"
            )

            for error in yaml_errors[:60]:
                log("  - " + error)

            return

        path = output_path()

        atomic_write(
            path,
            yaml_text,
        )

        # If a Mihomo binary is installed locally, validate the exact file.
        # This is syntax/config validation only, not a network health test.
        mihomo = (
            shutil.which("mihomo")
            or shutil.which("clash-meta")
        )

        if mihomo:
            try:
                result = subprocess.run(
                    [
                        mihomo,
                        "-t",
                        "-f",
                        str(path),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )

                if result.returncode != 0:
                    log(
                        "[WARN] Mihomo binary rejected "
                        "the generated config:"
                    )
                    log(
                        (
                            result.stderr
                            or result.stdout
                            or "unknown error"
                        ).strip()[:5000]
                    )
                    log(
                        "[WARN] Output kept for inspection; "
                        "input NOT cleared."
                    )
                    return

                log(
                    "[MIHOMO] native config test: OK"
                )

            except Exception as exc:
                log(
                    f"[WARN] native test skipped: {exc}"
                )

        clear_input()

        log("=" * 72)
        log("SUCCESS")
        log(f"YAML: {path}")
        log(f"NODES: {len(valid)}")
        log(
            "GROUPS: Select🔰 + Auto⚡ + "
            "Fallback🛡 + Balance⚖"
        )

        if ENABLE_LEGACY_RELAY:
            log("LEGACY RELAY: enabled")

        log(
            "Input cleared for next run."
        )
        log("=" * 72)

    except KeyboardInterrupt:
        log(
            "\n[STOP] Cancelled; "
            "input was NOT cleared."
        )

    except Exception as exc:
        log(
            f"[FATAL] {type(exc).__name__}: {exc}"
        )
        log(
            "Input was NOT cleared because "
            "output was not safely completed."
        )


if __name__ == "__main__":
    main()
