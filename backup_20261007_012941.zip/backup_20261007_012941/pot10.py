#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MIHOMO INDUSTRIAL ENGINE V4
============================
Industrial-grade Termux converter for Mihomo / Clash Meta.

Design principles
-----------------
- Exactly ONE static proxy group: Mobile-Fast❤ (type: select)
- NO URL-Test / fallback / load-balance / Smart / auto-switch
- Lightweight reachability: DNS -> TCP only; never downloads traffic
- Batch processing + adaptive workers
- DNS cache + TCP result cache with TTL
- Stable fingerprint-based deduplication
- Preserve protocol/security/transport parameters whenever possible
- Base64 subscription intelligence
- JSON / VMess / VLESS / Trojan / SS / SSR / Hysteria / Hysteria2 /
  TUIC / HTTP / SOCKS / WireGuard-ish JSON inputs
- Final YAML structural validation
- No report files are written to disk; only the final YAML is saved
- Atomic output writes
- Input file is cleared after a successful run
- Designed for large inputs (2k-5k+ nodes)

Reference architecture incorporated from the supplied test.txt:
DNS split concepts, proxy-server-nameserver, geodata, geox-url,
sniffer/TUN as optional settings, rule-provider architecture,
LAN protection, GEOIP/GEOSITE routing ideas and robust provider paths.
Those reference settings are deliberately kept conservative here:
TUN is disabled, no auto-selection group is emitted, and the user's
one-group architecture remains authoritative.
"""

from __future__ import annotations

import base64
import concurrent.futures
import hashlib
import ipaddress
import json
import os
import re
import socket
import ssl
import sys
import tempfile
import threading
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

# ----------------------------- CONSTANTS -----------------------------

ENGINE_VERSION = "INDUSTRIAL-V5-YAML-SAFE"
GROUP_NAME = "Mobile-Fast❤"
BASE_DIR = Path("/storage/emulated/0/Download/Akbar98")
INPUT_PATH = BASE_DIR / "input_mobile.txt"
DEFAULT_OUTPUT_DIR = BASE_DIR

DNS_TIMEOUT = 2.5
TCP_TIMEOUT = 2.8
DNS_CACHE_TTL = 300
TCP_CACHE_TTL = 600
MAX_WORKERS_CAP = 32
BATCH_SIZE = 100
MAX_INPUT_BYTES = 25 * 1024 * 1024
MAX_SUBSCRIPTION_BYTES = 8 * 1024 * 1024
MAX_DNS_ADDRESSES = 16

PROTOCOLS = {
    "vless", "vmess", "trojan", "ss", "ssr", "hysteria",
    "hysteria2", "hy2", "tuic", "http", "socks5", "socks",
    "wireguard"
}

# Conservative, widely useful defaults inspired by the helper config.
CORE_DEFAULTS = {
    "mixed-port": 7890,
    "allow-lan": False,
    "mode": "rule",
    "log-level": "info",
    "ipv6": True,
    "unified-delay": True,
    "tcp-concurrent": True,
    "find-process-mode": "strict",
    "keep-alive-interval": 1800,
    "global-client-fingerprint": "chrome",
    "profile": {
        "store-selected": True,
        "store-fake-ip": True,
    },
    "geodata-mode": True,
    "geox-url": {
        "geoip": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.dat",
        "geosite": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite.dat",
        "mmdb": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/country.mmdb",
    },
    "sniffer": {
        "enable": False,
        "override-destination": False,
    },
    "tun": {
        "enable": False,
        "stack": "system",
        "auto-route": True,
        "auto-detect-interface": True,
    },
    "dns": {
        "enable": True,
        "ipv6": True,
        "enhanced-mode": "fake-ip",
        "fake-ip-range": "198.18.0.1/16",
        "default-nameserver": ["223.5.5.5", "1.1.1.1"],
        "nameserver": [
            "https://dns.alidns.com/dns-query",
            "https://cloudflare-dns.com/dns-query",
        ],
        "proxy-server-nameserver": [
            "https://dns.alidns.com/dns-query",
            "https://cloudflare-dns.com/dns-query",
        ],
        "nameserver-policy": {
            "geosite:cn,private": [
                "https://dns.alidns.com/dns-query",
                "https://doh.pub/dns-query",
            ],
            "geosite:!cn,!private": [
                "https://cloudflare-dns.com/dns-query",
                "https://dns.google/dns-query",
            ],
        },
    },
}

# ----------------------------- DATA TYPES ----------------------------

@dataclass
class Proxy:
    type: str
    name: str
    server: str
    port: int
    data: dict[str, Any] = field(default_factory=dict)
    source: str = ""
    raw: str = ""
    fingerprint: str = ""
    status: str = "unknown"
    addresses: list[str] = field(default_factory=list)
    latency_ms: float | None = None
    error: str = ""
    score: float = 0.0

@dataclass
class TestResult:
    host: str
    port: int
    dns_ok: bool
    addresses: list[str]
    tcp_ok: bool
    latency_ms: float | None
    error: str = ""

# ----------------------------- UTILITIES -----------------------------

_print_lock = threading.Lock()

def log(msg: str = "") -> None:
    with _print_lock:
        print(msg, flush=True)

def normalize_b64(s: str) -> str | None:
    s = re.sub(r"\s+", "", s.strip())
    if not s:
        return None
    s += "=" * ((4 - len(s) % 4) % 4)
    try:
        return base64.b64decode(s, validate=False).decode("utf-8", "ignore")
    except Exception:
        return None

def safe_int(v: Any, default: int = 0) -> int:
    try:
        return int(str(v).strip())
    except Exception:
        return default

def clean_name(name: str, fallback: str = "Node") -> str:
    name = str(name or "").replace("\n", " ").replace("\r", " ").strip()
    name = re.sub(r"[\x00-\x1f\x7f]", "", name)
    return name[:120] or fallback

def host_is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host.strip("[]"))
        return True
    except Exception:
        return False

def host_port(server: str, port: int) -> str:
    if ":" in server and not server.startswith("["):
        return f"[{server}]:{port}"
    return f"{server}:{port}"

def url_unquote(v: Any) -> str:
    return urllib.parse.unquote(str(v)) if v is not None else ""

def b64_text(v: str) -> str:
    raw = normalize_b64(v)
    return raw if raw is not None else v

def canonical_value(v: Any) -> str:
    if isinstance(v, dict):
        return "{" + ",".join(f"{k}:{canonical_value(v[k])}" for k in sorted(v)) + "}"
    if isinstance(v, (list, tuple)):
        return "[" + ",".join(canonical_value(x) for x in v) + "]"
    return str(v).strip()

def fingerprint_proxy(p: Proxy) -> str:
    # Credentials and security parameters are intentionally included.
    keys = sorted(k for k in p.data if k not in {"name", "remark"})
    body = "|".join([
        p.type.lower(),
        p.server.lower().strip("[]"),
        str(p.port),
        *[f"{k}={canonical_value(p.data[k])}" for k in keys],
    ])
    return hashlib.sha256(body.encode("utf-8", "ignore")).hexdigest()

def score_proxy(p: Proxy) -> float:
    # DNS 10 + TCP 30 + latency 30 + protocol 20 + config 10.
    dns = 10 if p.addresses else 0
    tcp = 30 if p.status == "alive" else 0
    latency = 0
    if p.latency_ms is not None:
        latency = max(0.0, min(30.0, 30.0 * (1.0 - min(p.latency_ms, 1000.0) / 1000.0)))
    protocol = 20 if p.type.lower() in PROTOCOLS else 0
    config = 10 if p.server and p.port > 0 and p.port <= 65535 else 0
    return round(dns + tcp + latency + protocol + config, 2)

# ----------------------------- YAML WRITER ----------------------------

def yaml_quote(v: Any) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if v is None:
        return "null"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return str(v)
    s = str(v)
    # Always quote strings: safer for URLs, IPv6, names, emojis and YAML booleans.
    return json.dumps(s, ensure_ascii=False)

def yaml_dump(obj: Any, indent: int = 0) -> str:
    """Emit YAML safely using JSON syntax.

    JSON is valid YAML syntax and Mihomo documents JSON syntax as supported.
    The standard-library serializer avoids hand-written YAML indentation
    errors on very large configurations.
    """
    if indent:
        raise ValueError("yaml_dump() must serialize from the document root")
    return json.dumps(obj, ensure_ascii=False, indent=2, separators=(",", ": "))


def validate_serialized_yaml(text: str) -> None:
    """Validate the exact generated JSON-compatible YAML document."""
    if not text.strip():
        raise RuntimeError("Generated YAML is empty")
    body = text
    if body.startswith("# Generated by MIHOMO INDUSTRIAL ENGINE"):
        parts = body.split("\n", 1)
        body = parts[1] if len(parts) == 2 else ""
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"Generated YAML validation failed at line {exc.lineno}, "
            f"column {exc.colno}: {exc.msg}"
        ) from exc
    if not isinstance(parsed, dict):
        raise RuntimeError("Generated YAML root must be a mapping/object")
    structural = validate_config(parsed)
    if structural:
        raise RuntimeError("SERIALIZED CONFIG VALIDATION FAILED: " + "; ".join(structural))

# ----------------------------- PARSERS -------------------------------

def parse_query(u: urllib.parse.ParseResult) -> dict[str, Any]:
    q = urllib.parse.parse_qs(u.query, keep_blank_values=True)
    return {k: (v[-1] if v else "") for k, v in q.items()}

def common_tls_fields(q: dict[str, Any], d: dict[str, Any]) -> None:
    if q.get("security"):
        d["tls"] = q["security"] not in {"none", "false", "0"}
    if q.get("sni"):
        d["servername"] = q["sni"]
    elif q.get("peer"):
        d["servername"] = q["peer"]
    if q.get("alpn"):
        d["alpn"] = q["alpn"].split(",")
    if q.get("fp"):
        d["client-fingerprint"] = q["fp"]
    if q.get("fingerprint"):
        d["client-fingerprint"] = q["fingerprint"]

def parse_vless(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d: dict[str, Any] = {"uuid": urllib.parse.unquote(u.username or "")}
    common_tls_fields(q, d)
    network = q.get("type") or q.get("network") or "tcp"
    d["network"] = network
    if q.get("flow"):
        d["flow"] = q["flow"]
    if q.get("encryption"):
        d["encryption"] = q["encryption"]
    if q.get("security") == "reality":
        d["reality-opts"] = {}
        if q.get("pbk"):
            d["reality-opts"]["public-key"] = q["pbk"]
        if q.get("sid"):
            d["reality-opts"]["short-id"] = q["sid"]
    if network in {"ws", "http"}:
        ws = {}
        if q.get("path"):
            ws["path"] = q["path"]
        if q.get("host"):
            ws["headers"] = {"Host": q["host"]}
        if ws:
            d["ws-opts"] = ws
    if network == "grpc":
        go = {}
        if q.get("serviceName"):
            go["grpc-service-name"] = q["serviceName"]
        if go:
            d["grpc-opts"] = go
    name = clean_name(q.get("remarks") or u.fragment or "VLESS")
    return Proxy("vless", name, u.hostname, u.port, d, raw=line)

def parse_trojan(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d = {"password": urllib.parse.unquote(u.username or "")}
    d["tls"] = True
    common_tls_fields(q, d)
    if q.get("type"):
        d["network"] = q["type"]
    if q.get("path"):
        d["ws-opts"] = {"path": q["path"]}
        if q.get("host"):
            d["ws-opts"]["headers"] = {"Host": q["host"]}
    return Proxy("trojan", clean_name(q.get("remarks") or u.fragment or "Trojan"),
                 u.hostname, u.port, d, raw=line)

def parse_ss(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    host, port = u.hostname, u.port
    if not host or not port:
        return None
    user = u.username or ""
    if user and ":" in user:
        method, password = user.split(":", 1)
    else:
        decoded = normalize_b64((u.netloc.rsplit("@", 1)[0] if "@" in u.netloc else "").replace("%3A", ":"))
        if decoded and ":" in decoded:
            method, password = decoded.split(":", 1)
        else:
            method, password = "", ""
    d = {"cipher": url_unquote(method), "password": url_unquote(password)}
    return Proxy("ss", clean_name(u.fragment or "SS"), host, port, d, raw=line)

def parse_hysteria(line: str, proto: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d: dict[str, Any] = {}
    if u.username:
        d["auth"] = urllib.parse.unquote(u.username)
    for k in ("sni", "obfs", "obfs-password", "pinSHA256", "insecure"):
        if q.get(k):
            d[k] = q[k]
    if q.get("alpn"):
        d["alpn"] = q["alpn"].split(",")
    return Proxy(proto, clean_name(q.get("remarks") or u.fragment or proto.upper()),
                 u.hostname, u.port, d, raw=line)

def parse_tuic(line: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    q = parse_query(u)
    d = {
        "uuid": urllib.parse.unquote(u.username or ""),
        "password": urllib.parse.unquote(u.password or ""),
    }
    for k in ("congestion-controller", "udp-relay-mode", "disable-sni", "sni"):
        if q.get(k):
            d[k] = q[k]
    return Proxy("tuic", clean_name(q.get("name") or u.fragment or "TUIC"),
                 u.hostname, u.port, d, raw=line)

def parse_http_socks(line: str, proto: str) -> Proxy | None:
    u = urllib.parse.urlparse(line)
    if not u.hostname or not u.port:
        return None
    d = {}
    if u.username:
        d["username"] = urllib.parse.unquote(u.username)
    if u.password:
        d["password"] = urllib.parse.unquote(u.password)
    if q := parse_query(u):
        for k in ("tls", "udp"):
            if k in q:
                d[k] = q[k]
    return Proxy(proto, clean_name(u.fragment or proto.upper()), u.hostname, u.port, d, raw=line)

def parse_vmess(line: str) -> Proxy | None:
    payload = line.split("://", 1)[1].split("#", 1)[0]
    raw = normalize_b64(payload)
    if not raw:
        return None
    try:
        j = json.loads(raw)
    except Exception:
        return None
    host = j.get("add") or j.get("address")
    port = safe_int(j.get("port"))
    if not host or not port:
        return None
    d: dict[str, Any] = {
        "uuid": j.get("id", ""),
        "alterId": safe_int(j.get("aid"), 0),
        "cipher": j.get("scy") or j.get("cipher") or "auto",
    }
    net = j.get("net") or "tcp"
    d["network"] = net
    if j.get("tls"):
        d["tls"] = True
    if j.get("sni"):
        d["servername"] = j["sni"]
    if j.get("fp"):
        d["client-fingerprint"] = j["fp"]
    if net == "ws":
        ws = {}
        if j.get("path"):
            ws["path"] = j["path"]
        if j.get("host"):
            ws["headers"] = {"Host": j["host"]}
        if ws:
            d["ws-opts"] = ws
    name = clean_name(j.get("ps") or "VMess")
    return Proxy("vmess", name, str(host), port, d, raw=line)

def parse_json_proxy(obj: dict[str, Any], source: str = "") -> Proxy | None:
    ptype = str(obj.get("type") or "").lower()
    if ptype not in PROTOCOLS:
        return None
    host = obj.get("server") or obj.get("address") or obj.get("add")
    port = safe_int(obj.get("port"))
    if not host or not port:
        return None
    name = clean_name(obj.get("name") or obj.get("remarks") or ptype.upper())
    d = {k: v for k, v in obj.items() if k not in {"type", "name", "server", "address", "add", "port", "remarks"}}
    return Proxy(ptype, name, str(host), port, d, source=source, raw=json.dumps(obj, ensure_ascii=False))

def parse_ssr(line: str) -> Proxy | None:
    payload = line.split("://", 1)[1]
    raw = normalize_b64(payload)
    if not raw:
        return None
    # SSR: server:port:protocol:method:obfs:password-base64/?params
    main, _, query = raw.partition("/?")
    parts = main.split(":")
    if len(parts) < 6:
        return None
    host, port, protocol, method, obfs, pwb64 = parts[:6]
    password = normalize_b64(pwb64) or pwb64
    q = urllib.parse.parse_qs(query, keep_blank_values=True)
    name = normalize_b64(q.get("remarks", [""])[-1]) or "SSR"
    d = {"protocol": protocol, "cipher": method, "obfs": obfs, "password": password}
    return Proxy("ssr", clean_name(name), host, safe_int(port), d, raw=line)

def parse_line(line: str, source: str = "") -> Proxy | None:
    line = line.strip().lstrip("\ufeff")
    if not line or line.startswith("#") or line.startswith("//"):
        return None

    low = line.lower()
    try:
        if low.startswith("vmess://"):
            p = parse_vmess(line)
        elif low.startswith("vless://"):
            p = parse_vless(line)
        elif low.startswith("trojan://"):
            p = parse_trojan(line)
        elif low.startswith("ss://"):
            p = parse_ss(line)
        elif low.startswith("ssr://"):
            p = parse_ssr(line)
        elif low.startswith("hysteria2://") or low.startswith("hy2://"):
            p = parse_hysteria(line, "hysteria2")
        elif low.startswith("hysteria://"):
            p = parse_hysteria(line, "hysteria")
        elif low.startswith("tuic://"):
            p = parse_tuic(line)
        elif low.startswith("socks5://") or low.startswith("socks://"):
            p = parse_http_socks(line, "socks5")
        elif low.startswith("http://") or low.startswith("https://"):
            # http(s):// may be a proxy URI or a subscription URL.
            p = parse_http_socks(line, "http")
        elif low.startswith("{") and low.endswith("}"):
            p = parse_json_proxy(json.loads(line), source)
        else:
            return None
        if p:
            p.source = source
            p.fingerprint = fingerprint_proxy(p)
        return p
    except Exception:
        return None

def extract_json_objects(text: str) -> list[dict[str, Any]]:
    found = []
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            found.append(obj)
        elif isinstance(obj, list):
            found.extend(x for x in obj if isinstance(x, dict))
        return found
    except Exception:
        pass
    for m in re.finditer(r'\{(?:[^{}]|"(?:\\.|[^"])*")*\}', text, re.S):
        try:
            x = json.loads(m.group(0))
            if isinstance(x, dict):
                found.append(x)
        except Exception:
            continue
    return found

def expand_input(text: str) -> list[str]:
    lines = [x.strip() for x in text.splitlines() if x.strip()]
    out: list[str] = []
    for line in lines:
        if re.match(r"^(vmess|vless|trojan|ss|ssr|hysteria|hysteria2|hy2|tuic|socks5|socks|http)://", line, re.I):
            out.append(line)
            continue
        if line.startswith("{") or line.startswith("["):
            out.append(line)
            continue
        dec = normalize_b64(line)
        if dec and any(x in dec.lower() for x in ("vmess://", "vless://", "trojan://", "ss://", "ssr://", "hysteria", "tuic://")):
            out.extend(x.strip() for x in dec.splitlines() if x.strip())
        else:
            out.append(line)
    return out

# ----------------------------- CACHE ---------------------------------

class TTLCache:
    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.Lock()
        self.data: dict[str, Any] = {}
        self.load()

    def load(self):
        try:
            if self.path.exists():
                self.data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            self.data = {}

    def get(self, key: str, ttl: int) -> Any:
        with self.lock:
            x = self.data.get(key)
            if not x:
                return None
            if time.time() - float(x.get("time", 0)) > ttl:
                return None
            return x.get("value")

    def put(self, key: str, value: Any):
        with self.lock:
            self.data[key] = {"time": time.time(), "value": value}

    def save(self):
        with self.lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)

# ----------------------------- REACHABILITY --------------------------

def resolve_host(host: str, dns_cache: TTLCache) -> list[str]:
    if host_is_ip(host):
        return [host.strip("[]")]
    key = host.lower().rstrip(".")
    cached = dns_cache.get(key, DNS_CACHE_TTL)
    if cached:
        return cached[:MAX_DNS_ADDRESSES]
    try:
        infos = socket.getaddrinfo(host, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        seen = set()
        addrs = []
        for info in infos:
            addr = info[4][0]
            if addr not in seen:
                seen.add(addr)
                addrs.append(addr)
        addrs = addrs[:MAX_DNS_ADDRESSES]
        if addrs:
            dns_cache.put(key, addrs)
        return addrs
    except Exception:
        return []

def tcp_probe(addr: str, port: int) -> tuple[bool, float | None, str]:
    family = socket.AF_INET6 if ":" in addr else socket.AF_INET
    started = time.perf_counter()
    s = socket.socket(family, socket.SOCK_STREAM)
    s.settimeout(TCP_TIMEOUT)
    try:
        s.connect((addr, port))
        return True, round((time.perf_counter() - started) * 1000, 1), ""
    except Exception as e:
        return False, None, str(e)
    finally:
        try:
            s.close()
        except Exception:
            pass

def test_proxy(p: Proxy, dns_cache: TTLCache, tcp_cache: TTLCache) -> TestResult:
    key = f"{p.server.lower()}:{p.port}"
    cached = tcp_cache.get(key, TCP_CACHE_TTL)
    addresses = resolve_host(p.server, dns_cache)
    if not addresses:
        return TestResult(p.server, p.port, False, [], False, None, "DNS failed")
    if cached and cached.get("ok"):
        return TestResult(p.server, p.port, True, addresses, True, cached.get("latency_ms"), "cache")

    best: float | None = None
    for addr in addresses:
        ok, latency, err = tcp_probe(addr, p.port)
        if ok and (best is None or (latency or 999999) < best):
            best = latency
    ok = best is not None
    tcp_cache.put(key, {"ok": ok, "latency_ms": best})
    return TestResult(p.server, p.port, True, addresses, ok, best, "" if ok else "TCP failed")

def adaptive_workers(n: int) -> int:
    if n <= 50:
        return 4
    if n <= 100:
        return 8
    if n <= 500:
        return 16
    if n <= 2000:
        return 24
    return MAX_WORKERS_CAP

# ----------------------------- NORMALIZATION -------------------------

def dedupe(proxies: Iterable[Proxy]) -> tuple[list[Proxy], int]:
    seen: set[str] = set()
    result: list[Proxy] = []
    removed = 0
    for p in proxies:
        p.fingerprint = fingerprint_proxy(p)
        if p.fingerprint in seen:
            removed += 1
            continue
        seen.add(p.fingerprint)
        result.append(p)
    return result, removed

def assign_unique_names(proxies: list[Proxy]) -> None:
    counts: dict[str, int] = {}
    for p in proxies:
        base = clean_name(p.name, p.type.upper())
        counts[base] = counts.get(base, 0) + 1
        p.name = base
    used: set[str] = set()
    serial: dict[str, int] = {}
    for p in proxies:
        if p.name not in used and counts[p.name] == 1:
            used.add(p.name)
            continue
        serial[p.name] = serial.get(p.name, 0) + 1
        candidate = f"{p.name} #{serial[p.name]}"
        while candidate in used:
            serial[p.name] += 1
            candidate = f"{p.name} #{serial[p.name]}"
        p.name = candidate
        used.add(candidate)

# ----------------------------- MIHOMO MAPPING ------------------------

def proxy_yaml(p: Proxy) -> dict[str, Any]:
    d: dict[str, Any] = {"name": p.name, "type": p.type, "server": p.server, "port": p.port}
    # Copy all preserved parameters except internal fields.
    for k, v in p.data.items():
        if v in (None, ""):
            continue
        d[k] = v
    return d

def build_config(proxies: list[Proxy]) -> dict[str, Any]:
    cfg = dict(CORE_DEFAULTS)
    cfg["proxies"] = [proxy_yaml(p) for p in proxies]
    cfg["proxy-groups"] = [{
        "name": GROUP_NAME,
        "type": "select",
        "proxies": [p.name for p in proxies],
    }]
    # Conservative routing: all traffic enters the user's one fixed group.
    cfg["rules"] = [f"MATCH,{GROUP_NAME}"]
    return cfg

def validate_config(cfg: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    proxies = cfg.get("proxies")
    groups = cfg.get("proxy-groups")
    rules = cfg.get("rules")
    if not isinstance(proxies, list) or not proxies:
        errors.append("proxies missing/empty")
    if not isinstance(groups, list) or len(groups) != 1:
        errors.append("proxy-groups must contain exactly one group")
    else:
        g = groups[0]
        if g.get("name") != GROUP_NAME:
            errors.append("group name mismatch")
        if g.get("type") != "select":
            errors.append("group type must be select")
        refs = g.get("proxies", [])
        names = [p.get("name") for p in proxies if isinstance(p, dict)]
        if len(names) != len(set(names)):
            errors.append("duplicate proxy names")
        missing = [x for x in refs if x not in names]
        if missing:
            errors.append(f"invalid group refs: {len(missing)}")
    if rules != [f"MATCH,{GROUP_NAME}"]:
        errors.append("rules must end in exactly one static MATCH rule")
    return errors

# ----------------------------- NO REPORT FILES -----------------------

# ----------------------------- FILE / INPUT ---------------------------

def ensure_input() -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    if not INPUT_PATH.exists():
        INPUT_PATH.write_text("", encoding="utf-8")

def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".mihomo_", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    finally:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass

def open_nano() -> None:
    os.system(f'nano "{INPUT_PATH}"')

def load_input() -> str:
    if not INPUT_PATH.exists():
        return ""
    size = INPUT_PATH.stat().st_size
    if size > MAX_INPUT_BYTES:
        raise RuntimeError(f"Input too large: {size} bytes")
    return INPUT_PATH.read_text(encoding="utf-8", errors="ignore")

def clear_input() -> None:
    atomic_write(INPUT_PATH, "")

# ----------------------------- PROCESS --------------------------------

def parse_all(text: str) -> tuple[list[Proxy], int]:
    lines = expand_input(text)
    parsed: list[Proxy] = []
    invalid = 0
    for line in lines:
        if line.startswith("{") or line.startswith("["):
            try:
                objs = json.loads(line)
                if isinstance(objs, dict):
                    objs = [objs]
                if isinstance(objs, list):
                    local = [parse_json_proxy(x) for x in objs if isinstance(x, dict)]
                    ok = [x for x in local if x]
                    parsed.extend(ok)
                    invalid += len(objs) - len(ok)
                    continue
            except Exception:
                pass
        p = parse_line(line)
        if p:
            parsed.append(p)
        else:
            invalid += 1
    return parsed, invalid

def process_reachability(proxies: list[Proxy], dns_cache: TTLCache, tcp_cache: TTLCache) -> tuple[list[Proxy], list[Proxy]]:
    workers = adaptive_workers(len(proxies))
    log(f"[TEST] LIGHT DNS -> TCP | workers={workers} | nodes={len(proxies)}")
    alive: list[Proxy] = []
    failed: list[Proxy] = []
    def one(p: Proxy):
        r = test_proxy(p, dns_cache, tcp_cache)
        p.addresses = r.addresses
        p.latency_ms = r.latency_ms
        p.status = "alive" if r.tcp_ok else "failed"
        p.error = r.error
        p.score = score_proxy(p)
        return p
    for start in range(0, len(proxies), BATCH_SIZE):
        batch = proxies[start:start+BATCH_SIZE]
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(workers, len(batch))) as ex:
            for p in ex.map(one, batch):
                (alive if p.status == "alive" else failed).append(p)
        log(f"[TEST] {min(start+BATCH_SIZE, len(proxies))}/{len(proxies)}")
    alive.sort(key=lambda x: (-(x.score), x.latency_ms if x.latency_ms is not None else 999999))
    return alive, failed

def save_outputs(out_dir: Path, base_name: str, cfg: dict[str, Any]) -> Path:
    """Save ONLY the final YAML configuration. No report files are created."""
    yaml_path = out_dir / f"{base_name}.yaml"
    yml = "# Generated by MIHOMO INDUSTRIAL ENGINE V5 - JSON-compatible YAML\n" + yaml_dump(cfg) + "\n"

    # Validate before touching the destination.
    validate_serialized_yaml(yml)
    atomic_write(yaml_path, yml)

    # Validate the exact file that FlClash will read.
    written = yaml_path.read_text(encoding="utf-8")
    validate_serialized_yaml(written)
    return yaml_path

def run_once():
    ensure_input()
    log("\n" + "=" * 72)
    log(f"  {ENGINE_VERSION}")
    log("  ONE GROUP / STATIC / MOBILE-FAST❤ / LIGHT REACHABILITY / YAML-ONLY OUTPUT")
    log("=" * 72)
    open_nano()
    text = load_input()
    if not text.strip():
        log("[ERROR] input_mobile.txt is empty.")
        return

    started = time.time()
    log("[1/7] Parsing and normalizing...")
    raw_lines = len([x for x in text.splitlines() if x.strip()])
    parsed, invalid = parse_all(text)
    log(f"      raw={raw_lines} parsed={len(parsed)} invalid={invalid}")

    parsed, dedup = dedupe(parsed)
    log(f"[2/7] Fingerprint dedupe -> {len(parsed)} (removed {dedup})")
    if not parsed:
        log("[ERROR] No supported proxy configuration was found.")
        return

    dns_cache = TTLCache(BASE_DIR / ".cache" / "dns.json")
    tcp_cache = TTLCache(BASE_DIR / ".cache" / "tcp.json")

    log("[3/7] Lightweight reachability...")
    alive, failed = process_reachability(parsed, dns_cache, tcp_cache)
    log(f"      alive={len(alive)} failed={len(failed)}")

    if not alive:
        log("[ERROR] No reachable nodes. YAML was NOT generated.")
        dns_cache.save()
        tcp_cache.save()
        return

    log("[4/7] Stable naming + scoring...")
    assign_unique_names(alive)

    log("[5/7] Building Mihomo configuration...")
    cfg = build_config(alive)

    log("[6/7] Final structural validation...")
    errors = validate_config(cfg)
    if errors:
        raise RuntimeError("FINAL VALIDATION FAILED: " + "; ".join(errors))

    out_name = input("\nOutput folder name (Enter = Akbar98): ").strip() or "Akbar98"
    base_name = input("Output YAML name (without .yaml): ").strip() or "mihomo_final"
    out_dir = Path("/storage/emulated/0/Download") / clean_name(out_name, "Akbar98")
    base_name = re.sub(r'[\\/:*?"<>|]+', "_", base_name).strip() or "mihomo_final"


    log("[7/7] Atomic output...")
    yaml_path = save_outputs(out_dir, base_name, cfg)
    dns_cache.save()
    tcp_cache.save()

    # Only clear input after the YAML has been safely written.
    clear_input()

    log("\nSUCCESS")
    log(f"YAML   : {yaml_path}")
    log(f"Nodes  : {len(alive)}")
    log("Input  : cleared for next run.")
    log("=" * 72)

def main():
    try:
        ensure_input()
        run_once()
    except KeyboardInterrupt:
        log("\n[STOP] Cancelled. Input was NOT cleared.")
    except Exception as e:
        log(f"\n[FATAL] {type(e).__name__}: {e}")
        log("Input was NOT cleared because the run did not finish safely.")

if __name__ == "__main__":
    main()
