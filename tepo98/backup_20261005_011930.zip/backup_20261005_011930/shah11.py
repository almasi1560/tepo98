#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
"""
Ultra Industrial Clash Meta / Mihomo Parser
===========================================

Single replacement script for Android/Termux.

Design goals
------------
- Large inputs: suitable for thousands of nodes (tested architecture for 2,000–5,000+).
- Real parsing only: no fabricated/fake nodes or fake latency.
- Protocols:
  VLESS, VMess, Trojan, Shadowsocks, SSR, Hysteria, Hysteria2,
  TUIC, WireGuard, HTTP, SOCKS4/SOCKS5.
- Input containers:
  raw URI lines, Base64 subscriptions, JSON, YAML/Clash/Mihomo,
  Xray-style outbounds, sing-box-ish outbounds, WireGuard text.
- Validation:
  structural validation, hostname/IP validation, port validation,
  optional DNS resolution, TCP reachability.
- Test modes:
  LIGHT (default), NORMAL, DEEP.
  Tests are manual only. There is NO background loop, URL-test,
  fallback interval, repeated automatic traffic, or periodic probing.
- Caching:
  persistent DNS cache + in-process result cache with TTL.
- Deduplication:
  semantic endpoint/credential deduplication, then final name cleanup.
- Reports:
  main .yaml, failed.txt, unknown.txt, report.txt.
- Output:
  real YAML with `proxies`, one manual `proxy-groups` select group,
  and a conservative `rules` section.
"""

import os
import sys
import re
import json
import time
import socket
import base64
import hashlib
import ipaddress
import ssl
import subprocess
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote, unquote_plus
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import yaml
except ImportError:
    print("[FATAL] PyYAML is required.")
    print("Install once in Termux with: pip install pyyaml")
    sys.exit(1)


# ============================================================================
# CONFIGURATION
# ============================================================================

BASE_DIR = "/storage/emulated/0/Download/ClashMetaParser"
INPUT_PATH = os.path.join(BASE_DIR, "input_mobile.txt")
CACHE_PATH = os.path.join(BASE_DIR, "industrial_cache.json")

DEFAULT_OUT_FOLDER = "ClashMetaIndustrial"
DEFAULT_OUT_FILE = "proxies"

MAX_WORKERS = 40
DNS_WORKERS = 24

DNS_TTL_SECONDS = 1800
RESULT_TTL_SECONDS = 300

LIGHT_TIMEOUT = 0.45
NORMAL_TIMEOUT = 0.80
DEEP_TIMEOUT = 1.50

LIGHT_ATTEMPTS = 1
NORMAL_ATTEMPTS = 2
DEEP_ATTEMPTS = 3

MAX_INPUT_LINE = 2_000_000
MAX_DECODED_BUNDLE = 20_000_000

os.makedirs(BASE_DIR, exist_ok=True)


# ============================================================================
# GENERAL HELPERS
# ============================================================================

def now_ts():
    return int(time.time())


def safe_int(value, default=0):
    try:
        if value is None:
            return default
        return int(str(value).strip())
    except Exception:
        try:
            return int(float(value))
        except Exception:
            return default


def clean_text(value):
    if value is None:
        return ""
    return str(value).replace("\x00", "").strip()


def sanitize_name(value):
    value = unquote(str(value or ""))
    value = re.sub(r"[\r\n\t]+", " ", value)
    value = re.sub(r"[^\w .:@+\-/\[\]]+", "", value, flags=re.UNICODE)
    value = re.sub(r"\s+", " ", value).strip()
    return value[:180]


def b64fix(value):
    value = clean_text(value)
    value = value.replace("-", "+").replace("_", "/")
    return value + ("=" * (-len(value) % 4))


def b64decode_text(value):
    raw = base64.b64decode(
        b64fix(value),
        validate=False,
    )
    return raw.decode("utf-8", "ignore")


def b64encode_text(value):
    return base64.b64encode(value.encode("utf-8")).decode("ascii")


def maybe_percent_decode(value):
    try:
        return unquote(value)
    except Exception:
        return value


def is_base64_candidate(value):
    value = clean_text(value)
    if len(value) < 12:
        return False
    if "://" in value:
        return False
    if re.search(r"[^A-Za-z0-9+/_=\-]", value):
        return False
    try:
        decoded = b64decode_text(value)
        if not decoded:
            return False
        printable = sum(1 for c in decoded if c.isprintable() or c in "\r\n\t")
        return printable / max(1, len(decoded)) > 0.80
    except Exception:
        return False


def tail(value, n=8):
    value = re.sub(r"[^A-Za-z0-9]", "", str(value or ""))
    return value[-n:] if value else ""


def normalize_host(host):
    host = clean_text(host)
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    return host.strip().lower()


def split_host_port(value, default_port=None):
    """
    Correctly handles:
      example.com:443
      1.2.3.4:443
      [2001:db8::1]:443
      2001:db8::1  (no port)
    """
    value = clean_text(value)

    if value.startswith("["):
        end = value.find("]")
        if end >= 0:
            host = value[1:end]
            rest = value[end + 1:]
            if rest.startswith(":"):
                return normalize_host(host), safe_int(rest[1:], default_port)
            return normalize_host(host), default_port

    # IPv6 without brackets.
    try:
        ipaddress.IPv6Address(value)
        return normalize_host(value), default_port
    except Exception:
        pass

    if value.count(":") == 1:
        host, port = value.rsplit(":", 1)
        if port.isdigit():
            return normalize_host(host), safe_int(port, default_port)

    return normalize_host(value), default_port


def host_port_from_url(parsed, default_port=None):
    try:
        host = parsed.hostname
    except Exception:
        host = None
    try:
        port = parsed.port
    except Exception:
        port = None
    return normalize_host(host), (port or default_port)


def query_dict(query):
    result = {}
    for key, values in parse_qs(query, keep_blank_values=True).items():
        if not values:
            result[key] = ""
        else:
            result[key] = values[-1]
    return result


def first_nonempty(mapping, *keys, default=""):
    for key in keys:
        value = mapping.get(key)
        if value not in (None, ""):
            return value
    return default


def parse_bool(value):
    return str(value or "").strip().lower() in {
        "1", "true", "yes", "on", "tls", "enabled"
    }


# ============================================================================
# NAME MANAGER
# ============================================================================

class NameManager:
    def __init__(self):
        self.used = set()

    def unique(self, base):
        base = sanitize_name(base) or "Proxy"
        candidate = base
        index = 2
        while candidate in self.used:
            candidate = f"{base} {index}"
            index += 1
        self.used.add(candidate)
        return candidate


NAME_MANAGER = NameManager()


# ============================================================================
# PROXY MODEL HELPERS
# ============================================================================

KNOWN_TYPES = {
    "vless", "vmess", "trojan", "ss", "ssr",
    "hysteria", "hysteria2", "tuic", "wireguard",
    "http", "socks5", "socks4"
}

KNOWN_URI_SCHEMES = {
    "vless", "vmess", "trojan", "ss", "ssr",
    "hy", "hysteria", "hy2", "hysteria2", "tuic",
    "wg", "wireguard", "http", "https",
    "socks", "socks5", "socks4"
}


def new_proxy(name, ptype, server, port):
    return {
        "name": NAME_MANAGER.unique(name),
        "type": ptype,
        "server": normalize_host(server),
        "port": safe_int(port),
    }


def add_common_transport(proxy, q):
    network = first_nonempty(q, "type", "network", default="")
    if network:
        proxy["network"] = network.lower()

    if parse_bool(q.get("udp")):
        proxy["udp"] = True

    if parse_bool(q.get("tfo")):
        proxy["tfo"] = True

    if parse_bool(q.get("mptcp")):
        proxy["mptcp"] = True

    sni = first_nonempty(q, "sni", "servername", "serverName")
    if sni:
        proxy["servername"] = sni

    return proxy


def add_ws(proxy, q):
    path = q.get("path")
    host = first_nonempty(q, "host", "Host")

    if path is not None or host:
        opts = {"path": unquote(path or "/")}
        if host:
            opts["headers"] = {"Host": host}
        proxy["ws-opts"] = opts


def add_grpc(proxy, q):
    service = first_nonempty(q, "serviceName", "service", "grpc-service-name")
    if service:
        proxy["grpc-opts"] = {
            "grpc-service-name": service
        }


def add_tls(proxy, q, default_host=None):
    security = str(q.get("security") or "").lower()
    tls_value = q.get("tls")

    if security in {"tls", "reality"} or parse_bool(tls_value):
        proxy["tls"] = True

    sni = first_nonempty(q, "sni", "servername", "serverName", default=default_host or "")
    if sni:
        proxy["servername"] = sni

    if security == "reality" or q.get("pbk") or q.get("sid"):
        proxy["tls"] = True
        proxy["reality-opts"] = {
            "public-key": q.get("pbk", ""),
            "short-id": q.get("sid", ""),
        }
        if sni:
            proxy["reality-opts"]["server-name"] = sni


# ============================================================================
# URI PARSERS
# ============================================================================

def parse_vless(line):
    if not line.lower().startswith("vless://"):
        return None

    try:
        parsed = urlparse(line)
        host, port = host_port_from_url(parsed, 443)
        if not host:
            return None

        uuid = unquote(parsed.username or "")
        if not uuid:
            return None

        q = query_dict(parsed.query)
        name = unquote(parsed.fragment or "")
        proxy = new_proxy(
            name or f"VLESS-{host}-{tail(uuid)}",
            "vless", host, port
        )
        proxy["uuid"] = uuid
        proxy["encryption"] = q.get("encryption", "none")
        add_common_transport(proxy, q)
        add_tls(proxy, q, host)

        network = proxy.get("network", "tcp").lower()
        if network == "ws":
            add_ws(proxy, q)
        elif network == "grpc":
            add_grpc(proxy, q)

        # Reality / flow are valid Mihomo-related fields when supplied.
        if q.get("flow"):
            proxy["flow"] = q["flow"]

        return proxy
    except Exception:
        return None


def parse_vmess(line):
    if not line.lower().startswith("vmess://"):
        return None

    try:
        raw = line[8:].strip()
        decoded = None

        try:
            decoded = b64decode_text(raw)
            obj = json.loads(decoded)
        except Exception:
            obj = json.loads(unquote(raw))

        if not isinstance(obj, dict):
            return None

        host = first_nonempty(obj, "add", "address", "server")
        port = safe_int(first_nonempty(obj, "port", default="443"), 443)
        uuid = first_nonempty(obj, "id", "uuid")

        if not host or not uuid or not port:
            return None

        name = first_nonempty(obj, "ps", "name")
        proxy = new_proxy(
            name or f"VMESS-{host}-{tail(uuid)}",
            "vmess", host, port
        )
        proxy["uuid"] = uuid
        proxy["alterId"] = safe_int(first_nonempty(obj, "aid", "alterId", default=0))
        proxy["cipher"] = first_nonempty(obj, "scy", "cipher", default="auto")

        network = first_nonempty(obj, "net", "network", default="tcp").lower()
        proxy["network"] = network

        if str(obj.get("tls", "")).lower() in {"tls", "true", "1"}:
            proxy["tls"] = True

        sni = first_nonempty(obj, "sni", "servername", "host")
        if sni:
            proxy["servername"] = sni

        if network == "ws":
            proxy["ws-opts"] = {
                "path": obj.get("path") or "/"
            }
            if obj.get("host"):
                proxy["ws-opts"]["headers"] = {"Host": obj["host"]}

        if network == "grpc" and obj.get("path"):
            proxy["grpc-opts"] = {
                "grpc-service-name": obj["path"]
            }

        if obj.get("alpn"):
            alpn = obj["alpn"]
            proxy["alpn"] = alpn if isinstance(alpn, list) else str(alpn).split(",")

        return proxy
    except Exception:
        return None


def parse_trojan(line):
    if not line.lower().startswith("trojan://"):
        return None

    try:
        parsed = urlparse(line)
        host, port = host_port_from_url(parsed, 443)
        password = unquote(parsed.username or "")

        if not host or not password:
            return None

        q = query_dict(parsed.query)
        proxy = new_proxy(
            unquote(parsed.fragment or "") or f"Trojan-{host}-{port}",
            "trojan", host, port
        )
        proxy["password"] = password
        proxy["tls"] = True

        add_common_transport(proxy, q)

        sni = first_nonempty(q, "sni", "servername", default=host)
        proxy["sni"] = sni

        if q.get("security") == "reality":
            add_tls(proxy, q, host)

        network = proxy.get("network", "tcp").lower()
        if network == "ws":
            add_ws(proxy, q)
        elif network == "grpc":
            add_grpc(proxy, q)

        return proxy
    except Exception:
        return None


def parse_ss(line):
    if not line.lower().startswith("ss://"):
        return None

    try:
        body = line[5:]
        fragment = ""
        if "#" in body:
            body, fragment = body.split("#", 1)
            fragment = unquote(fragment)

        # Modern SIP002:
        # ss://BASE64(method:password)@host:port
        if "@" in body:
            userinfo, hostport = body.rsplit("@", 1)
            try:
                decoded_userinfo = b64decode_text(userinfo)
                if ":" in decoded_userinfo:
                    userinfo = decoded_userinfo
            except Exception:
                pass

            if ":" not in userinfo:
                return None

            cipher, password = userinfo.split(":", 1)
            host, port = split_host_port(hostport, 443)
        else:
            decoded = b64decode_text(body)
            if "@" not in decoded:
                return None
            userinfo, hostport = decoded.rsplit("@", 1)
            cipher, password = userinfo.split(":", 1)
            host, port = split_host_port(hostport, 443)

        if not host or not cipher or password == "":
            return None

        return {
            **new_proxy(fragment or f"SS-{host}-{port}", "ss", host, port),
            "cipher": cipher,
            "password": password,
            "udp": True,
        }
    except Exception:
        return None


def parse_ssr(line):
    if not line.lower().startswith("ssr://"):
        return None

    try:
        decoded = b64decode_text(line[6:])
        main, _, query = decoded.partition("/?")
        parts = main.split(":")

        if len(parts) < 6:
            return None

        host, port, protocol, method, obfs, password_b64 = parts[:6]
        password = b64decode_text(password_b64)

        q = query_dict(query)
        remarks = q.get("remarks", "")
        remarks = b64decode_text(remarks) if remarks else ""

        obfsparam = q.get("obfsparam", "")
        protoparam = q.get("protoparam", "")

        if obfsparam:
            try:
                obfsparam = b64decode_text(obfsparam)
            except Exception:
                pass

        if protoparam:
            try:
                protoparam = b64decode_text(protoparam)
            except Exception:
                pass

        proxy = new_proxy(
            remarks or f"SSR-{host}-{port}",
            "ssr", host, safe_int(port)
        )
        proxy.update({
            "protocol": protocol,
            "cipher": method,
            "obfs": obfs,
            "password": password,
        })

        if obfsparam:
            proxy["obfs-param"] = obfsparam
        if protoparam:
            proxy["protocol-param"] = protoparam

        return proxy
    except Exception:
        return None


def parse_hysteria1(line):
    if not (line.lower().startswith("hy://") or line.lower().startswith("hysteria://")):
        return None

    try:
        scheme_end = line.find("://")
        raw = line[scheme_end + 3:]

        fragment = ""
        if "#" in raw:
            raw, fragment = raw.split("#", 1)
            fragment = unquote(fragment)

        main, _, query = raw.partition("?")
        q = query_dict(query)

        if "@" in main:
            auth, hostport = main.rsplit("@", 1)
        else:
            auth, hostport = "", main

        host, port = split_host_port(hostport, 443)
        if not host:
            return None

        proxy = new_proxy(
            fragment or f"Hysteria-{host}-{port}",
            "hysteria", host, port
        )

        if auth:
            proxy["password"] = unquote(auth)

        if q.get("auth"):
            proxy["password"] = q["auth"]

        if q.get("sni"):
            proxy["sni"] = q["sni"]

        if q.get("alpn"):
            proxy["alpn"] = q["alpn"].split(",")

        if q.get("obfs"):
            proxy["obfs"] = q["obfs"]

        if q.get("obfs-password"):
            proxy["obfs-password"] = q["obfs-password"]

        return proxy
    except Exception:
        return None


def parse_hysteria2(line):
    if not (line.lower().startswith("hy2://") or line.lower().startswith("hysteria2://")):
        return None

    try:
        scheme_end = line.find("://")
        raw = line[scheme_end + 3:]

        fragment = ""
        if "#" in raw:
            raw, fragment = raw.split("#", 1)
            fragment = unquote(fragment)

        main, _, query = raw.partition("?")
        q = query_dict(query)

        if "@" in main:
            auth, hostport = main.rsplit("@", 1)
        else:
            auth, hostport = "", main

        host, port = split_host_port(hostport, 443)
        if not host:
            return None

        proxy = new_proxy(
            fragment or f"Hysteria2-{host}-{port}",
            "hysteria2", host, port
        )

        if auth:
            proxy["password"] = unquote(auth)

        if q.get("password"):
            proxy["password"] = q["password"]

        if q.get("sni"):
            proxy["sni"] = q["sni"]

        if q.get("alpn"):
            proxy["alpn"] = q["alpn"].split(",")

        if q.get("obfs"):
            proxy["obfs"] = q["obfs"]

        if q.get("obfs-password"):
            proxy["obfs-password"] = q["obfs-password"]

        if q.get("insecure"):
            proxy["skip-cert-verify"] = parse_bool(q["insecure"])

        return proxy
    except Exception:
        return None


def parse_tuic(line):
    if not line.lower().startswith("tuic://"):
        return None

    try:
        parsed = urlparse(line)
        host, port = host_port_from_url(parsed, 443)
        if not host:
            return None

        q = query_dict(parsed.query)
        uuid = unquote(parsed.username or "")
        password = unquote(parsed.password or "")

        # Some TUIC URLs use UUID:password in the user part.
        if not password and ":" in uuid:
            uuid, password = uuid.split(":", 1)

        if not uuid:
            return None

        proxy = new_proxy(
            unquote(parsed.fragment or "") or f"TUIC-{host}-{tail(uuid)}",
            "tuic", host, port
        )
        proxy["uuid"] = uuid
        proxy["password"] = password
        proxy["congestion-controller"] = q.get("congestion_control", q.get("congestion-controller", "bbr"))

        if q.get("alpn"):
            proxy["alpn"] = q["alpn"].split(",")
        else:
            proxy["alpn"] = ["h3"]

        proxy["sni"] = q.get("sni", host)

        if q.get("udp_relay_mode"):
            proxy["udp-relay-mode"] = q["udp_relay_mode"]

        if q.get("zero_rtt"):
            proxy["reduce-rtt"] = parse_bool(q["zero_rtt"])

        return proxy
    except Exception:
        return None


def parse_wireguard_uri(line):
    if not (line.lower().startswith("wg://") or line.lower().startswith("wireguard://")):
        return None

    try:
        parsed = urlparse(line)
        host, port = host_port_from_url(parsed, 51820)
        q = query_dict(parsed.query)

        public_key = unquote(parsed.username or "")
        private_key = q.get("privateKey", q.get("private_key", ""))
        address = q.get("address", "")

        if not host:
            return None

        proxy = new_proxy(
            unquote(parsed.fragment or "") or f"WireGuard-{host}",
            "wireguard", host, port
        )

        if public_key:
            proxy["public-key"] = public_key
        if private_key:
            proxy["private-key"] = private_key
        if address:
            proxy["ip"] = address

        if q.get("mtu"):
            proxy["mtu"] = safe_int(q["mtu"], 1280)

        if q.get("dns"):
            proxy["dns"] = q["dns"].split(",")

        if q.get("allowedIPs"):
            proxy["allowed-ips"] = q["allowedIPs"].split(",")

        return proxy
    except Exception:
        return None


def parse_wireguard_config(text):
    if "[Interface]" not in text or "[Peer]" not in text:
        return None

    try:
        interface = {}
        peer = {}

        section = None
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue

            if line.startswith("["):
                section = line.strip("[]").lower()
                continue

            key, value = [x.strip() for x in line.split("=", 1)]

            if section == "interface":
                interface[key.lower()] = value
            elif section == "peer":
                peer[key.lower()] = value

        endpoint = peer.get("endpoint", "")
        host, port = split_host_port(endpoint, 51820)
        if not host:
            return None

        proxy = new_proxy(
            f"WireGuard-{host}",
            "wireguard", host, port
        )

        if peer.get("publickey"):
            proxy["public-key"] = peer["publickey"]
        if interface.get("privatekey"):
            proxy["private-key"] = interface["privatekey"]
        if interface.get("address"):
            proxy["ip"] = interface["address"]
        if interface.get("dns"):
            proxy["dns"] = interface["dns"].split(",")
        if interface.get("mtu"):
            proxy["mtu"] = safe_int(interface["mtu"], 1280)
        if peer.get("allowedips"):
            proxy["allowed-ips"] = peer["allowedips"].split(",")

        return proxy
    except Exception:
        return None


def parse_http(line):
    if not line.lower().startswith(("http://", "https://")):
        return None

    try:
        parsed = urlparse(line)
        host, port = host_port_from_url(
            parsed,
            443 if parsed.scheme.lower() == "https" else 80
        )

        if not host:
            return None

        proxy = new_proxy(
            unquote(parsed.fragment or "") or f"HTTP-{host}-{port}",
            "http", host, port
        )

        if parsed.username:
            proxy["username"] = unquote(parsed.username)
        if parsed.password:
            proxy["password"] = unquote(parsed.password)

        if parsed.scheme.lower() == "https":
            proxy["tls"] = True

        return proxy
    except Exception:
        return None


def parse_socks(line):
    if not line.lower().startswith(("socks://", "socks5://", "socks4://")):
        return None

    try:
        parsed = urlparse(line)
        scheme = parsed.scheme.lower()
        ptype = "socks4" if scheme == "socks4" else "socks5"
        host, port = host_port_from_url(parsed, 1080)

        if not host:
            return None

        proxy = new_proxy(
            unquote(parsed.fragment or "") or f"{ptype.upper()}-{host}-{port}",
            ptype, host, port
        )

        if parsed.username:
            proxy["username"] = unquote(parsed.username)
        if parsed.password:
            proxy["password"] = unquote(parsed.password)

        return proxy
    except Exception:
        return None


# ============================================================================
# JSON / YAML PARSERS
# ============================================================================

def extract_balanced_json_objects(text):
    objects = []
    start = None
    depth = 0
    in_string = False
    escaped = False

    for index, char in enumerate(text):
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue

        if char == '"':
            in_string = True
            continue

        if char == "{":
            if depth == 0:
                start = index
            depth += 1
        elif char == "}":
            if depth > 0:
                depth -= 1
                if depth == 0 and start is not None:
                    objects.append(text[start:index + 1])
                    start = None

    return objects


def proxy_from_clash_dict(obj):
    if not isinstance(obj, dict):
        return None

    ptype = str(obj.get("type") or "").lower()
    server = obj.get("server")
    port = obj.get("port")

    if ptype not in KNOWN_TYPES or not server:
        return None

    if not safe_int(port):
        return None

    result = dict(obj)

    original_name = result.get("name") or f"{ptype}-{server}-{port}"
    result["name"] = NAME_MANAGER.unique(original_name)
    result["server"] = normalize_host(server)
    result["port"] = safe_int(port)

    return result


def parse_xray_outbounds(obj):
    results = []

    if not isinstance(obj, dict):
        return results

    outbounds = obj.get("outbounds")
    if isinstance(outbounds, dict):
        outbounds = [outbounds]
    if not isinstance(outbounds, list):
        return results

    for ob in outbounds:
        if not isinstance(ob, dict):
            continue

        proto = str(ob.get("protocol") or ob.get("type") or "").lower()
        tag = ob.get("tag") or ob.get("name")

        settings = ob.get("settings") or {}
        stream = ob.get("streamSettings") or {}

        if proto in {"vless", "vmess"}:
            vnext = settings.get("vnext") or settings.get("servers") or []
            if not vnext:
                continue

            node = vnext[0] if isinstance(vnext[0], dict) else {}
            users = node.get("users") or [{}]
            user = users[0] if users else {}

            server = node.get("address") or node.get("server")
            port = safe_int(node.get("port"), 443)
            uuid = user.get("id") or user.get("uuid")

            if not server or not uuid:
                continue

            proxy = new_proxy(
                tag or f"{proto}-{server}-{tail(uuid)}",
                proto, server, port
            )
            proxy["uuid"] = uuid

            if proto == "vless":
                proxy["encryption"] = "none"
            else:
                proxy["alterId"] = safe_int(user.get("alterId", user.get("aid", 0)))
                proxy["cipher"] = user.get("security") or user.get("cipher") or "auto"

            network = str(stream.get("network") or "tcp").lower()
            proxy["network"] = network

            security = str(stream.get("security") or "").lower()
            if security in {"tls", "reality"}:
                proxy["tls"] = True

            tls_settings = stream.get("tlsSettings") or {}
            server_name = tls_settings.get("serverName")
            if server_name:
                proxy["servername"] = server_name

            if security == "reality":
                reality = stream.get("realitySettings") or {}
                proxy["reality-opts"] = {
                    "public-key": reality.get("publicKey", ""),
                    "short-id": reality.get("shortId", ""),
                }
                if server_name:
                    proxy["reality-opts"]["server-name"] = server_name

            ws = stream.get("wsSettings") or {}
            if network == "ws":
                proxy["ws-opts"] = {"path": ws.get("path", "/")}
                if ws.get("headers"):
                    proxy["ws-opts"]["headers"] = ws["headers"]

            grpc = stream.get("grpcSettings") or {}
            if network == "grpc" and grpc.get("serviceName"):
                proxy["grpc-opts"] = {
                    "grpc-service-name": grpc["serviceName"]
                }

            results.append(proxy)

        elif proto == "trojan":
            servers = settings.get("servers") or []
            node = servers[0] if servers else {}
            server = node.get("address") or node.get("server")
            port = safe_int(node.get("port"), 443)
            password = node.get("password")

            if not server or not password:
                continue

            proxy = new_proxy(
                tag or f"trojan-{server}-{port}",
                "trojan", server, port
            )
            proxy["password"] = password

            tls_settings = stream.get("tlsSettings") or {}
            if tls_settings.get("serverName"):
                proxy["sni"] = tls_settings["serverName"]

            results.append(proxy)

        elif proto in {"shadowsocks", "ss"}:
            servers = settings.get("servers") or []
            node = servers[0] if servers else {}
            server = node.get("address") or node.get("server")
            port = safe_int(node.get("port"), 0)
            cipher = node.get("method") or node.get("cipher")
            password = node.get("password") or node.get("passwd")

            if server and port and cipher and password:
                proxy = new_proxy(
                    tag or f"ss-{server}-{port}",
                    "ss", server, port
                )
                proxy["cipher"] = cipher
                proxy["password"] = password
                results.append(proxy)

        elif proto == "ssr":
            servers = settings.get("servers") or []
            node = servers[0] if servers else {}
            server = node.get("address")
            port = safe_int(node.get("port"), 0)
            if server and port:
                proxy = new_proxy(
                    tag or f"ssr-{server}-{port}",
                    "ssr", server, port
                )
                for source, target in (
                    ("method", "cipher"),
                    ("password", "password"),
                    ("protocol", "protocol"),
                    ("obfs", "obfs"),
                    ("obfsParam", "obfs-param"),
                    ("protocolParam", "protocol-param"),
                ):
                    if node.get(source) not in (None, ""):
                        proxy[target] = node[source]
                results.append(proxy)

    return results


def parse_json_document(obj):
    results = []

    if isinstance(obj, dict):
        # Direct Clash/Mihomo proxy list.
        proxies = obj.get("proxies")
        if isinstance(proxies, dict):
            proxies = [proxies]

        if isinstance(proxies, list):
            for item in proxies:
                parsed = proxy_from_clash_dict(item)
                if parsed:
                    results.append(parsed)

        # Xray / V2Ray style.
        results.extend(parse_xray_outbounds(obj))

        # Sing-box style.
        outbounds = obj.get("outbounds")
        if isinstance(outbounds, list):
            for ob in outbounds:
                if not isinstance(ob, dict):
                    continue

                typ = str(ob.get("type") or "").lower()
                server = ob.get("server")
                port = safe_int(ob.get("server_port"), 0)

                if typ in {"vless", "vmess", "trojan", "shadowsocks", "hysteria", "hysteria2", "tuic"} and server and port:
                    mapped_type = "ss" if typ == "shadowsocks" else typ
                    proxy = new_proxy(
                        ob.get("tag") or f"{mapped_type}-{server}-{port}",
                        mapped_type, server, port
                    )

                    for source, target in (
                        ("uuid", "uuid"),
                        ("password", "password"),
                        ("method", "cipher"),
                        ("security", "cipher"),
                        ("network", "network"),
                        ("server_name", "servername"),
                    ):
                        if ob.get(source) not in (None, ""):
                            proxy[target] = ob[source]

                    if ob.get("tls"):
                        tls = ob["tls"]
                        if isinstance(tls, dict):
                            proxy["tls"] = True
                            if tls.get("server_name"):
                                proxy["servername"] = tls["server_name"]
                        elif tls:
                            proxy["tls"] = True

                    results.append(proxy)

    return results


def parse_yaml_document(text):
    results = []

    try:
        for doc in yaml.safe_load_all(text):
            if not isinstance(doc, dict):
                continue

            proxies = doc.get("proxies")
            if isinstance(proxies, dict):
                proxies = [proxies]

            if isinstance(proxies, list):
                for item in proxies:
                    parsed = proxy_from_clash_dict(item)
                    if parsed:
                        results.append(parsed)

            results.extend(parse_xray_outbounds(doc))
    except Exception:
        return []

    return results


# ============================================================================
# UNIVERSAL PARSING
# ============================================================================

PARSERS = (
    parse_vless,
    parse_vmess,
    parse_trojan,
    parse_ss,
    parse_ssr,
    parse_hysteria1,
    parse_hysteria2,
    parse_tuic,
    parse_wireguard_uri,
    parse_http,
    parse_socks,
)


def parse_uri_line(line):
    line = clean_text(line)
    if not line:
        return None

    # WireGuard INI may span multiple lines, so URI parser is separate.
    low = line.lower()

    for parser in PARSERS:
        try:
            result = parser(line)
            if result:
                return result
        except Exception:
            pass

    return None


def parse_base64_bundle(value, depth=0):
    if depth > 3:
        return []

    results = []

    try:
        decoded = b64decode_text(value)

        if len(decoded) > MAX_DECODED_BUNDLE:
            return results

        # JSON.
        try:
            obj = json.loads(decoded)
            results.extend(parse_json_document(obj))
            if results:
                return results
        except Exception:
            pass

        # YAML / Clash bundle.
        yaml_results = parse_yaml_document(decoded)
        if yaml_results:
            results.extend(yaml_results)
            return results

        # Normal subscription lines.
        for raw in decoded.splitlines():
            line = clean_text(raw)
            if not line:
                continue

            parsed = parse_uri_line(line)
            if parsed:
                results.append(parsed)
                continue

            if is_base64_candidate(line):
                results.extend(parse_base64_bundle(line, depth + 1))

        return results
    except Exception:
        return []


def parse_any_text(text):
    results = []

    if not text:
        return results

    # Whole YAML / JSON first.
    results.extend(parse_yaml_document(text))

    try:
        obj = json.loads(text)
        results.extend(parse_json_document(obj))
    except Exception:
        pass

    # Embedded JSON fragments.
    for fragment in extract_balanced_json_objects(text):
        try:
            results.extend(parse_json_document(json.loads(fragment)))
        except Exception:
            pass

    # WireGuard multi-line block.
    wg = parse_wireguard_config(text)
    if wg:
        results.append(wg)

    # Individual lines.
    for raw in text.splitlines():
        line = clean_text(raw)

        if not line or line.startswith("#"):
            continue

        parsed = parse_uri_line(line)
        if parsed:
            results.append(parsed)
            continue

        if is_base64_candidate(line):
            results.extend(parse_base64_bundle(line))

    return results


# ============================================================================
# VALIDATION
# ============================================================================

def validate_host(host):
    host = normalize_host(host)

    if not host or len(host) > 253:
        return False, "invalid-host"

    try:
        ipaddress.ip_address(host)
        return True, "ip"
    except Exception:
        pass

    if " " in host or "/" in host or "\\" in host:
        return False, "invalid-host"

    if not re.match(r"^[A-Za-z0-9_.:\-]+$", host):
        return False, "invalid-host"

    return True, "hostname"


def validate_proxy(proxy):
    if not isinstance(proxy, dict):
        return False, "not-dict"

    ptype = str(proxy.get("type") or "").lower()
    if ptype not in KNOWN_TYPES:
        return False, "unsupported-type"

    server = proxy.get("server")
    ok, reason = validate_host(server)
    if not ok:
        return False, reason

    port = safe_int(proxy.get("port"))
    if not 1 <= port <= 65535:
        return False, "invalid-port"

    if ptype in {"vless", "vmess"} and not proxy.get("uuid"):
        return False, "missing-uuid"

    if ptype == "trojan" and not proxy.get("password"):
        return False, "missing-password"

    if ptype == "ss" and (not proxy.get("cipher") or proxy.get("password") is None):
        return False, "missing-ss-credentials"

    if ptype == "ssr" and (not proxy.get("cipher") or proxy.get("password") is None):
        return False, "missing-ssr-credentials"

    if ptype == "tuic" and not proxy.get("uuid"):
        return False, "missing-tuic-uuid"

    if ptype == "wireguard":
        # Public key is normally needed by Mihomo WireGuard.
        if not proxy.get("public-key") and not proxy.get("public_key"):
            return False, "missing-wireguard-public-key"

    return True, "ok"


# ============================================================================
# DEDUPLICATION
# ============================================================================

SECRET_FIELDS = (
    "uuid", "password", "username",
    "public-key", "public_key", "private-key", "private_key"
)


def dedupe_key(proxy):
    ptype = str(proxy.get("type") or "").lower()
    server = normalize_host(proxy.get("server"))
    port = safe_int(proxy.get("port"))

    identity = []
    for key in SECRET_FIELDS:
        value = proxy.get(key)
        if value not in (None, ""):
            identity.append((key, str(value)))

    # Include protocol-specific transport properties where they can describe
    # materially different endpoints on the same server/port.
    transport = (
        proxy.get("network"),
        proxy.get("servername"),
        json.dumps(proxy.get("ws-opts", {}), sort_keys=True, ensure_ascii=False),
        json.dumps(proxy.get("grpc-opts", {}), sort_keys=True, ensure_ascii=False),
    )

    return (
        ptype,
        server,
        port,
        tuple(identity),
        transport,
    )


def dedupe_proxies(proxies):
    seen = set()
    output = []

    for proxy in proxies:
        key = dedupe_key(proxy)
        if key in seen:
            continue
        seen.add(key)
        output.append(proxy)

    return output


# ============================================================================
# DNS CACHE
# ============================================================================

class PersistentCache:
    def __init__(self, path):
        self.path = path
        self.data = {
            "dns": {},
            "result": {},
            "meta": {},
        }
        self.load()

    def load(self):
        try:
            if os.path.exists(self.path):
                with open(self.path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    self.data.update(loaded)
        except Exception:
            pass

    def save(self):
        temp = self.path + ".tmp"
        try:
            with open(temp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(temp, self.path)
        except Exception:
            try:
                if os.path.exists(temp):
                    os.remove(temp)
            except Exception:
                pass

    def get_dns(self, host):
        item = self.data.get("dns", {}).get(host)
        if not item:
            return None
        if now_ts() - safe_int(item.get("ts")) > DNS_TTL_SECONDS:
            return None
        return item.get("ips")

    def put_dns(self, host, ips):
        self.data.setdefault("dns", {})[host] = {
            "ts": now_ts(),
            "ips": ips,
        }

    def get_result(self, key):
        item = self.data.get("result", {}).get(key)
        if not item:
            return None
        if now_ts() - safe_int(item.get("ts")) > RESULT_TTL_SECONDS:
            return None
        return item

    def put_result(self, key, result):
        self.data.setdefault("result", {})[key] = {
            "ts": now_ts(),
            **result,
        }


CACHE = PersistentCache(CACHE_PATH)


def resolve_host(host):
    host = normalize_host(host)

    try:
        ipaddress.ip_address(host)
        return [host]
    except Exception:
        pass

    cached = CACHE.get_dns(host)
    if cached:
        return cached

    ips = set()

    try:
        infos = socket.getaddrinfo(
            host,
            None,
            type=socket.SOCK_STREAM,
        )
        for info in infos:
            sockaddr = info[4]
            if sockaddr:
                ips.add(sockaddr[0])
    except Exception:
        pass

    ips = sorted(ips)
    CACHE.put_dns(host, ips)
    return ips


# ============================================================================
# CONNECTIVITY TESTING
# ============================================================================

def tcp_connect(host, port, timeout):
    sock = None
    started = time.monotonic()

    try:
        sock = socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))
        elapsed = int((time.monotonic() - started) * 1000)
        return True, elapsed, ""
    except Exception as exc:
        return False, None, type(exc).__name__
    finally:
        if sock:
            try:
                sock.close()
            except Exception:
                pass


def tcp_connect_any(host, port, timeout):
    ips = resolve_host(host)

    if not ips:
        return False, None, "dns-failed", []

    best = None
    last_error = "connect-failed"

    for ip in ips:
        ok, latency, error = tcp_connect(ip, port, timeout)

        if ok:
            if best is None or latency < best:
                best = latency
        else:
            last_error = error

    if best is not None:
        return True, best, "", ips

    return False, None, last_error, ips


def tls_probe(host, port, timeout):
    """
    Real TLS handshake only.
    This does NOT claim that proxy authentication succeeded.
    """
    context = ssl.create_default_context()
    sock = None
    started = time.monotonic()

    try:
        raw = socket.create_connection((host, port), timeout=timeout)
        raw.settimeout(timeout)

        server_name = host
        sock = context.wrap_socket(raw, server_hostname=server_name)

        elapsed = int((time.monotonic() - started) * 1000)
        version = sock.version() or ""

        return True, elapsed, version
    except Exception as exc:
        return False, None, type(exc).__name__
    finally:
        if sock:
            try:
                sock.close()
            except Exception:
                pass


def test_one_proxy(proxy, mode):
    p = dict(proxy)

    if mode == "LIGHT":
        timeout = LIGHT_TIMEOUT
        attempts = LIGHT_ATTEMPTS
    elif mode == "NORMAL":
        timeout = NORMAL_TIMEOUT
        attempts = NORMAL_ATTEMPTS
    else:
        timeout = DEEP_TIMEOUT
        attempts = DEEP_ATTEMPTS

    cache_key_raw = json.dumps(
        {
            "type": p.get("type"),
            "server": p.get("server"),
            "port": p.get("port"),
            "mode": mode,
        },
        sort_keys=True,
    )
    cache_key = hashlib.sha256(cache_key_raw.encode()).hexdigest()

    cached = CACHE.get_result(cache_key)
    if cached:
        p.update({
            "test": cached.get("test"),
            "reachable": cached.get("reachable", False),
            "latency": cached.get("latency"),
            "dns_ips": cached.get("dns_ips", []),
            "error": cached.get("error", ""),
        })
        return p

    best_latency = None
    last_error = ""
    ips = []

    for _ in range(attempts):
        ok, latency, error, resolved_ips = tcp_connect_any(
            p["server"], p["port"], timeout
        )
        ips = resolved_ips or ips

        if ok:
            if best_latency is None or latency < best_latency:
                best_latency = latency
        else:
            last_error = error

    reachable = best_latency is not None

    result = {
        "test": mode,
        "reachable": reachable,
        "latency": best_latency,
        "dns_ips": ips,
        "error": last_error if not reachable else "",
    }

    # DEEP adds a genuine TLS handshake only when TLS is explicitly configured.
    if mode == "DEEP" and reachable and p.get("tls"):
        tls_ok, tls_latency, tls_info = tls_probe(
            p["server"], p["port"], DEEP_TIMEOUT
        )
        result["tls_checked"] = True
        result["tls_ok"] = tls_ok
        result["tls_latency"] = tls_latency
        result["tls_info"] = tls_info

        # A TCP-reachable TLS endpoint can remain useful even when certificate
        # verification fails. We report the real TLS result separately.
        if not tls_ok:
            result["tls_error"] = tls_info

    CACHE.put_result(cache_key, result)

    p.update(result)
    return p


# ============================================================================
# MIHOMO OUTPUT NORMALIZATION
# ============================================================================

INTERNAL_FIELDS = {
    "status", "reachable", "latency", "dns_ips",
    "test", "error", "tls_checked", "tls_ok",
    "tls_latency", "tls_info", "tls_error",
}


def clean_for_yaml(proxy):
    out = {}

    for key, value in proxy.items():
        if key in INTERNAL_FIELDS:
            continue

        # Convert internal/private aliases to Mihomo names.
        if key == "public_key":
            key = "public-key"
        elif key == "private_key":
            key = "private-key"

        out[key] = value

    return out


def stable_sort_key(proxy):
    latency = proxy.get("latency")
    if latency is None:
        return 10**9
    return safe_int(latency, 10**9)


def make_group_names(proxies):
    return [p["name"] for p in proxies]


def build_output(proxies, mode):
    yaml_proxies = [clean_for_yaml(p) for p in proxies]

    # One manual select group by design. No periodic url-test/fallback.
    names = make_group_names(yaml_proxies)

    groups = [
        {
            "name": "♻ Mobile-Auto❤",
            "type": "select",
            "proxies": names,
        }
    ]

    # Conservative rules; users can edit routing independently.
    rules = [
        "MATCH,♻ Mobile-Auto❤"
    ]

    return {
        "mixed-port": 7890,
        "allow-lan": False,
        "mode": "rule",
        "log-level": "warning",
        "ipv6": True,
        "proxies": yaml_proxies,
        "proxy-groups": groups,
        "rules": rules,
    }


# ============================================================================
# REPORTING
# ============================================================================

def write_text(path, lines):
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
        if lines:
            f.write("\n")


def write_reports(out_dir, base_name, all_candidates, valid, failed, unknown, mode):
    failed_lines = []
    for item in failed:
        failed_lines.append(
            f"{item.get('line','')}\tREASON={item.get('reason','unknown')}"
        )

    unknown_lines = []
    for item in unknown:
        unknown_lines.append(item)

    report = [
        "Ultra Industrial Clash Meta / Mihomo Report",
        f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Mode: {mode}",
        f"Raw candidates: {len(all_candidates)}",
        f"Valid candidates: {len(valid)}",
        f"Reachable after test: {sum(1 for x in valid if x.get('reachable'))}",
        f"Failed validation/test: {len(failed)}",
        f"Unknown/unparsed lines: {len(unknown)}",
        "",
        "Latency distribution:",
    ]

    reachable = [
        x.get("latency")
        for x in valid
        if x.get("reachable") and x.get("latency") is not None
    ]

    if reachable:
        reachable.sort()
        report.extend([
            f"min: {min(reachable)} ms",
            f"median: {reachable[len(reachable)//2]} ms",
            f"max: {max(reachable)} ms",
        ])
    else:
        report.append("No reachable endpoints.")

    write_text(
        os.path.join(out_dir, f"{base_name}_failed.txt"),
        failed_lines or ["No failed entries."],
    )

    write_text(
        os.path.join(out_dir, f"{base_name}_unknown.txt"),
        unknown_lines or ["No unknown/unparsed entries."],
    )

    write_text(
        os.path.join(out_dir, f"{base_name}_report.txt"),
        report,
    )


# ============================================================================
# INPUT / INTERACTIVE UI
# ============================================================================

def prepare_input():
    # Always create/clear the mobile input file before editing.
    with open(INPUT_PATH, "w", encoding="utf-8"):
        pass

    print()
    print("==============================================================")
    print(" Ultra Industrial Clash Meta / Mihomo Parser")
    print("==============================================================")
    print(f"Input: {INPUT_PATH}")
    print()
    print("Opening nano. Paste your configs/subscriptions, save, exit.")
    print()

    try:
        subprocess.call(["nano", INPUT_PATH])
    except Exception as exc:
        print(f"[WARN] nano could not be started: {exc}")

    try:
        with open(INPUT_PATH, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def choose_mode():
    print()
    print("Test mode:")
    print("  1 = LIGHT  (default, lowest data/CPU)")
    print("  2 = NORMAL (balanced)")
    print("  3 = DEEP   (most checking)")
    print()

    choice = input("Select mode [1]: ").strip()

    if choice == "2":
        return "NORMAL"
    if choice == "3":
        return "DEEP"
    return "LIGHT"


def choose_output():
    folder = input(
        f"Enter output folder name in Download [{DEFAULT_OUT_FOLDER}]: "
    ).strip() or DEFAULT_OUT_FOLDER

    folder = re.sub(r'[\\/:*?"<>|]+', "_", folder)
    out_dir = os.path.join(
        "/storage/emulated/0/Download",
        folder
    )
    os.makedirs(out_dir, exist_ok=True)

    filename = input(
        f"Enter output file name without extension [{DEFAULT_OUT_FILE}]: "
    ).strip() or DEFAULT_OUT_FILE

    filename = re.sub(r'[\\/:*?"<>|]+', "_", filename)
    filename = re.sub(r"\.ya?ml$", "", filename, flags=re.I)

    return out_dir, filename


# ============================================================================
# MAIN PIPELINE
# ============================================================================

def parse_pipeline(text):
    raw_results = parse_any_text(text)

    # A second pass specifically for individual WireGuard blocks separated
    # by blank lines.
    if "[Interface]" in text:
        chunks = re.split(r"(?=\[Interface\])", text)
        for chunk in chunks:
            if "[Interface]" in chunk and "[Peer]" in chunk:
                parsed = parse_wireguard_config(chunk)
                if parsed:
                    raw_results.append(parsed)

    return raw_results


def main():
    start_time = time.time()

    text = prepare_input()

    if not text.strip():
        print("[ERROR] Input is empty.")
        return 1

    mode = choose_mode()
    out_dir, base_name = choose_output()

    print()
    print(f"[*] Mode: {mode}")
    print("[*] Parsing all supported input formats...")

    candidates = parse_pipeline(text)

    if not candidates:
        print("[ERROR] No supported proxy/configuration was parsed.")
        return 1

    print(f"[*] Parsed raw candidates: {len(candidates)}")

    # Structural validation.
    valid = []
    failed = []

    for proxy in candidates:
        ok, reason = validate_proxy(proxy)
        if ok:
            valid.append(proxy)
        else:
            failed.append({
                "line": proxy.get("name", "<unnamed>"),
                "reason": reason,
            })

    print(f"[*] Structurally valid: {len(valid)}")
    print(f"[*] Structurally rejected: {len(failed)}")

    # Semantic deduplication.
    before = len(valid)
    valid = dedupe_proxies(valid)
    print(f"[*] After semantic dedupe: {len(valid)} (removed {before - len(valid)})")

    if not valid:
        print("[ERROR] No valid proxies remain.")
        return 1

    # Testing is manual and happens only once for this execution.
    print()
    print(f"[*] Running manual {mode} connectivity checks...")
    print("[*] No background/periodic testing is used.")

    tested = []
    workers = min(MAX_WORKERS, max(4, len(valid)))

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {
            executor.submit(test_one_proxy, proxy, mode): proxy
            for proxy in valid
        }

        completed = 0
        total = len(future_map)

        for future in as_completed(future_map):
            original = future_map[future]
            completed += 1

            try:
                result = future.result()
                tested.append(result)
            except Exception as exc:
                failed.append({
                    "line": original.get("name", "<unnamed>"),
                    "reason": f"test-exception:{type(exc).__name__}",
                })

            if completed % 50 == 0 or completed == total:
                print(f"    checked {completed}/{total}")

    reachable = [
        p for p in tested
        if p.get("reachable") and p.get("latency") is not None
    ]

    reachable.sort(key=stable_sort_key)

    # Final name cleanup after dedupe/testing.
    final = []
    final_seen = set()

    for proxy in reachable:
        key = dedupe_key(proxy)
        if key in final_seen:
            continue
        final_seen.add(key)

        # Names are already unique; ensure no empty name survives.
        if not proxy.get("name"):
            proxy["name"] = NAME_MANAGER.unique(
                f"{proxy.get('type','proxy')}-{proxy.get('server')}"
            )

        final.append(proxy)

    print()
    print(f"[*] Reachable endpoints: {len(final)}")

    if not final:
        print("[ERROR] No reachable endpoints found.")
        print("[INFO] Nothing was written as a fake/empty proxy list.")
        return 1

    output_data = build_output(final, mode)

    out_path = os.path.join(out_dir, f"{base_name}.yaml")

    # Safe YAML write.
    with open(out_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(
            output_data,
            f,
            allow_unicode=True,
            sort_keys=False,
            default_flow_style=False,
        )

    # Unknown lines: best-effort report only.
    unknown = []
    for raw in text.splitlines():
        line = clean_text(raw)
        if not line or line.startswith("#"):
            continue

        # Don't report obvious YAML structural lines as unknown.
        if line in {"proxies:", "proxy-groups:", "rules:", "outbounds:"}:
            continue

        parsed = parse_uri_line(line)
        if parsed:
            continue

        if is_base64_candidate(line):
            continue

        # YAML/JSON may legitimately be a container rather than a URI.
        if line.startswith(("{", "}", "[", "]", "-", "proxies:", "outbounds:")):
            continue

        if re.match(r"^[A-Za-z0-9_.-]+\s*:", line):
            continue

        if "://" not in line and "[Interface]" not in line:
            unknown.append(line)

    # Failed tests.
    for proxy in tested:
        if not proxy.get("reachable"):
            failed.append({
                "line": proxy.get("name", "<unnamed>"),
                "reason": proxy.get("error") or "tcp-unreachable",
            })

    write_reports(
        out_dir,
        base_name,
        candidates,
        final,
        failed,
        unknown,
        mode,
    )

    CACHE.data.setdefault("meta", {})["last_run"] = now_ts()
    CACHE.data["meta"]["last_mode"] = mode
    CACHE.save()

    # Clear input after successful read/write, preserving the user's workflow.
    try:
        with open(INPUT_PATH, "w", encoding="utf-8"):
            pass
    except Exception:
        pass

    elapsed = time.time() - start_time

    print()
    print("==============================================================")
    print(" DONE")
    print("==============================================================")
    print(f"YAML:   {out_path}")
    print(f"Failed: {os.path.join(out_dir, base_name + '_failed.txt')}")
    print(f"Unknown:{os.path.join(out_dir, base_name + '_unknown.txt')}")
    print(f"Report: {os.path.join(out_dir, base_name + '_report.txt')}")
    print(f"Mode:   {mode}")
    print(f"Nodes:  {len(final)}")
    print(f"Time:   {elapsed:.1f}s")
    print("==============================================================")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[STOP] Interrupted by user.")
        raise SystemExit(130)
    except Exception as exc:
        print(f"\n[FATAL] {type(exc).__name__}: {exc}")
        raise SystemExit(1)

