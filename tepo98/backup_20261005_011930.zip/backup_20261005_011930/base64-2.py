#!/usr/bin/env python3
import os, json, base64, subprocess

# ================== PATH ==================
BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)

INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

# این خط باعث می‌شود که فایل ورودی هر بار کاملاً خالی شود
open(INPUT_PATH, "w", encoding="utf-8").close()

print("\n[+] Paste ALL configs, save & exit nano")
subprocess.call(["nano", INPUT_PATH])

out_folder = input("\nEnter output folder name in Download: ").strip()
if not out_folder:
    exit("Folder name required")

OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

OUT_PATH = os.path.join(OUT_DIR, "subscription_base64.txt")

# ================== HELPERS ==================
def b64e(s: str) -> str:
    return base64.b64encode(s.encode()).decode()

def fix_vmess(link):
    try:
        raw = link.replace("vmess://","")
        j = json.loads(base64.b64decode(raw + "===").decode())
        clean = json.dumps(j, separators=(",",":"))
        return "vmess://" + b64e(clean)
    except:
        return None

def fix_ss(link):
    try:
        raw = link.replace("ss://","").split("#")[0]
        base64.b64decode(raw + "===")
        return "ss://" + raw
    except:
        try:
            return "ss://" + b64e(raw)
        except:
            return None

def normalize(line):
    line = line.strip()
    if not line:
        return None

    if line.startswith("vmess://"): return fix_vmess(line)
    if line.startswith("ss://"): return fix_ss(line)
    if line.startswith((
        "vless://","trojan://","hysteria://","hysteria2://",
        "tuic://","socks://","http://","https://"
    )): return line
    return None

# ================== PROCESS ==================
unique = set()
final_links = []
BATCH = 10

with open(INPUT_PATH, encoding="utf-8", errors="ignore") as fin:
    batch = []
    for line in fin:
        batch.append(line)
        if len(batch) == BATCH:
            for l in batch:
                try:
                    r = normalize(l)
                    if r and r not in unique:
                        unique.add(r)
                        final_links.append(r)
                except:
                    pass
            batch.clear()
    for l in batch:
        try:
            r = normalize(l)
            if r and r not in unique:
                unique.add(r)
                final_links.append(r)
        except:
            pass

# ================== SUBSCRIPTION ==================
subscription_raw = "\n".join(final_links)
subscription_b64 = base64.b64encode(subscription_raw.encode()).decode()

with open(OUT_PATH, "w", encoding="utf-8") as f:
    f.write(subscription_b64)

# ================== CLEAR input.txt ==================
open(INPUT_PATH, "w", encoding="utf-8").close()  # پاک کردن محتویات فایل

print("\n[✓] SUBSCRIPTION READY")
print(f"Configs count : {len(final_links)}")
print(f"Saved to      : {OUT_PATH}")
