#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-

"""
============================================================
CLASH META INDUSTRIAL ENGINE
Version: 2.1.0-industrial
Target: Android / Termux
============================================================

FEATURES
------------------------------------------------------------
- Fixed input path:
  /storage/emulated/0/Download/Akbar98/input.txt

- input.txt is automatically emptied BEFORE Nano opens
- Nano opens automatically
- No "open nano? [Y/n]" question
- User enters configurations in Nano
- After Nano closes:
    1. ask output folder
    2. ask output filename
- Output:
    /storage/emulated/0/Download/<folder>/<file>.yaml

- input.txt is cleared ONLY after successful output
- If processing/output fails, input.txt is preserved

- ONE proxy-group only
- LOW_DATA default
- No continuous Python HTTP testing
- TCP health check
- Retry support
- Latency measurement
- Stability scoring
- Multi-stage deduplication
- Stable fingerprint
- IPv4 / IPv6 / hostname
- ThreadPool suitable for Android / Termux
- Atomic YAML output
- Base64 bundles
- JSON
- YAML
- VLESS
- VMess
- Trojan
- Shadowsocks
- ShadowsocksR
- Hysteria
- Hysteria2
- TUIC
- WireGuard
============================================================
"""

import os
import sys
import re
import json
import time
import base64
import socket
import hashlib
import threading
import subprocess

from dataclasses import dataclass, field
from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)

from typing import (
    Any,
    Dict,
    List,
    Optional,
)

from urllib.parse import (
    urlparse,
    parse_qs,
    unquote,
)

import yaml


# ============================================================
# CONFIGURATION
# ============================================================

BASE_DIR = (
    "/storage/emulated/0/Download/Akbar98"
)

INPUT_FILE = os.path.join(
    BASE_DIR,
    "input.txt"
)

ENGINE_NAME = (
    "ClashMetaIndustrialEngine"
)

ENGINE_VERSION = (
    "2.1.0-industrial"
)


# ============================================================
# MODE
# ============================================================

# LOW_DATA
# ------------------------------------------------------------
# Python performs only TCP health checks.
# Clash Meta does not continuously HTTP-test the group.
#
# BALANCED
# ------------------------------------------------------------
# Clash Meta uses url-test after import.
#
MODE = "LOW_DATA"


# ============================================================
# TCP HEALTH CHECK
# ============================================================

TCP_TIMEOUT = 1.20

TCP_RETRIES = 2

MAX_WORKERS = 16

MAX_WORKERS_HARD = 24


# ============================================================
# INPUT / OUTPUT LIMITS
# ============================================================

MAX_INPUT_LINES = 50000

MAX_PROXIES = 20000


# ============================================================
# HEALTH POLICY
# ============================================================

# Keep dead proxies in final YAML?
KEEP_DEAD = False

# Export alive proxies only
KEEP_ALIVE_ONLY = True


# ============================================================
# GROUP
# ============================================================

GROUP_NAME = "AUTO💚"

GROUP_TYPE_LOW_DATA = "select"

GROUP_TYPE_BALANCED = "url-test"

CLASH_TEST_URL = (
    "http://cp.cloudflare.com/generate_204"
)

CLASH_INTERVAL = 300

CLASH_TOLERANCE = 50


# ============================================================
# NAME
# ============================================================

DEFAULT_NAME_PREFIX = "Proxy"


# ============================================================
# LOGGING
# ============================================================

LOG_LEVEL = "INFO"


# ============================================================
# LOGGER
# ============================================================

class Logger:

    LEVELS = {
        "DEBUG": 10,
        "INFO": 20,
        "WARN": 30,
        "ERROR": 40,
    }

    current_level = LEVELS.get(
        LOG_LEVEL,
        20
    )

    lock = threading.Lock()

    @classmethod
    def log(
        cls,
        level: str,
        message: str
    ):

        if cls.LEVELS[level] < cls.current_level:
            return

        with cls.lock:

            stamp = time.strftime(
                "%Y-%m-%d %H:%M:%S"
            )

            print(
                f"[{stamp}] "
                f"[{level}] "
                f"{message}",
                flush=True
            )

    @classmethod
    def debug(cls, msg):
        cls.log(
            "DEBUG",
            msg
        )

    @classmethod
    def info(cls, msg):
        cls.log(
            "INFO",
            msg
        )

    @classmethod
    def warn(cls, msg):
        cls.log(
            "WARN",
            msg
        )

    @classmethod
    def error(cls, msg):
        cls.log(
            "ERROR",
            msg
        )


# ============================================================
# BASIC UTILITIES
# ============================================================

def safe_int(
    value: Any,
    default: int = 0
) -> int:

    try:
        return int(value)

    except Exception:

        try:
            return int(
                float(value)
            )

        except Exception:
            return default


def clean_string(
    value: Any
) -> str:

    if value is None:
        return ""

    return str(value).strip()


def decode_url_value(
    value: Any
) -> str:

    return unquote(
        clean_string(value)
    )


def normalize_scheme(
    value: str
) -> str:

    return (
        clean_string(value)
        .lower()
        .rstrip(":")
    )


def valid_port(
    port: Any
) -> bool:

    p = safe_int(port)

    return (
        1 <= p <= 65535
    )


def safe_host(
    host: Any
) -> str:

    host = clean_string(host)

    if (
        host.startswith("[")
        and host.endswith("]")
    ):
        return host[1:-1]

    return host


def split_host_port(
    value: str,
    default_port: int = 443
):

    value = clean_string(value)

    if not value:
        return "", default_port

    # IPv6:
    # [2001:db8::1]:443

    if value.startswith("["):

        end = value.find("]")

        if end >= 0:

            host = value[
                1:end
            ]

            rest = value[
                end + 1:
            ]

            if rest.startswith(":"):

                return (
                    host,
                    safe_int(
                        rest[1:],
                        default_port
                    )
                )

            return (
                host,
                default_port
            )

    # hostname:port
    if value.count(":") == 1:

        host, port = value.rsplit(
            ":",
            1
        )

        if port.isdigit():

            return (
                host,
                safe_int(
                    port,
                    default_port
                )
            )

    # Raw IPv6
    if value.count(":") > 1:

        return (
            value,
            default_port
        )

    return (
        value,
        default_port
    )


# ============================================================
# BASE64
# ============================================================

def b64_decode_bytes(
    value: str
) -> Optional[bytes]:

    try:

        value = clean_string(value)

        if not value:
            return None

        value = (
            value
            .replace("\n", "")
            .replace("\r", "")
            .replace(" ", "")
        )

        value = (
            value
            .replace("-", "+")
            .replace("_", "/")
        )

        value += "=" * (
            -len(value) % 4
        )

        return base64.b64decode(
            value,
            validate=False
        )

    except Exception:

        return None


def b64_decode_text(
    value: str
) -> Optional[str]:

    raw = b64_decode_bytes(
        value
    )

    if raw is None:
        return None

    try:

        return raw.decode(
            "utf-8",
            "ignore"
        )

    except Exception:

        return None


def looks_like_base64(
    value: str
) -> bool:

    value = clean_string(
        value
    )

    if len(value) < 16:
        return False

    if "://" in value:
        return False

    if not re.fullmatch(
        r"[A-Za-z0-9+/=_\-]+",
        value
    ):
        return False

    decoded = b64_decode_text(
        value
    )

    if not decoded:
        return False

    schemes = (
        "vless://",
        "vmess://",
        "trojan://",
        "ss://",
        "ssr://",
        "hysteria://",
        "hysteria2://",
        "hy2://",
        "tuic://",
        "wg://",
        "wireguard://",
    )

    low = decoded.lower()

    return any(
        scheme in low
        for scheme in schemes
    )


# ============================================================
# NAME
# ============================================================

def sanitize_name(
    name: Any
) -> str:

    name = decode_url_value(
        name
    )

    name = re.sub(
        r"[\x00-\x1f\x7f]",
        "",
        name
    )

    name = re.sub(
        r'[\\/:*?"<>|]+',
        " ",
        name
    )

    name = re.sub(
        r"\s+",
        " ",
        name
    ).strip()

    return name[:120]


class NamePool:

    def __init__(self):

        self.used = set()

        self.lock = threading.Lock()

    def get(
        self,
        requested: str,
        fallback: str
    ) -> str:

        base = sanitize_name(
            requested
        )

        if not base:

            base = sanitize_name(
                fallback
            )

        if not base:

            base = DEFAULT_NAME_PREFIX

        with self.lock:

            name = base

            index = 2

            while name in self.used:

                name = (
                    f"{base} {index}"
                )

                index += 1

            self.used.add(name)

            return name


NAME_POOL = NamePool()


# ============================================================
# QUERY HELPERS
# ============================================================

def query_first(
    qs: Dict[str, List[str]],
    *keys,
    default=""
):

    for key in keys:

        if (
            key in qs
            and qs[key]
        ):

            return decode_url_value(
                qs[key][0]
            )

    return default


def bool_param(
    qs,
    *keys,
    default=False
):

    value = query_first(
        qs,
        *keys,
        default=""
    ).lower()

    if value in (
        "1",
        "true",
        "yes",
        "on",
    ):
        return True

    if value in (
        "0",
        "false",
        "no",
        "off",
    ):
        return False

    return default


# ============================================================
# PROXY MODEL
# ============================================================

@dataclass
class Proxy:

    data: Dict[str, Any]

    ping: Optional[int] = None

    alive: bool = False

    attempts: int = 0

    successes: int = 0

    fingerprint: str = field(
        init=False
    )

    def __post_init__(self):

        self.fingerprint = (
            fingerprint(
                self.data
            )
        )

    @property
    def type(self):

        return normalize_scheme(
            self.data.get(
                "type",
                ""
            )
        )

    @property
    def server(self):

        return clean_string(
            self.data.get(
                "server"
            )
        )

    @property
    def port(self):

        return safe_int(
            self.data.get(
                "port"
            )
        )

    @property
    def name(self):

        return clean_string(
            self.data.get(
                "name"
            )
        )

    def success_rate(self):

        if self.attempts <= 0:
            return 0.0

        return (
            self.successes
            / self.attempts
        )

    def score(self):

        if not self.alive:

            return 10_000_000

        ping = (
            self.ping
            or 9999
        )

        reliability_penalty = (
            (
                1.0
                - self.success_rate()
            )
            * 500
        )

        return (
            ping
            + reliability_penalty
        )

    def export(self):

        return dict(
            self.data
        )


# ============================================================
# FINGERPRINT
# ============================================================

def fingerprint(
    data: Dict[str, Any]
) -> str:

    t = normalize_scheme(
        data.get("type")
    )

    server = safe_host(
        data.get(
            "server"
        )
    ).lower()

    port = str(
        safe_int(
            data.get(
                "port"
            )
        )
    )

    identity = ""

    if t in (
        "vless",
        "vmess",
    ):

        identity = clean_string(
            data.get(
                "uuid"
            )
        )

    elif t in (
        "trojan",
        "hysteria",
        "hysteria2",
        "tuic",
    ):

        identity = (
            clean_string(
                data.get(
                    "uuid"
                )
            )
            + "|"
            + clean_string(
                data.get(
                    "password"
                )
            )
        )

    elif t in (
        "ss",
        "ssr",
    ):

        identity = (
            clean_string(
                data.get(
                    "cipher"
                )
            )
            + "|"
            + clean_string(
                data.get(
                    "password"
                )
            )
        )

    elif t == "wireguard":

        identity = (
            clean_string(
                data.get(
                    "private-key"
                )
            )
            + "|"
            + clean_string(
                data.get(
                    "public-key"
                )
            )
        )

    canonical = "|".join(
        (
            t,
            server,
            port,
            identity,
            clean_string(
                data.get(
                    "sni"
                )
            ),
            clean_string(
                data.get(
                    "servername"
                )
            ),
            clean_string(
                data.get(
                    "network"
                )
            ),
        )
    )

    return hashlib.sha256(
        canonical.encode(
            "utf-8"
        )
    ).hexdigest()


# ============================================================
# NORMALIZER
# ============================================================

class ProxyNormalizer:

    SUPPORTED = {
        "vless",
        "vmess",
        "trojan",
        "ss",
        "ssr",
        "hysteria",
        "hysteria2",
        "tuic",
        "wireguard",
    }

    @classmethod
    def normalize(
        cls,
        raw: Dict[str, Any]
    ) -> Optional[Proxy]:

        if not isinstance(
            raw,
            dict
        ):
            return None

        data = dict(
            raw
        )

        t = normalize_scheme(
            data.get(
                "type"
            )
        )

        if t == "wg":
            t = "wireguard"

        if t not in cls.SUPPORTED:
            return None

        server = safe_host(
            data.get(
                "server"
            )
        )

        port = safe_int(
            data.get(
                "port"
            )
        )

        if not server:
            return None

        if not valid_port(
            port
        ):

            defaults = {
                "vless": 443,
                "vmess": 443,
                "trojan": 443,
                "ss": 443,
                "ssr": 443,
                "hysteria": 443,
                "hysteria2": 443,
                "tuic": 443,
                "wireguard": 51820,
            }

            port = defaults.get(
                t,
                443
            )

        data["type"] = t

        data["server"] = server

        data["port"] = port

        # ----------------------------------------------------
        # String normalization
        # ----------------------------------------------------

        for key in (
            "name",
            "uuid",
            "password",
            "cipher",
            "sni",
            "servername",
            "network",
            "path",
            "host",
            "flow",
            "encryption",
            "alterId",
        ):

            if (
                key in data
                and data[key] is not None
            ):

                if key != "alterId":

                    data[key] = (
                        decode_url_value(
                            data[key]
                        )
                    )

        # ----------------------------------------------------
        # Boolean normalization
        # ----------------------------------------------------

        if "tls" in data:

            value = data["tls"]

            if isinstance(
                value,
                str
            ):

                data["tls"] = (
                    value.lower()
                    in (
                        "1",
                        "true",
                        "yes",
                        "on",
                        "tls",
                        "reality",
                    )
                )

            else:

                data["tls"] = bool(
                    value
                )

        if "udp" in data:

            value = data["udp"]

            if isinstance(
                value,
                str
            ):

                data["udp"] = (
                    value.lower()
                    in (
                        "1",
                        "true",
                        "yes",
                        "on",
                    )
                )

            else:

                data["udp"] = bool(
                    value
                )

        # ----------------------------------------------------
        # Name
        # ----------------------------------------------------

        fallback = (
            f"{t}-{server}-{port}"
        )

        data["name"] = (
            NAME_POOL.get(
                data.get(
                    "name"
                ),
                fallback
            )
        )

        # ----------------------------------------------------
        # Validation
        # ----------------------------------------------------

        if t in (
            "vless",
            "vmess",
        ):

            if not clean_string(
                data.get(
                    "uuid"
                )
            ):

                return None

        if t == "trojan":

            if not clean_string(
                data.get(
                    "password"
                )
            ):

                return None

        if t in (
            "ss",
            "ssr",
        ):

            if not clean_string(
                data.get(
                    "cipher"
                )
            ):

                return None

            if not clean_string(
                data.get(
                    "password"
                )
            ):

                return None

        # ----------------------------------------------------
        # Internal fields
        # ----------------------------------------------------

        for key in (
            "ping",
            "alive",
            "status",
            "score",
            "_source",
            "attempts",
            "successes",
        ):

            data.pop(
                key,
                None
            )

        return Proxy(
            data
        )


# ============================================================
# DEDUPLICATION
# ============================================================

class Deduper:

    def __init__(self):

        self.fingerprints = set()

        self.lock = threading.Lock()

    def add(
        self,
        proxy: Proxy
    ) -> bool:

        with self.lock:

            if (
                proxy.fingerprint
                in self.fingerprints
            ):

                return False

            self.fingerprints.add(
                proxy.fingerprint
            )

            return True

    def run(
        self,
        proxies: List[Proxy]
    ) -> List[Proxy]:

        result = []

        for proxy in proxies:

            if self.add(
                proxy
            ):

                result.append(
                    proxy
                )

        return result


# ============================================================
# VLESS
# ============================================================

def parse_vless(
    url: str
) -> Optional[Proxy]:

    try:

        parsed = urlparse(
            url
        )

        uuid = unquote(
            parsed.username or ""
        )

        host = safe_host(
            parsed.hostname or ""
        )

        port = (
            parsed.port
            or 443
        )

        if not uuid or not host:
            return None

        qs = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        network = query_first(
            qs,
            "type",
            "network",
            default="tcp"
        ).lower()

        security = query_first(
            qs,
            "security",
            default=""
        ).lower()

        data = {
            "type": "vless",
            "server": host,
            "port": port,
            "uuid": uuid,
            "encryption": query_first(
                qs,
                "encryption",
                default="none"
            ),
            "network": network,
            "udp": True,
            "tls": security in (
                "tls",
                "reality",
            ),
        }

        # ----------------------------------------------------
        # Reality
        # ----------------------------------------------------

        if security == "reality":

            reality = {
                "public-key": query_first(
                    qs,
                    "pbk",
                    "public-key"
                ),
                "short-id": query_first(
                    qs,
                    "sid",
                    "short-id"
                ),
            }

            reality = {
                k: v
                for k, v in reality.items()
                if v
            }

            if reality:

                data[
                    "reality-opts"
                ] = reality

        # ----------------------------------------------------
        # SNI
        # ----------------------------------------------------

        sni = query_first(
            qs,
            "sni",
            "serverName",
            "servername"
        )

        if sni:

            data["servername"] = sni

            data["sni"] = sni

        # ----------------------------------------------------
        # Flow
        # ----------------------------------------------------

        flow = query_first(
            qs,
            "flow"
        )

        if flow:

            data["flow"] = flow

        # ----------------------------------------------------
        # WebSocket
        # ----------------------------------------------------

        if network == "ws":

            path = query_first(
                qs,
                "path",
                default="/"
            )

            host_header = query_first(
                qs,
                "host",
                default=""
            )

            ws_opts = {
                "path": path,
                "headers": {},
            }

            if host_header:

                ws_opts[
                    "headers"
                ]["Host"] = host_header

            data[
                "ws-opts"
            ] = ws_opts

        # ----------------------------------------------------
        # gRPC
        # ----------------------------------------------------

        elif network == "grpc":

            service_name = query_first(
                qs,
                "serviceName",
                "service-name",
                default=""
            )

            grpc_opts = {}

            if service_name:

                grpc_opts[
                    "grpc-service-name"
                ] = service_name

            if grpc_opts:

                data[
                    "grpc-opts"
                ] = grpc_opts

        # ----------------------------------------------------
        # HTTP/2
        # ----------------------------------------------------

        elif network == "h2":

            h2_opts = {
                "path": query_first(
                    qs,
                    "path",
                    default="/"
                )
            }

            host_header = query_first(
                qs,
                "host",
                default=""
            )

            if host_header:

                h2_opts[
                    "host"
                ] = [
                    host_header
                ]

            data[
                "h2-opts"
            ] = h2_opts

        # ----------------------------------------------------
        # Fragment/name
        # ----------------------------------------------------

        if parsed.fragment:

            data["name"] = unquote(
                parsed.fragment
            )

        return ProxyNormalizer.normalize(
            data
        )

    except Exception:

        return None


# ============================================================
# VMESS
# ============================================================

def parse_vmess(
    url: str
) -> Optional[Proxy]:

    try:

        encoded = url[
            len("vmess://"):
        ].strip()

        decoded = b64_decode_text(
            encoded
        )

        if not decoded:
            return None

        obj = json.loads(
            decoded
        )

        if not isinstance(
            obj,
            dict
        ):

            return None

        network = clean_string(
            obj.get("net")
            or obj.get("network")
            or "tcp"
        ).lower()

        data = {
            "type": "vmess",
            "server": (
                obj.get("add")
                or obj.get("address")
            ),
            "port": safe_int(
                obj.get("port"),
                443
            ),
            "uuid": (
                obj.get("id")
                or obj.get("uuid")
            ),
            "alterId": safe_int(
                obj.get("aid"),
                0
            ),
            "cipher": (
                obj.get("scy")
                or obj.get("cipher")
                or "auto"
            ),
            "network": network,
            "tls": str(
                obj.get(
                    "tls",
                    ""
                )
            ).lower() in (
                "tls",
                "true",
                "1",
            ),
            "udp": True,
        }

        sni = (
            obj.get("sni")
            or obj.get("servername")
            or obj.get("host")
        )

        if sni:

            data["servername"] = sni

            data["sni"] = sni

        # ----------------------------------------------------
        # WebSocket
        # ----------------------------------------------------

        if network == "ws":

            path = (
                obj.get("path")
                or "/"
            )

            host = (
                obj.get("host")
                or ""
            )

            ws_opts = {
                "path": path,
                "headers": {},
            }

            if host:

                ws_opts[
                    "headers"
                ]["Host"] = host

            data[
                "ws-opts"
            ] = ws_opts

        # ----------------------------------------------------
        # gRPC
        # ----------------------------------------------------

        elif network == "grpc":

            service = (
                obj.get(
                    "serviceName"
                )
                or obj.get(
                    "service-name"
                )
                or obj.get(
                    "path",
                    ""
                )
            )

            grpc_opts = {}

            if service:

                grpc_opts[
                    "grpc-service-name"
                ] = service

            if grpc_opts:

                data[
                    "grpc-opts"
                ] = grpc_opts

        name = (
            obj.get("ps")
            or obj.get("name")
            or ""
        )

        if name:

            data["name"] = name

        return ProxyNormalizer.normalize(
            data
        )

    except Exception:

        return None


# ============================================================
# TROJAN
# ============================================================

def parse_trojan(
    url: str
) -> Optional[Proxy]:

    try:

        parsed = urlparse(
            url
        )

        password = unquote(
            parsed.username or ""
        )

        host = safe_host(
            parsed.hostname or ""
        )

        port = (
            parsed.port
            or 443
        )

        if not password or not host:
            return None

        qs = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        data = {
            "type": "trojan",
            "server": host,
            "port": port,
            "password": password,
            "udp": True,
            "tls": True,
        }

        sni = query_first(
            qs,
            "sni",
            "peer",
            "servername"
        )

        if sni:

            data["sni"] = sni

            data["servername"] = sni

        network = query_first(
            qs,
            "type",
            "network",
            default=""
        ).lower()

        if network:

            data[
                "network"
            ] = network

        if network == "ws":

            ws_opts = {
                "path": query_first(
                    qs,
                    "path",
                    default="/"
                ),
                "headers": {},
            }

            host_header = query_first(
                qs,
                "host",
                default=""
            )

            if host_header:

                ws_opts[
                    "headers"
                ]["Host"] = host_header

            data[
                "ws-opts"
            ] = ws_opts

        elif network == "grpc":

            service = query_first(
                qs,
                "serviceName",
                "service-name",
                default=""
            )

            if service:

                data[
                    "grpc-opts"
                ] = {
                    "grpc-service-name":
                        service
                }

        if parsed.fragment:

            data["name"] = unquote(
                parsed.fragment
            )

        return ProxyNormalizer.normalize(
            data
        )

    except Exception:

        return None


# ============================================================
# SHADOWSOCKS
# ============================================================

def parse_ss(
    url: str
) -> Optional[Proxy]:

    try:

        parsed = urlparse(
            url
        )

        netloc = parsed.netloc

        # ----------------------------------------------------
        # Modern:
        # ss://BASE64@host:port
        # ----------------------------------------------------

        if "@" in netloc:

            user_part, host_part = (
                netloc.rsplit(
                    "@",
                    1
                )
            )

            decoded_user = (
                b64_decode_text(
                    user_part
                )
            )

            if (
                decoded_user
                and ":"
                in decoded_user
            ):

                cipher, password = (
                    decoded_user.split(
                        ":",
                        1
                    )
                )

            elif ":" in user_part:

                cipher, password = (
                    user_part.split(
                        ":",
                        1
                    )
                )

            else:

                return None

            host, port = (
                split_host_port(
                    host_part,
                    443
                )
            )

        # ----------------------------------------------------
        # Legacy:
        # ss://BASE64
        # ----------------------------------------------------

        else:

            decoded = (
                b64_decode_text(
                    netloc
                )
            )

            if (
                not decoded
                or "@"
                not in decoded
            ):

                return None

            user_part, host_part = (
                decoded.rsplit(
                    "@",
                    1
                )
            )

            if ":" not in user_part:

                return None

            cipher, password = (
                user_part.split(
                    ":",
                    1
                )
            )

            host, port = (
                split_host_port(
                    host_part,
                    443
                )
            )

        if (
            not cipher
            or not password
            or not host
        ):

            return None

        data = {
            "type": "ss",
            "server": host,
            "port": port,
            "cipher": cipher,
            "password": password,
            "udp": True,
        }

        if parsed.fragment:

            data["name"] = unquote(
                parsed.fragment
            )

        return ProxyNormalizer.normalize(
            data
        )

    except Exception:

        return None


# ============================================================
# SSR
# ============================================================

def parse_ssr(
    url: str
) -> Optional[Proxy]:

    try:

        encoded = url[
            len("ssr://"):
        ]

        decoded = b64_decode_text(
            encoded
        )

        if not decoded:
            return None

        main, _, query = (
            decoded.partition(
                "/?"
            )
        )

        parts = main.split(
            ":"
        )

        if len(parts) < 6:
            return None

        server = parts[0]

        port = safe_int(
            parts[1]
        )

        protocol = parts[2]

        cipher = parts[3]

        obfs = parts[4]

        password = (
            b64_decode_text(
                parts[5]
            )
            or parts[5]
        )

        qs = parse_qs(
            query,
            keep_blank_values=True
        )

        data = {
            "type": "ssr",
            "server": server,
            "port": port,
            "protocol": protocol,
            "cipher": cipher,
            "obfs": obfs,
            "password": password,
            "protocol-param":
                query_first(
                    qs,
                    "protoparam"
                ),
            "obfs-param":
                query_first(
                    qs,
                    "obfsparam"
                ),
            "udp": True,
        }

        return ProxyNormalizer.normalize(
            data
        )

    except Exception:

        return None


# ============================================================
# HYSTERIA / HYSTERIA2
# ============================================================

def parse_hysteria(
    url: str
) -> Optional[Proxy]:

    try:

        parsed = urlparse(
            url
        )

        host = safe_host(
            parsed.hostname or ""
        )

        port = (
            parsed.port
            or 443
        )

        qs = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        password = unquote(
            parsed.username or ""
        )

        if not password:

            password = query_first(
                qs,
                "password",
                "auth",
                default=""
            )

        scheme = normalize_scheme(
            parsed.scheme
        )

        if scheme in (
            "hysteria2",
            "hy2",
        ):

            proxy_type = (
                "hysteria2"
            )

        else:

            proxy_type = (
                "hysteria"
            )

        data = {
            "type": proxy_type,
            "server": host,
            "port": port,
            "password": password,
            "udp": True,
        }

        sni = query_first(
            qs,
            "sni",
            "peer",
            "servername"
        )

        if sni:

            data["sni"] = sni

            data[
                "servername"
            ] = sni

        obfs = query_first(
            qs,
            "obfs"
        )

        if obfs:

            data[
                "obfs"
            ] = obfs

        obfs_password = query_first(
            qs,
            "obfs-password"
        )

        if obfs_password:

            data[
                "obfs-password"
            ] = obfs_password

        if parsed.fragment:

            data["name"] = unquote(
                parsed.fragment
            )

        return ProxyNormalizer.normalize(
            data
        )

    except Exception:

        return None


# ============================================================
# TUIC
# ============================================================

def parse_tuic(
    url: str
) -> Optional[Proxy]:

    try:

        parsed = urlparse(
            url
        )

        uuid = unquote(
            parsed.username or ""
        )

        password = unquote(
            parsed.password or ""
        )

        host = safe_host(
            parsed.hostname or ""
        )

        port = (
            parsed.port
            or 443
        )

        if not uuid or not host:
            return None

        qs = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        data = {
            "type": "tuic",
            "server": host,
            "port": port,
            "uuid": uuid,
            "password": password,
            "udp": True,
        }

        sni = query_first(
            qs,
            "sni",
            "server",
            "servername"
        )

        if sni:

            data["sni"] = sni

            data[
                "servername"
            ] = sni

        congestion = query_first(
            qs,
            "congestion-controller"
        )

        if congestion:

            data[
                "congestion-controller"
            ] = congestion

        if parsed.fragment:

            data["name"] = unquote(
                parsed.fragment
            )

        return ProxyNormalizer.normalize(
            data
        )

    except Exception:

        return None


# ============================================================
# WIREGUARD
# ============================================================

def parse_wireguard_url(
    url: str
) -> Optional[Proxy]:

    try:

        parsed = urlparse(
            url
        )

        host = safe_host(
            parsed.hostname or ""
        )

        port = (
            parsed.port
            or 51820
        )

        qs = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        data = {
            "type": "wireguard",
            "server": host,
            "port": port,
            "udp": True,
        }

        mapping = {
            "private-key":
                "private-key",
            "public-key":
                "public-key",
            "preshared-key":
                "preshared-key",
            "ip":
                "ip",
            "ipv6":
                "ipv6",
            "mtu":
                "mtu",
        }

        for source, target in (
            mapping.items()
        ):

            value = query_first(
                qs,
                source
            )

            if value:

                data[target] = value

        if parsed.username:

            data[
                "private-key"
            ] = unquote(
                parsed.username
            )

        if parsed.fragment:

            data["name"] = unquote(
                parsed.fragment
            )

        return ProxyNormalizer.normalize(
            data
        )

    except Exception:

        return None


# ============================================================
# URL DISPATCHER
# ============================================================

def parse_url(
    url: str
) -> Optional[Proxy]:

    url = clean_string(
        url
    )

    low = url.lower()

    if low.startswith(
        "vless://"
    ):

        return parse_vless(
            url
        )

    if low.startswith(
        "vmess://"
    ):

        return parse_vmess(
            url
        )

    if low.startswith(
        "trojan://"
    ):

        return parse_trojan(
            url
        )

    if low.startswith(
        "ss://"
    ):

        return parse_ss(
            url
        )

    if low.startswith(
        "ssr://"
    ):

        return parse_ssr(
            url
        )

    if low.startswith(
        (
            "hysteria://",
            "hysteria2://",
            "hy2://",
        )
    ):

        return parse_hysteria(
            url
        )

    if low.startswith(
        "tuic://"
    ):

        return parse_tuic(
            url
        )

    if low.startswith(
        (
            "wg://",
            "wireguard://",
        )
    ):

        return parse_wireguard_url(
            url
        )

    return None


# ============================================================
# STRUCTURED DATA
# ============================================================

def extract_proxy_dicts(
    obj: Any
) -> List[Dict[str, Any]]:

    result = []

    if isinstance(
        obj,
        dict
    ):

        if "proxies" in obj:

            proxies = obj.get(
                "proxies"
            )

            if isinstance(
                proxies,
                list
            ):

                for item in proxies:

                    if isinstance(
                        item,
                        dict
                    ):

                        result.append(
                            item
                        )

        if (
            "type" in obj
            and "server" in obj
        ):

            result.append(
                obj
            )

        for value in obj.values():

            if isinstance(
                value,
                (dict, list)
            ):

                result.extend(
                    extract_proxy_dicts(
                        value
                    )
                )

    elif isinstance(
        obj,
        list
    ):

        for item in obj:

            result.extend(
                extract_proxy_dicts(
                    item
                )
            )

    return result


def parse_structured(
    text: str
) -> List[Proxy]:

    result = []

    # --------------------------------------------------------
    # JSON
    # --------------------------------------------------------

    try:

        obj = json.loads(
            text
        )

        for item in extract_proxy_dicts(
            obj
        ):

            proxy = (
                ProxyNormalizer.normalize(
                    item
                )
            )

            if proxy:

                result.append(
                    proxy
                )

    except Exception:
        pass

    # --------------------------------------------------------
    # YAML
    # --------------------------------------------------------

    try:

        docs = yaml.safe_load_all(
            text
        )

        for doc in docs:

            for item in (
                extract_proxy_dicts(
                    doc
                )
            ):

                proxy = (
                    ProxyNormalizer.normalize(
                        item
                    )
                )

                if proxy:

                    result.append(
                        proxy
                    )

    except Exception:
        pass

    return result


# ============================================================
# INPUT LOADER
# ============================================================

class InputLoader:

    def __init__(
        self,
        path
    ):

        self.path = path

    def read(self) -> str:

        if not os.path.exists(
            self.path
        ):

            return ""

        with open(
            self.path,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as f:

            return f.read()

    def load(
        self
    ) -> List[Proxy]:

        raw = self.read()

        if not raw.strip():

            return []

        result = []

        # ----------------------------------------------------
        # Structured data
        # ----------------------------------------------------

        result.extend(
            parse_structured(
                raw
            )
        )

        # ----------------------------------------------------
        # Line scan
        # ----------------------------------------------------

        lines = raw.splitlines()

        if len(lines) > MAX_INPUT_LINES:

            Logger.warn(
                f"Input limited to "
                f"{MAX_INPUT_LINES} lines"
            )

            lines = lines[
                :MAX_INPUT_LINES
            ]

        for original in lines:

            line = original.strip()

            if not line:
                continue

            if line.startswith(
                (
                    "#",
                    "//",
                    ";",
                )
            ):
                continue

            # ------------------------------------------------
            # Direct URL
            # ------------------------------------------------

            proxy = parse_url(
                line
            )

            if proxy:

                result.append(
                    proxy
                )

                continue

            # ------------------------------------------------
            # Base64 bundle
            # ------------------------------------------------

            if looks_like_base64(
                line
            ):

                decoded = (
                    b64_decode_text(
                        line
                    )
                )

                if decoded:

                    for subline in (
                        decoded.splitlines()
                    ):

                        subline = (
                            subline.strip()
                        )

                        if not subline:
                            continue

                        proxy = parse_url(
                            subline
                        )

                        if proxy:

                            result.append(
                                proxy
                            )

        return result


# ============================================================
# TCP PROBE
# ============================================================

class TCPProbe:

    def __init__(
        self,
        timeout: float = TCP_TIMEOUT,
        retries: int = TCP_RETRIES,
    ):

        self.timeout = timeout

        self.retries = retries

    @staticmethod
    def once(
        host: str,
        port: int,
        timeout: float
    ) -> Optional[int]:

        sock = None

        try:

            start = (
                time.perf_counter()
            )

            # ------------------------------------------------
            # Resolve endpoint
            # ------------------------------------------------

            infos = socket.getaddrinfo(
                host,
                port,
                type=socket.SOCK_STREAM
            )

            if not infos:

                return None

            last_error = None

            # ------------------------------------------------
            # Try resolved addresses
            # ------------------------------------------------

            for info in infos:

                family = info[0]

                sockaddr = info[4]

                try:

                    sock = socket.socket(
                        family,
                        socket.SOCK_STREAM
                    )

                    sock.settimeout(
                        timeout
                    )

                    sock.connect(
                        sockaddr
                    )

                    elapsed = (
                        time.perf_counter()
                        - start
                    )

                    return max(
                        1,
                        int(
                            elapsed * 1000
                        )
                    )

                except Exception as exc:

                    last_error = exc

                    try:

                        if sock:
                            sock.close()

                    except Exception:
                        pass

                    sock = None

            return None

        except Exception:

            return None

        finally:

            try:

                if sock:

                    sock.close()

            except Exception:
                pass

    def test(
        self,
        proxy: Proxy
    ) -> Proxy:

        values = []

        for _ in range(
            self.retries
        ):

            proxy.attempts += 1

            value = self.once(
                proxy.server,
                proxy.port,
                self.timeout
            )

            if value is not None:

                proxy.successes += 1

                values.append(
                    value
                )

        if values:

            values.sort()

            # Median
            proxy.ping = values[
                len(values) // 2
            ]

            proxy.alive = True

        else:

            proxy.ping = None

            proxy.alive = False

        return proxy


# ============================================================
# HEALTH ENGINE
# ============================================================

class HealthEngine:

    def __init__(
        self,
        workers=MAX_WORKERS
    ):

        self.workers = max(
            1,
            min(
                safe_int(
                    workers,
                    8
                ),
                MAX_WORKERS_HARD
            )
        )

        self.probe = TCPProbe()

    def run(
        self,
        proxies: List[Proxy]
    ) -> List[Proxy]:

        if not proxies:
            return []

        total = len(
            proxies
        )

        Logger.info(
            "TCP health check: "
            f"{total} proxies / "
            f"{self.workers} workers"
        )

        completed = 0

        with ThreadPoolExecutor(
            max_workers=self.workers
        ) as executor:

            futures = [
                executor.submit(
                    self.probe.test,
                    proxy
                )
                for proxy in proxies
            ]

            for future in as_completed(
                futures
            ):

                completed += 1

                try:

                    future.result()

                except Exception as exc:

                    Logger.debug(
                        f"Health error: {exc}"
                    )

                if (
                    completed % 100 == 0
                    or completed == total
                ):

                    Logger.info(
                        "Health check "
                        f"{completed}/{total}"
                    )

        return proxies


# ============================================================
# SORT / QUALITY
# ============================================================

def sort_proxies(
    proxies: List[Proxy]
) -> List[Proxy]:

    return sorted(
        proxies,
        key=lambda p: (
            not p.alive,
            p.score(),
            p.ping or 999999,
            p.name.lower(),
        )
    )


# ============================================================
# CLASH EXPORTER
# ============================================================

class ClashExporter:

    @staticmethod
    def clean_proxy(
        proxy: Proxy
    ) -> Dict[str, Any]:

        data = proxy.export()

        # ----------------------------------------------------
        # Remove internal fields
        # ----------------------------------------------------

        for key in (
            "ping",
            "alive",
            "attempts",
            "successes",
            "score",
            "_source",
            "status",
        ):

            data.pop(
                key,
                None
            )

        # ----------------------------------------------------
        # Required fields
        # ----------------------------------------------------

        data["name"] = proxy.name

        data["type"] = proxy.type

        data["server"] = proxy.server

        data["port"] = proxy.port

        # ----------------------------------------------------
        # Normalize common aliases
        # ----------------------------------------------------

        if "servername" in data:

            data["servername"] = (
                clean_string(
                    data["servername"]
                )
            )

        if "sni" in data:

            data["sni"] = (
                clean_string(
                    data["sni"]
                )
            )

        # ----------------------------------------------------
        # Remove empty scalar values
        # ----------------------------------------------------

        for key in list(
            data.keys()
        ):

            value = data[key]

            if value == "":

                data.pop(
                    key,
                    None
                )

            elif value is None:

                data.pop(
                    key,
                    None
                )

        return data

    @classmethod
    def generate(
        cls,
        proxies: List[Proxy]
    ) -> Dict[str, Any]:

        proxies = sort_proxies(
            proxies
        )

        exported = [
            cls.clean_proxy(
                proxy
            )
            for proxy in proxies
        ]

        names = [
            proxy["name"]
            for proxy in exported
        ]

        # ----------------------------------------------------
        # Exactly ONE group
        # ----------------------------------------------------

        group_type = (
            GROUP_TYPE_LOW_DATA
            if MODE == "LOW_DATA"
            else GROUP_TYPE_BALANCED
        )

        group = {
            "name": GROUP_NAME,
            "type": group_type,
            "proxies": names,
        }

        if MODE != "LOW_DATA":

            group["url"] = (
                CLASH_TEST_URL
            )

            group["interval"] = (
                CLASH_INTERVAL
            )

            group["tolerance"] = (
                CLASH_TOLERANCE
            )

        # ----------------------------------------------------
        # Final Clash Meta configuration
        # ----------------------------------------------------

        config = {

            "mixed-port": 7890,

            "allow-lan": False,

            "mode": "rule",

            "log-level": "info",

            "ipv6": True,

            "proxies": exported,

            "proxy-groups": [
                group
            ],

            "rules": [
                f"MATCH,{GROUP_NAME}"
            ],
        }

        return config


# ============================================================
# ATOMIC WRITER
# ============================================================

class AtomicWriter:

    def __init__(
        self,
        path: str
    ):

        self.path = path

        self.temp = (
            path + ".tmp"
        )

    def write_yaml(
        self,
        data: Dict[str, Any]
    ):

        directory = os.path.dirname(
            self.path
        )

        if directory:

            os.makedirs(
                directory,
                exist_ok=True
            )

        content = yaml.safe_dump(
            data,
            allow_unicode=True,
            sort_keys=False,
            default_flow_style=False,
        )

        # ----------------------------------------------------
        # Temporary file
        # ----------------------------------------------------

        with open(
            self.temp,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(
                content
            )

            f.flush()

            os.fsync(
                f.fileno()
            )

        # ----------------------------------------------------
        # Atomic replacement
        # ----------------------------------------------------

        os.replace(
            self.temp,
            self.path
        )


# ============================================================
# INDUSTRIAL ENGINE
# ============================================================

class IndustrialEngine:

    def __init__(
        self,
        input_file: str,
        output_file: str
    ):

        self.input_file = (
            input_file
        )

        self.output_file = (
            output_file
        )

        self.stats = {

            "raw": 0,

            "parsed": 0,

            "unique": 0,

            "tested": 0,

            "alive": 0,

            "dead": 0,

            "exported": 0,
        }

    # --------------------------------------------------------
    # LOAD
    # --------------------------------------------------------

    def load(self):

        Logger.info(
            "Loading input..."
        )

        loader = InputLoader(
            self.input_file
        )

        raw = loader.read()

        self.stats["raw"] = len(
            [
                x
                for x in raw.splitlines()
                if x.strip()
            ]
        )

        proxies = loader.load()

        self.stats["parsed"] = (
            len(proxies)
        )

        Logger.info(
            f"Parsed: {len(proxies)}"
        )

        return proxies

    # --------------------------------------------------------
    # DEDUPLICATE
    # --------------------------------------------------------

    def deduplicate(
        self,
        proxies
    ):

        deduper = Deduper()

        result = deduper.run(
            proxies
        )

        self.stats["unique"] = (
            len(result)
        )

        Logger.info(
            "Deduplicated: "
            f"{len(proxies)} -> "
            f"{len(result)}"
        )

        return result

    # --------------------------------------------------------
    # HEALTH CHECK
    # --------------------------------------------------------

    def health_check(
        self,
        proxies
    ):

        self.stats["tested"] = (
            len(proxies)
        )

        engine = HealthEngine(
            MAX_WORKERS
        )

        proxies = engine.run(
            proxies
        )

        alive = [
            proxy
            for proxy in proxies
            if proxy.alive
        ]

        self.stats["alive"] = (
            len(alive)
        )

        self.stats["dead"] = (
            len(proxies)
            - len(alive)
        )

        return (
            alive
            if KEEP_ALIVE_ONLY
            else proxies
        )

    # --------------------------------------------------------
    # EXPORT
    # --------------------------------------------------------

    def export(
        self,
        proxies
    ):

        proxies = sort_proxies(
            proxies
        )

        if len(proxies) > MAX_PROXIES:

            Logger.warn(
                "Output limited to "
                f"{MAX_PROXIES} proxies"
            )

            proxies = proxies[
                :MAX_PROXIES
            ]

        config = (
            ClashExporter.generate(
                proxies
            )
        )

        writer = AtomicWriter(
            self.output_file
        )

        writer.write_yaml(
            config
        )

        self.stats["exported"] = (
            len(
                config["proxies"]
            )
        )

        return config

    # --------------------------------------------------------
    # RUN
    # --------------------------------------------------------

    def run(self):

        Logger.info(
            "======================================"
        )

        Logger.info(
            f"{ENGINE_NAME} "
            f"{ENGINE_VERSION}"
        )

        Logger.info(
            f"MODE = {MODE}"
        )

        Logger.info(
            "======================================"
        )

        proxies = self.load()

        if not proxies:

            Logger.warn(
                "No valid proxy found."
            )

            return None

        proxies = self.deduplicate(
            proxies
        )

        if not proxies:

            Logger.warn(
                "No unique proxy found."
            )

            return None

        proxies = self.health_check(
            proxies
        )

        if not proxies:

            Logger.warn(
                "No alive proxy found."
            )

            if not KEEP_ALIVE_ONLY:

                return self.export(
                    []
                )

            return None

        config = self.export(
            proxies
        )

        self.print_summary()

        return config

    # --------------------------------------------------------
    # SUMMARY
    # --------------------------------------------------------

    def print_summary(self):

        Logger.info(
            "======================================"
        )

        Logger.info(
            f"Raw lines   : "
            f"{self.stats['raw']}"
        )

        Logger.info(
            f"Parsed      : "
            f"{self.stats['parsed']}"
        )

        Logger.info(
            f"Unique      : "
            f"{self.stats['unique']}"
        )

        Logger.info(
            f"Tested      : "
            f"{self.stats['tested']}"
        )

        Logger.info(
            f"Alive       : "
            f"{self.stats['alive']}"
        )

        Logger.info(
            f"Dead        : "
            f"{self.stats['dead']}"
        )

        Logger.info(
            f"Exported    : "
            f"{self.stats['exported']}"
        )

        Logger.info(
            f"Group       : "
            f"{GROUP_NAME}"
        )

        Logger.info(
            f"Mode        : "
            f"{MODE}"
        )

        Logger.info(
            f"Output      : "
            f"{self.output_file}"
        )

        Logger.info(
            "======================================"
        )


# ============================================================
# INPUT PREPARATION
# ============================================================

def prepare_empty_input():

    """
    IMPORTANT:

    Every execution starts with an empty input.txt.

    The file itself is NOT deleted.
    Only its contents are cleared.

    This guarantees Nano always opens
    a completely empty file.
    """

    os.makedirs(
        BASE_DIR,
        exist_ok=True
    )

    with open(
        INPUT_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        f.truncate(0)

        f.flush()

        os.fsync(
            f.fileno()
        )


# ============================================================
# NANO INPUT EDITOR
# ============================================================

def open_input_editor():

    # --------------------------------------------------------
    # Always empty before Nano
    # --------------------------------------------------------

    prepare_empty_input()

    print()

    print(
        "=============================================="
    )

    print(
        " INPUT CONFIGURATIONS"
    )

    print(
        "=============================================="
    )

    print()

    print(
        f"Input path:"
    )

    print(
        INPUT_FILE
    )

    print()

    print(
        "Nano will open automatically."
    )

    print(
        "Enter your configurations."
    )

    print(
        "Save : Ctrl+O -> Enter"
    )

    print(
        "Exit : Ctrl+X"
    )

    print()

    try:

        result = subprocess.call(
            [
                "nano",
                INPUT_FILE
            ]
        )

        if result != 0:

            Logger.warn(
                "Nano exited with "
                f"code {result}"
            )

    except FileNotFoundError:

        Logger.error(
            "nano is not installed "
            "or is not available."
        )

        sys.exit(1)

    except Exception as exc:

        Logger.error(
            f"Cannot open nano: {exc}"
        )

        sys.exit(1)


# ============================================================
# OUTPUT PATH
# ============================================================

def ask_output_path():

    download_dir = (
        "/storage/emulated/0/Download"
    )

    os.makedirs(
        download_dir,
        exist_ok=True
    )

    print()

    print(
        "=============================================="
    )

    print(
        " OUTPUT"
    )

    print(
        "=============================================="
    )

    # --------------------------------------------------------
    # Folder
    # --------------------------------------------------------

    while True:

        print()

        print(
            "Output folder name in Download:"
        )

        folder = input(
            "> "
        ).strip()

        folder = os.path.basename(
            folder
        )

        folder = re.sub(
            r"[\x00-\x1f\x7f]",
            "",
            folder
        )

        if not folder:

            print(
                "ERROR: folder name "
                "cannot be empty."
            )

            continue

        if folder in (
            ".",
            "..",
        ):

            print(
                "ERROR: invalid folder name."
            )

            continue

        break

    output_dir = os.path.join(
        download_dir,
        folder
    )

    os.makedirs(
        output_dir,
        exist_ok=True
    )

    # --------------------------------------------------------
    # Filename
    # --------------------------------------------------------

    while True:

        print()

        print(
            "Output file name "
            "(without extension):"
        )

        filename = input(
            "> "
        ).strip()

        filename = os.path.basename(
            filename
        )

        filename = os.path.splitext(
            filename
        )[0]

        filename = re.sub(
            r"[\x00-\x1f\x7f]",
            "",
            filename
        )

        if not filename:

            print(
                "ERROR: filename "
                "cannot be empty."
            )

            continue

        if filename in (
            ".",
            "..",
        ):

            print(
                "ERROR: invalid filename."
            )

            continue

        break

    return os.path.join(
        output_dir,
        filename + ".yaml"
    )


# ============================================================
# VERIFY OUTPUT
# ============================================================

def verify_output(
    path: str
) -> bool:

    try:

        if not os.path.isfile(
            path
        ):

            return False

        size = os.path.getsize(
            path
        )

        if size <= 0:

            return False

        # ----------------------------------------------------
        # Verify YAML is readable
        # ----------------------------------------------------

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            content = f.read()

        if not content.strip():

            return False

        parsed = yaml.safe_load(
            content
        )

        if not isinstance(
            parsed,
            dict
        ):

            return False

        if "proxies" not in parsed:

            return False

        if "proxy-groups" not in parsed:

            return False

        if not isinstance(
            parsed["proxies"],
            list
        ):

            return False

        if not isinstance(
            parsed["proxy-groups"],
            list
        ):

            return False

        # Exactly one group
        if len(
            parsed["proxy-groups"]
        ) != 1:

            return False

        return True

    except Exception as exc:

        Logger.error(
            f"Output verification failed: "
            f"{exc}"
        )

        return False


# ============================================================
# CLEAR INPUT AFTER SUCCESS
# ============================================================

def clear_input_after_success():

    """
    IMPORTANT:

    input.txt is cleared ONLY after:
      - engine succeeded
      - output exists
      - output is non-empty
      - output YAML is valid
      - exactly one proxy-group exists
    """

    try:

        with open(
            INPUT_FILE,
            "w",
            encoding="utf-8"
        ) as f:

            f.truncate(0)

            f.flush()

            os.fsync(
                f.fileno()
            )

        # Final verification
        if os.path.getsize(
            INPUT_FILE
        ) != 0:

            Logger.error(
                "input.txt could not "
                "be emptied."
            )

            return False

        Logger.info(
            "input.txt cleared successfully."
        )

        return True

    except Exception as exc:

        Logger.error(
            f"Cannot clear input.txt: "
            f"{exc}"
        )

        return False


# ============================================================
# MAIN
# ============================================================

def main():

    output_file = None

    config = None

    try:

        # ----------------------------------------------------
        # Prepare fixed directory
        # ----------------------------------------------------

        os.makedirs(
            BASE_DIR,
            exist_ok=True
        )

        # ----------------------------------------------------
        # Header
        # ----------------------------------------------------

        print()

        print(
            "=============================================="
        )

        print(
            " CLASH META INDUSTRIAL ENGINE"
        )

        print(
            f" {ENGINE_VERSION}"
        )

        print(
            "=============================================="
        )

        print()

        print(
            f"Input:"
        )

        print(
            INPUT_FILE
        )

        print()

        print(
            f"Mode: {MODE}"
        )

        print()

        # ----------------------------------------------------
        # IMPORTANT:
        #
        # This automatically:
        # 1. empties input.txt
        # 2. opens Nano
        #
        # NO QUESTION
        # ----------------------------------------------------

        open_input_editor()

        # ----------------------------------------------------
        # Check input after Nano
        # ----------------------------------------------------

        if not os.path.exists(
            INPUT_FILE
        ):

            Logger.error(
                "input.txt does not exist."
            )

            sys.exit(1)

        if os.path.getsize(
            INPUT_FILE
        ) == 0:

            Logger.warn(
                "input.txt is empty."
            )

            print()

            print(
                "No configuration was entered."
            )

            print(
                "Nothing was generated."
            )

            sys.exit(1)

        # ----------------------------------------------------
        # Ask output path
        #
        # ONLY AFTER NANO
        # ----------------------------------------------------

        output_file = (
            ask_output_path()
        )

        print()

        print(
            "=============================================="
        )

        print(
            " PROCESSING"
        )

        print(
            "=============================================="
        )

        print()

        # ----------------------------------------------------
        # Create engine
        # ----------------------------------------------------

        engine = IndustrialEngine(
            INPUT_FILE,
            output_file
        )

        # ----------------------------------------------------
        # Run
        # ----------------------------------------------------

        config = engine.run()

        # ----------------------------------------------------
        # Engine failed
        # ----------------------------------------------------

        if config is None:

            print()

            print(
                "=============================================="
            )

            print(
                " OUTPUT NOT GENERATED"
            )

            print(
                "=============================================="
            )

            print()

            print(
                "input.txt was NOT cleared."
            )

            print(
                "Your configurations are preserved."
            )

            print()

            sys.exit(1)

        # ----------------------------------------------------
        # Verify output exists and is valid
        # ----------------------------------------------------

        if not verify_output(
            output_file
        ):

            Logger.error(
                "Output verification failed."
            )

            print()

            print(
                "input.txt was NOT cleared."
            )

            print(
                "Your configurations are preserved."
            )

            sys.exit(1)

        # ----------------------------------------------------
        # ONLY NOW clear input
        # ----------------------------------------------------

        if not clear_input_after_success():

            print()

            print(
                "WARNING:"
            )

            print(
                "Output was created successfully,"
            )

            print(
                "but input.txt could not be cleared."
            )

            print(
                f"Output: {output_file}"
            )

            sys.exit(1)

        # ----------------------------------------------------
        # Final success
        # ----------------------------------------------------

        print()

        print(
            "=============================================="
        )

        print(
            " DONE"
        )

        print(
            "=============================================="
        )

        print(
            f"Output : {output_file}"
        )

        print(
            f"Proxies: "
            f"{len(config.get('proxies', []))}"
        )

        print(
            f"Groups : "
            f"{len(config.get('proxy-groups', []))}"
        )

        print()

        print(
            "input.txt has been cleared."
        )

        print(
            "Next execution will open a "
            "completely empty Nano."
        )

        print()

        print(
            "=============================================="
        )

    except KeyboardInterrupt:

        print()

        print(
            "Stopped by user."
        )

        print(
            "input.txt was preserved."
        )

        sys.exit(130)

    except Exception as exc:

        Logger.error(
            f"Fatal error: {exc}"
        )

        print()

        print(
            "=============================================="
        )

        print(
            "ERROR"
        )

        print(
            "=============================================="
        )

        print(
            f"{exc}"
        )

        print()

        print(
            "input.txt was NOT cleared."
        )

        print(
            "Your configurations are preserved."
        )

        sys.exit(1)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()
