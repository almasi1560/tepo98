#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-

"""
===============================================================
 Mihomo / Clash Meta INDUSTRIAL UNIFIED PARSER
 Android / Termux
===============================================================

BASELINE:
    User supplied Unified Parser

DESIGN:
    - Low-data testing
    - DNS cache
    - IPv4 / IPv6 intelligence
    - TCP reachability
    - Adaptive workers
    - Batch processing
    - Persistent result cache
    - TTL
    - Smart deduplication
    - Subscription/Base64 decoding
    - JSON/YAML parsing
    - Mihomo compatibility validation
    - Final YAML validation
    - Reports
    - Failed input report
    - Atomic output
    - Automatic URL-Test groups
    - Automatic DNS section
    - No interactive test-mode questions
    - Nano input file is always empty at start
    - Input file is cleared after successful output

IMPORTANT:
    Runtime testing performs NO HTTP download.
    Runtime testing is limited to DNS resolution + TCP connect.
===============================================================
"""

import os
import re
import sys
import json
import time
import socket
import base64
import hashlib
import tempfile
import subprocess
import threading
from urllib.parse import (
    urlparse,
    parse_qs,
    unquote
)
from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed
)
from collections import Counter


# ============================================================
# OPTIONAL YAML
# ============================================================

try:
    import yaml
except ImportError:
    print("[ERROR] PyYAML is not installed.")
    print("Install with:")
    print("pip install pyyaml")
    sys.exit(1)


# ============================================================
# PATHS
# ============================================================

BASE_DIR = "/storage/emulated/0/Download/Akbar98"

os.makedirs(
    BASE_DIR,
    exist_ok=True
)

INPUT_PATH = os.path.join(
    BASE_DIR,
    "input.txt"
)

CACHE_PATH = os.path.join(
    BASE_DIR,
    ".mihomo_test_cache.json"
)

REPORT_PATH = os.path.join(
    BASE_DIR,
    "mihomo_report.txt"
)

FAILED_PATH = os.path.join(
    BASE_DIR,
    "mihomo_failed.txt"
)


# ============================================================
# INDUSTRIAL CONSTANTS
# ============================================================

CACHE_VERSION = 3

DNS_TTL = 300

TCP_TTL = 600

CACHE_MAX_ENTRIES = 20000

DEFAULT_TIMEOUT = 1.25

DNS_TIMEOUT = 1.50

TCP_ATTEMPTS = 1

BATCH_SIZE = 100

MAX_WORKERS = 32

MIN_WORKERS = 4

MAX_BATCH = 150

OUTPUT_ENCODING = "utf-8"


# ============================================================
# GLOBAL STATE
# ============================================================

_used_names = set()

_name_lock = threading.Lock()

_dns_cache = {}

_dns_lock = threading.Lock()

_result_cache = {}

_cache_lock = threading.Lock()


# ============================================================
# INPUT FILE
# ============================================================

# Every run starts with an EMPTY Nano file.
try:
    with open(
        INPUT_PATH,
        "w",
        encoding=OUTPUT_ENCODING
    ) as f:
        f.write("")
except Exception as e:
    print("[ERROR] Cannot initialize input.txt:")
    print(e)
    sys.exit(1)


# ============================================================
# OPEN NANO
# ============================================================

try:

    subprocess.call(
        ["nano", INPUT_PATH]
    )

except Exception:

    print(
        "[INFO] Nano unavailable."
    )

    print(
        f"[INFO] Edit manually: {INPUT_PATH}"
    )


# ============================================================
# OUTPUT SETTINGS
# ============================================================

out_folder = input(
    "Enter output folder name in Download: "
).strip()

if not out_folder:

    out_folder = "ClashMetaExport"


OUT_DIR = os.path.join(
    "/storage/emulated/0/Download",
    out_folder
)

os.makedirs(
    OUT_DIR,
    exist_ok=True
)


out_name = input(
    "Enter output file name (without extension): "
).strip()

if not out_name:

    out_name = (
        f"clash_meta_"
        f"{int(time.time())}"
    )


if out_name.lower().endswith(".yaml"):

    OUT_PATH = os.path.join(
        OUT_DIR,
        out_name
    )

else:

    OUT_PATH = os.path.join(
        OUT_DIR,
        out_name + ".yaml"
    )


REPORT_OUT = os.path.join(
    OUT_DIR,
    "report.txt"
)

FAILED_OUT = os.path.join(
    OUT_DIR,
    "failed.txt"
)


# ============================================================
# BASIC UTILITIES
# ============================================================

def now():

    return int(
        time.time()
    )


def safe_int(
    value,
    default=0
):

    try:

        return int(value)

    except Exception:

        try:

            return int(
                float(value)
            )

        except Exception:

            return default


def b64fix(value):

    if not value:

        return ""

    value = str(value).strip()

    value = (
        value
        .replace("\n", "")
        .replace("\r", "")
        .replace(" ", "")
    )

    value = (
        value
        .replace("-", "+")
        .replace("_", "/")
    )

    padding = len(value) % 4

    if padding:

        value += "=" * (
            4 - padding
        )

    return value


def b64decode_text(value):

    try:

        raw = base64.b64decode(
            b64fix(value),
            validate=False
        )

        return raw.decode(
            "utf-8",
            "ignore"
        )

    except Exception:

        return ""


def b64encode_text(value):

    return base64.b64encode(
        str(value).encode(
            "utf-8"
        )
    ).decode(
        "ascii"
    )


def is_probably_base64(value):

    if not isinstance(
        value,
        str
    ):

        return False

    value = value.strip()

    if len(value) < 16:

        return False

    if "://" in value:

        return False

    try:

        decoded = b64decode_text(
            value
        )

        if not decoded:

            return False

        if (
            "://" in decoded
            or "\n" in decoded
            or decoded.lstrip().startswith("{")
            or decoded.lstrip().startswith("[")
        ):

            return True

    except Exception:

        pass

    return False


def sanitize(value):

    if value is None:

        return ""

    value = str(value)

    value = re.sub(
        r"[^A-Za-z0-9_\- .\u0600-\u06FF]",
        "",
        value
    )

    value = re.sub(
        r"\s+",
        " ",
        value
    )

    return value.strip()


def uniq_name(base):

    base = (
        sanitize(base)
        or "Proxy"
    )

    with _name_lock:

        name = base

        counter = 2

        while name in _used_names:

            name = (
                f"{base} "
                f"{counter}"
            )

            counter += 1

        _used_names.add(name)

        return name


def tail(
    value,
    length=6
):

    if not value:

        return ""

    value = re.sub(
        r"-",
        "",
        str(value)
    )

    return value[-length:]


def normalize_host(host):

    if not host:

        return ""

    host = str(host).strip()

    host = host.strip("[]")

    return host.lower()


def normalize_protocol(value):

    return str(
        value or ""
    ).strip().lower()


# ============================================================
# DNS CACHE
# ============================================================

def dns_cache_get(host):

    host = normalize_host(host)

    if not host:

        return None

    with _dns_lock:

        item = _dns_cache.get(host)

        if not item:

            return None

        if now() - item["time"] > DNS_TTL:

            del _dns_cache[host]

            return None

        return item


def dns_cache_set(
    host,
    addresses
):

    host = normalize_host(host)

    if not host:

        return

    item = {
        "time": now(),
        "addresses": addresses
    }

    with _dns_lock:

        _dns_cache[host] = item


def resolve_host(host):

    host = normalize_host(host)

    if not host:

        return {
            "ok": False,
            "ipv4": [],
            "ipv6": [],
            "addresses": []
        }

    cached = dns_cache_get(host)

    if cached:

        addresses = cached[
            "addresses"
        ]

        return {
            "ok": bool(addresses),
            "ipv4": [
                x for x in addresses
                if "." in x
            ],
            "ipv6": [
                x for x in addresses
                if ":" in x
            ],
            "addresses": addresses
        }

    ipv4 = []

    ipv6 = []

    try:

        old_timeout = socket.getdefaulttimeout()

        socket.setdefaulttimeout(
            DNS_TIMEOUT
        )

        records = socket.getaddrinfo(
            host,
            None,
            socket.AF_UNSPEC,
            socket.SOCK_STREAM
        )

        socket.setdefaulttimeout(
            old_timeout
        )

        for record in records:

            try:

                address = record[4][0]

            except Exception:

                continue

            if ":" in address:

                if address not in ipv6:

                    ipv6.append(
                        address
                    )

            else:

                if address not in ipv4:

                    ipv4.append(
                        address
                    )

    except Exception:

        try:

            socket.setdefaulttimeout(
                None
            )

        except Exception:

            pass

    addresses = (
        ipv4 +
        ipv6
    )

    dns_cache_set(
        host,
        addresses
    )

    return {
        "ok": bool(addresses),
        "ipv4": ipv4,
        "ipv6": ipv6,
        "addresses": addresses
    }


# ============================================================
# TCP TEST
# ============================================================

def tcp_connect_one(
    address,
    port,
    timeout=DEFAULT_TIMEOUT
):

    family = (
        socket.AF_INET6
        if ":" in address
        else socket.AF_INET
    )

    sock = None

    try:

        sock = socket.socket(
            family,
            socket.SOCK_STREAM
        )

        sock.settimeout(
            timeout
        )

        start = time.monotonic()

        if family == socket.AF_INET6:

            sock.connect(
                (address, int(port), 0, 0)
            )

        else:

            sock.connect(
                (address, int(port))
            )

        elapsed = int(
            (
                time.monotonic()
                - start
            ) * 1000
        )

        return elapsed

    except Exception:

        return None

    finally:

        try:

            if sock:

                sock.close()

        except Exception:

            pass


def tcp_check(
    host,
    port,
    timeout=DEFAULT_TIMEOUT
):

    dns = resolve_host(
        host
    )

    if not dns["ok"]:

        return {
            "status": "DNS_FAIL",
            "latency": None,
            "family": None,
            "ipv4": [],
            "ipv6": []
        }

    results = []

    # IPv4 and IPv6 are attempted independently.
    # One failing family does NOT kill the proxy.

    for address in dns["ipv4"]:

        latency = tcp_connect_one(
            address,
            port,
            timeout
        )

        if latency is not None:

            results.append(
                (
                    latency,
                    "IPv4"
                )
            )

    for address in dns["ipv6"]:

        latency = tcp_connect_one(
            address,
            port,
            timeout
        )

        if latency is not None:

            results.append(
                (
                    latency,
                    "IPv6"
                )
            )

    if not results:

        return {
            "status": "TCP_FAIL",
            "latency": None,
            "family": None,
            "ipv4": dns["ipv4"],
            "ipv6": dns["ipv6"]
        }

    results.sort(
        key=lambda x: x[0]
    )

    best_latency, family = results[0]

    return {
        "status": "TCP_OK",
        "latency": best_latency,
        "family": family,
        "ipv4": dns["ipv4"],
        "ipv6": dns["ipv6"]
    }


# ============================================================
# PERSISTENT CACHE
# ============================================================

def load_cache():

    global _result_cache

    try:

        if not os.path.exists(
            CACHE_PATH
        ):

            _result_cache = {}

            return

        with open(
            CACHE_PATH,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

        if (
            not isinstance(data, dict)
            or data.get("version") != CACHE_VERSION
        ):

            _result_cache = {}

            return

        entries = data.get(
            "entries",
            {}
        )

        if not isinstance(
            entries,
            dict
        ):

            entries = {}

        _result_cache = entries

    except Exception:

        _result_cache = {}


def save_cache():

    with _cache_lock:

        # prune oldest entries
        if len(_result_cache) > CACHE_MAX_ENTRIES:

            items = sorted(
                _result_cache.items(),
                key=lambda x:
                x[1].get(
                    "timestamp",
                    0
                ),
                reverse=True
            )

            _result_cache.clear()

            for key, value in items[
                :CACHE_MAX_ENTRIES
            ]:

                _result_cache[key] = value

        data = {
            "version": CACHE_VERSION,
            "entries": _result_cache
        }

    tmp = CACHE_PATH + ".tmp"

    try:

        with open(
            tmp,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                data,
                f,
                ensure_ascii=False,
                separators=(",", ":")
            )

        os.replace(
            tmp,
            CACHE_PATH
        )

    except Exception:

        try:

            if os.path.exists(tmp):

                os.remove(tmp)

        except Exception:

            pass


def cache_get(
    fingerprint
):

    with _cache_lock:

        item = _result_cache.get(
            fingerprint
        )

        if not item:

            return None

        timestamp = safe_int(
            item.get(
                "timestamp",
                0
            )
        )

        if now() - timestamp > TCP_TTL:

            return None

        return dict(item)


def cache_set(
    fingerprint,
    result
):

    # Do NOT store credentials.
    safe_result = {
        "timestamp": now(),
        "status": result.get(
            "status"
        ),
        "latency": result.get(
            "latency"
        ),
        "family": result.get(
            "family"
        )
    }

    with _cache_lock:

        _result_cache[
            fingerprint
        ] = safe_result


# ============================================================
# FINGERPRINT
# ============================================================

def canonical_value(
    value
):

    if isinstance(
        value,
        dict
    ):

        return {
            str(k): canonical_value(v)
            for k, v in sorted(
                value.items(),
                key=lambda x:
                str(x[0])
            )
            if k not in (
                "name",
                "remark",
                "remarks"
            )
        }

    if isinstance(
        value,
        list
    ):

        return [
            canonical_value(x)
            for x in value
        ]

    return value


def proxy_fingerprint(
    proxy
):

    clean = canonical_value(
        proxy
    )

    raw = json.dumps(
        clean,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":")
    )

    return hashlib.sha256(
        raw.encode(
            "utf-8"
        )
    ).hexdigest()


# ============================================================
# SMART DEDUPLICATION
# ============================================================

def dedupe_key(
    proxy
):

    t = normalize_protocol(
        proxy.get("type")
    )

    server = normalize_host(
        proxy.get("server")
    )

    port = safe_int(
        proxy.get("port")
    )

    # Authentication must participate.
    # Different credentials must NEVER collapse.

    identity = []

    for key in (
        "uuid",
        "password",
        "username",
        "private_key",
        "public_key",
        "cipher",
        "encryption",
        "alterId",
        "network",
        "tls",
        "servername",
        "sni",
        "reality-opts",
        "ws-opts",
        "grpc-opts",
        "alpn",
        "protocol",
        "obfs"
    ):

        if key in proxy:

            identity.append(
                (
                    key,
                    canonical_value(
                        proxy[key]
                    )
                )
            )

    return (
        t,
        server,
        port,
        json.dumps(
            identity,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":")
        )
    )


def dedupe_proxies(
    proxies
):

    result = []

    seen_exact = set()

    for proxy in proxies:

        if not isinstance(
            proxy,
            dict
        ):

            continue

        key = dedupe_key(
            proxy
        )

        if key in seen_exact:

            continue

        seen_exact.add(
            key
        )

        result.append(
            proxy
        )

    return result


# ============================================================
# PARSERS
# ============================================================

def parse_vless(line):

    try:

        raw = line[8:]

        fragment = ""

        if "#" in raw:

            raw, fragment = raw.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        if "?" in raw:

            main, query = raw.split(
                "?",
                1
            )

        else:

            main = raw
            query = ""

        if "@" not in main:

            return None

        uid, hostport = main.split(
            "@",
            1
        )

        uid = unquote(
            uid
        )

        if hostport.startswith("["):

            end = hostport.find("]")

            if end == -1:

                return None

            host = hostport[
                1:end
            ]

            remaining = hostport[
                end + 1:
            ]

            if remaining.startswith(":"):

                port = safe_int(
                    remaining[1:],
                    443
                )

            else:

                port = 443

        else:

            if ":" in hostport:

                host, port_text = (
                    hostport.rsplit(
                        ":",
                        1
                    )
                )

                port = safe_int(
                    port_text,
                    443
                )

            else:

                host = hostport
                port = 443

        q = parse_qs(
            query,
            keep_blank_values=True
        )

        def qv(key, default=""):

            return q.get(
                key,
                [default]
            )[0]

        net = (
            qv("type")
            or qv("network")
            or "tcp"
        ).lower()

        security = (
            qv("security")
            or ""
        ).lower()

        name = (
            fragment
            or qv("remark")
            or f"vless-{host}-{tail(uid)}"
        )

        proxy = {
            "name": uniq_name(name),
            "type": "vless",
            "server": host,
            "port": port,
            "uuid": uid,
            "encryption": qv(
                "encryption",
                "none"
            ),
            "network": net,
            "udp": True
        }

        if security in (
            "tls",
            "reality"
        ):

            proxy["tls"] = True

            proxy["servername"] = (
                qv("sni")
                or qv("servername")
                or qv("host")
                or host
            )

        if net == "ws":

            ws = {
                "path": qv(
                    "path",
                    "/"
                )
            }

            host_header = (
                qv("host")
                or qv("Host")
            )

            if host_header:

                ws["headers"] = {
                    "Host": host_header
                }

            proxy["ws-opts"] = ws

        if net == "grpc":

            service = (
                qv("serviceName")
                or qv("service")
            )

            if service:

                proxy["grpc-opts"] = {
                    "grpc-service-name":
                        service
                }

        if (
            security == "reality"
            or qv("pbk")
            or qv("sid")
        ):

            proxy["tls"] = True

            proxy["reality-opts"] = {
                "public-key": qv(
                    "pbk"
                ),
                "short-id": qv(
                    "sid"
                ),
                "server-name": (
                    qv("sni")
                    or host
                )
            }

        return proxy

    except Exception:

        return None


def parse_vmess(line):

    try:

        raw = line[8:].strip()

        decoded = b64decode_text(
            raw
        )

        try:

            data = json.loads(
                decoded
            )

        except Exception:

            data = json.loads(
                unquote(raw)
            )

        host = (
            data.get("add")
            or data.get("address")
            or data.get("server")
        )

        port = safe_int(
            data.get("port"),
            0
        )

        uid = (
            data.get("id")
            or data.get("uuid")
        )

        if not (
            host
            and port
            and uid
        ):

            return None

        net = (
            data.get("net")
            or "tcp"
        ).lower()

        name = (
            data.get("ps")
            or f"vmess-{host}-{tail(uid)}"
        )

        proxy = {
            "name": uniq_name(name),
            "type": "vmess",
            "server": host,
            "port": port,
            "uuid": uid,
            "alterId": safe_int(
                data.get(
                    "aid",
                    data.get(
                        "alterId",
                        0
                    )
                )
            ),
            "cipher": (
                data.get("scy")
                or data.get("cipher")
                or "auto"
            ),
            "network": net,
            "udp": True
        }

        if str(
            data.get("tls", "")
        ).lower() == "tls":

            proxy["tls"] = True

            proxy["servername"] = (
                data.get("sni")
                or data.get("host")
                or host
            )

        if net == "ws":

            ws = {
                "path": (
                    data.get("path")
                    or "/"
                )
            }

            if data.get("host"):

                ws["headers"] = {
                    "Host":
                        data.get("host")
                }

            proxy["ws-opts"] = ws

        if net == "grpc":

            service = (
                data.get(
                    "serviceName"
                )
                or data.get("service")
            )

            if service:

                proxy["grpc-opts"] = {
                    "grpc-service-name":
                        service
                }

        return proxy

    except Exception:

        return None


def parse_trojan(line):

    try:

        parsed = urlparse(
            line
        )

        query = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or safe_int(
                query.get(
                    "port",
                    [443]
                )[0],
                443
            )
        )

        password = (
            parsed.username
            or ""
        )

        if not host:

            return None

        name = (
            unquote(
                parsed.fragment
            )
            or f"trojan-{host}"
        )

        proxy = {
            "name": uniq_name(name),
            "type": "trojan",
            "server": host,
            "port": port,
            "password": password,
            "udp": True,
            "network": "tcp"
        }

        sni = query.get(
            "sni",
            [""]
        )[0]

        if sni:

            proxy["sni"] = sni

        net = query.get(
            "type",
            ["tcp"]
        )[0].lower()

        if net == "ws":

            proxy["network"] = "ws"

            proxy["ws-opts"] = {
                "path": query.get(
                    "path",
                    ["/"]
                )[0]
            }

            host_header = query.get(
                "host",
                [""]
            )[0]

            if host_header:

                proxy[
                    "ws-opts"
                ]["headers"] = {
                    "Host":
                        host_header
                }

        return proxy

    except Exception:

        return None


def parse_ss(line):

    try:

        body = line[5:]

        fragment = ""

        if "#" in body:

            body, fragment = body.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        # URI userinfo form
        if "@" in body:

            credentials, hostport = (
                body.split(
                    "@",
                    1
                )
            )

            decoded_credentials = (
                b64decode_text(
                    credentials
                )
            )

            if ":" in decoded_credentials:

                method, password = (
                    decoded_credentials.split(
                        ":",
                        1
                    )
                )

            else:

                if ":" not in credentials:

                    return None

                method, password = (
                    credentials.split(
                        ":",
                        1
                    )
                )

            if hostport.startswith("["):

                end = hostport.find("]")

                host = hostport[
                    1:end
                ]

                port = safe_int(
                    hostport[
                        end + 2:
                    ]
                )

            else:

                host, port = (
                    hostport.rsplit(
                        ":",
                        1
                    )
                )

        else:

            decoded = b64decode_text(
                body
            )

            if "@" not in decoded:

                return None

            credentials, hostport = (
                decoded.split(
                    "@",
                    1
                )
            )

            method, password = (
                credentials.split(
                    ":",
                    1
                )
            )

            host, port = (
                hostport.rsplit(
                    ":",
                    1
                )
            )

        port = safe_int(
            port
        )

        if not (
            method
            and password
            and host
            and port
        ):

            return None

        return {
            "name": uniq_name(
                fragment
                or f"ss-{host}-{port}"
            ),
            "type": "ss",
            "server": host,
            "port": port,
            "cipher": method,
            "password": password,
            "udp": True
        }

    except Exception:

        return None


def parse_ssr(line):

    try:

        decoded = b64decode_text(
            line[6:]
        )

        main, sep, params = (
            decoded.partition(
                "/?"
            )
        )

        parts = main.split(
            ":"
        )

        if len(parts) != 6:

            return None

        (
            server,
            port,
            protocol,
            method,
            obfs,
            pwd_b64
        ) = parts

        password = b64decode_text(
            pwd_b64
        )

        q = parse_qs(
            params,
            keep_blank_values=True
        )

        def decode_q(key):

            value = q.get(
                key,
                [""]
            )[0]

            decoded_value = (
                b64decode_text(
                    value
                )
            )

            return (
                decoded_value
                or value
            )

        return {
            "name": uniq_name(
                decode_q(
                    "remarks"
                )
                or f"ssr-{server}-{port}"
            ),
            "type": "ssr",
            "server": server,
            "port": safe_int(port),
            "cipher": method,
            "password": password,
            "protocol": protocol,
            "obfs": obfs,
            "obfs-param": decode_q(
                "obfsparam"
            ),
            "protocol-param": decode_q(
                "protoparam"
            ),
            "udp": True
        }

    except Exception:

        return None


def parse_hysteria1(line):

    try:

        raw = line[
            len("hy://"):
        ] if line.startswith(
            "hy://"
        ) else line[
            len("hysteria://"):
        ]

        fragment = ""

        if "#" in raw:

            raw, fragment = raw.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        if "?" in raw:

            main, query = raw.split(
                "?",
                1
            )

        else:

            main = raw
            query = ""

        if "@" not in main:

            return None

        auth, hostport = main.split(
            "@",
            1
        )

        host, port = hostport.rsplit(
            ":",
            1
        )

        q = parse_qs(
            query,
            keep_blank_values=True
        )

        proxy = {
            "name": uniq_name(
                fragment
                or f"hysteria-{host}"
            ),
            "type": "hysteria",
            "server": host,
            "port": safe_int(port),
            "auth": auth,
            "sni": q.get(
                "sni",
                [host]
            )[0],
            "udp": True
        }

        if q.get("alpn"):

            proxy["alpn"] = q[
                "alpn"
            ][0].split(",")

        return proxy

    except Exception:

        return None


def parse_hysteria2(line):

    try:

        if line.startswith(
            "hysteria2://"
        ):

            raw = line[
                len("hysteria2://"):
            ]

        else:

            raw = line[
                len("hy2://"):
            ]

        fragment = ""

        if "#" in raw:

            raw, fragment = raw.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        if "?" in raw:

            main, query = raw.split(
                "?",
                1
            )

        else:

            main = raw
            query = ""

        if "@" not in main:

            return None

        auth, hostport = main.split(
            "@",
            1
        )

        host, port = hostport.rsplit(
            ":",
            1
        )

        password = auth

        if ":" in auth:

            _, password = auth.split(
                ":",
                1
            )

        q = parse_qs(
            query,
            keep_blank_values=True
        )

        proxy = {
            "name": uniq_name(
                fragment
                or f"hysteria2-{host}"
            ),
            "type": "hysteria2",
            "server": host,
            "port": safe_int(port),
            "password": password,
            "sni": q.get(
                "sni",
                [host]
            )[0],
            "udp": True
        }

        if q.get("alpn"):

            proxy["alpn"] = q[
                "alpn"
            ][0].split(",")

        return proxy

    except Exception:

        return None


def parse_tuic(line):

    try:

        raw = line[
            len("tuic://"):
        ]

        fragment = ""

        if "#" in raw:

            raw, fragment = raw.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        if "?" in raw:

            main, query = raw.split(
                "?",
                1
            )

        else:

            main = raw
            query = ""

        uidpwd, hostport = main.split(
            "@",
            1
        )

        if ":" in uidpwd:

            uuid, password = (
                uidpwd.split(
                    ":",
                    1
                )
            )

        else:

            uuid = uidpwd
            password = ""

        host, port = hostport.rsplit(
            ":",
            1
        )

        q = parse_qs(
            query,
            keep_blank_values=True
        )

        proxy = {
            "name": uniq_name(
                fragment
                or f"tuic-{host}"
            ),
            "type": "tuic",
            "server": host,
            "port": safe_int(port),
            "uuid": uuid,
            "password": password,
            "congestion-controller":
                q.get(
                    "congestion_control",
                    q.get(
                        "congestion",
                        ["bbr"]
                    )
                )[0],
            "sni": q.get(
                "sni",
                [host]
            )[0],
            "udp": True
        }

        if q.get("alpn"):

            proxy["alpn"] = q[
                "alpn"
            ][0].split(",")

        if q.get("udp_relay_mode"):

            proxy["udp-relay-mode"] = q[
                "udp_relay_mode"
            ][0]

        if q.get("zero_rtt"):

            proxy["zeroRTT"] = (
                q["zero_rtt"][0]
                .lower()
                == "true"
            )

        return proxy

    except Exception:

        return None


def parse_wireguard(line):

    try:

        if line.startswith(
            "wg://"
        ):

            parsed = urlparse(
                line
            )

            host = (
                parsed.hostname
                or ""
            )

            port = (
                parsed.port
                or 51820
            )

            query = parse_qs(
                parsed.query,
                keep_blank_values=True
            )

            proxy = {
                "name": uniq_name(
                    unquote(
                        parsed.fragment
                    )
                    or f"wg-{host}"
                ),
                "type": "wireguard",
                "server": host,
                "port": port,
                "public_key":
                    parsed.username
                    or "",
                "private_key":
                    query.get(
                        "privateKey",
                        [""]
                    )[0],
                "address":
                    query.get(
                        "address",
                        [""]
                    )[0],
                "mtu":
                    safe_int(
                        query.get(
                            "mtu",
                            [1280]
                        )[0],
                        1280
                    ),
                "udp": True
            }

            if query.get(
                "allowedIPs"
            ):

                proxy[
                    "allowed-ips"
                ] = query[
                    "allowedIPs"
                ][0].split(",")

            return proxy

        # Inline WireGuard
        public_key = re.search(
            r"(?im)^\s*PublicKey\s*=\s*(\S+)",
            line
        )

        endpoint = re.search(
            r"(?im)^\s*Endpoint\s*=\s*(.+?)\s*$",
            line
        )

        if not endpoint:

            return None

        endpoint_value = (
            endpoint.group(1).strip()
        )

        if endpoint_value.startswith(
            "["
        ):

            match = re.match(
                r"\[([^\]]+)\]:(\d+)",
                endpoint_value
            )

            if not match:

                return None

            host = match.group(1)

            port = safe_int(
                match.group(2),
                51820
            )

        else:

            host, port_text = (
                endpoint_value.rsplit(
                    ":",
                    1
                )
            )

            port = safe_int(
                port_text,
                51820
            )

        return {
            "name": uniq_name(
                f"wg-{host}"
            ),
            "type": "wireguard",
            "server": host,
            "port": port,
            "public_key":
                public_key.group(1)
                if public_key
                else "",
            "udp": True
        }

    except Exception:

        return None


def parse_h2(line):

    try:

        parsed = urlparse(
            line
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        q = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        return {
            "name": uniq_name(
                unquote(
                    parsed.fragment
                )
                or f"h2-{host}"
            ),
            "type": "h2",
            "server": host,
            "port": port,
            "tls": True,
            "servername": q.get(
                "sni",
                [host]
            )[0],
            "path": q.get(
                "path",
                ["/"]
            )[0],
            "host": q.get(
                "host",
                [host]
            )[0],
            "alpn": ["h2"],
            "udp": True
        }

    except Exception:

        return None


def parse_quic(line):

    try:

        parsed = urlparse(
            line
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        q = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        proxy = {
            "name": uniq_name(
                unquote(
                    parsed.fragment
                )
                or f"quic-{host}"
            ),
            "type": "quic",
            "server": host,
            "port": port,
            "key": q.get(
                "key",
                [""]
            )[0],
            "alpn": q.get(
                "alpn",
                ["h3"]
            )[0].split(","),
            "udp": True
        }

        return proxy

    except Exception:

        return None


def parse_reality(line):

    try:

        parsed = urlparse(
            line
        )

        uuid = (
            parsed.username
            or ""
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        q = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        return {
            "name": uniq_name(
                unquote(
                    parsed.fragment
                )
                or f"reality-{host}"
            ),
            "type": "vless",
            "server": host,
            "port": port,
            "uuid": uuid,
            "udp": True,
            "network": "tcp",
            "tls": True,
            "reality-opts": {
                "public-key":
                    q.get(
                        "pbk",
                        [""]
                    )[0],
                "short-id":
                    q.get(
                        "sid",
                        [""]
                    )[0],
                "server-name":
                    q.get(
                        "sni",
                        [host]
                    )[0]
            }
        }

    except Exception:

        return None


def parse_grpc(line):

    try:

        parsed = urlparse(
            line
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        q = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        return {
            "name": uniq_name(
                unquote(
                    parsed.fragment
                )
                or f"grpc-{host}"
            ),
            "type": "vless",
            "server": host,
            "port": port,
            "uuid":
                q.get(
                    "uuid",
                    [""]
                )[0],
            "encryption": "none",
            "network": "grpc",
            "tls": True,
            "servername":
                q.get(
                    "sni",
                    [host]
                )[0],
            "grpc-opts": {
                "grpc-service-name":
                    q.get(
                        "service",
                        [""]
                    )[0]
            },
            "udp": True
        }

    except Exception:

        return None


def parse_http(line):

    try:

        parsed = urlparse(
            line
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 80
        )

        if not host:

            return None

        return {
            "name": uniq_name(
                unquote(
                    parsed.fragment
                )
                or f"http-{host}"
            ),
            "type": "http",
            "server": host,
            "port": port,
            "username":
                parsed.username
                or "",
            "password":
                parsed.password
                or "",
            "udp": False
        }

    except Exception:

        return None


def parse_socks(line):

    try:

        parsed = urlparse(
            line
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 1080
        )

        if not host:

            return None

        return {
            "name": uniq_name(
                unquote(
                    parsed.fragment
                )
                or f"socks-{host}"
            ),
            "type": "socks5",
            "server": host,
            "port": port,
            "username":
                parsed.username
                or "",
            "password":
                parsed.password
                or "",
            "udp": True
        }

    except Exception:

        return None


# ============================================================
# JSON NODE PARSER
# ============================================================

def parse_json_node(
    obj
):

    result = []

    if not isinstance(
        obj,
        dict
    ):

        return result

    try:

        outbounds = (
            obj.get("outbounds")
            or obj.get("proxy")
            or []
        )

        if isinstance(
            outbounds,
            dict
        ):

            outbounds = [
                outbounds
            ]

        for outbound in outbounds:

            if not isinstance(
                outbound,
                dict
            ):

                continue

            proto = (
                outbound.get(
                    "protocol"
                )
                or outbound.get(
                    "type"
                )
                or ""
            ).lower()

            tag = (
                outbound.get("tag")
                or outbound.get("name")
            )

            # -----------------------------
            # VLESS / VMESS
            # -----------------------------

            if proto in (
                "vless",
                "vmess"
            ):

                settings = (
                    outbound.get(
                        "settings"
                    )
                    or {}
                )

                vnext = (
                    settings.get(
                        "vnext"
                    )
                    or settings.get(
                        "servers"
                    )
                    or []
                )

                if isinstance(
                    vnext,
                    dict
                ):

                    vnext = [
                        vnext
                    ]

                first = (
                    vnext[0]
                    if vnext
                    else {}
                )

                users = (
                    first.get(
                        "users"
                    )
                    or []
                )

                user = (
                    users[0]
                    if users
                    else {}
                )

                server = (
                    first.get(
                        "address"
                    )
                    or first.get(
                        "server"
                    )
                    or outbound.get(
                        "address"
                    )
                    or ""
                )

                port = safe_int(
                    first.get(
                        "port"
                    )
                    or outbound.get(
                        "port"
                    )
                    or 0
                )

                uuid = (
                    user.get("id")
                    or user.get("uuid")
                    or ""
                )

                if not (
                    server
                    and port
                    and uuid
                ):

                    continue

                proxy = {
                    "name": uniq_name(
                        tag
                        or f"{proto}-{server}"
                    ),
                    "type": proto,
                    "server": server,
                    "port": port,
                    "uuid": uuid,
                    "network": "tcp",
                    "udp": True
                }

                if proto == "vless":

                    proxy[
                        "encryption"
                    ] = "none"

                else:

                    proxy[
                        "alterId"
                    ] = safe_int(
                        user.get(
                            "alterId",
                            user.get(
                                "aid",
                                0
                            )
                        )
                    )

                    proxy[
                        "cipher"
                    ] = (
                        user.get(
                            "cipher"
                        )
                        or user.get(
                            "scy"
                        )
                        or "auto"
                    )

                stream = (
                    outbound.get(
                        "streamSettings"
                    )
                    or {}
                )

                network = (
                    stream.get(
                        "network"
                    )
                    or "tcp"
                )

                proxy[
                    "network"
                ] = network

                security = (
                    stream.get(
                        "security"
                    )
                    or ""
                ).lower()

                if security in (
                    "tls",
                    "reality"
                ):

                    proxy[
                        "tls"
                    ] = True

                    tls_settings = (
                        stream.get(
                            "tlsSettings"
                        )
                        or {}
                    )

                    proxy[
                        "servername"
                    ] = (
                        tls_settings.get(
                            "serverName"
                        )
                        or server
                    )

                if network == "ws":

                    ws = (
                        stream.get(
                            "wsSettings"
                        )
                        or {}
                    )

                    proxy[
                        "ws-opts"
                    ] = {
                        "path":
                            ws.get(
                                "path",
                                "/"
                            )
                    }

                    if ws.get(
                        "headers"
                    ):

                        proxy[
                            "ws-opts"
                        ][
                            "headers"
                        ] = ws[
                            "headers"
                        ]

                if network == "grpc":

                    grpc = (
                        stream.get(
                            "grpcSettings"
                        )
                        or {}
                    )

                    service = grpc.get(
                        "serviceName"
                    )

                    if service:

                        proxy[
                            "grpc-opts"
                        ] = {
                            "grpc-service-name":
                                service
                        }

                if security == "reality":

                    reality = (
                        stream.get(
                            "realitySettings"
                        )
                        or {}
                    )

                    proxy[
                        "reality-opts"
                    ] = {
                        "public-key":
                            reality.get(
                                "publicKey",
                                ""
                            ),
                        "short-id":
                            reality.get(
                                "shortId",
                                ""
                            ),
                        "server-name":
                            reality.get(
                                "serverName",
                                server
                            )
                    }

                result.append(
                    proxy
                )

            # -----------------------------
            # TROJAN
            # -----------------------------

            elif proto == "trojan":

                settings = (
                    outbound.get(
                        "settings"
                    )
                    or {}
                )

                servers = (
                    settings.get(
                        "servers"
                    )
                    or []
                )

                first = (
                    servers[0]
                    if servers
                    else {}
                )

                server = (
                    first.get(
                        "address"
                    )
                    or first.get(
                        "server"
                    )
                    or ""
                )

                port = safe_int(
                    first.get(
                        "port"
                    )
                    or 443
                )

                password = (
                    first.get(
                        "password"
                    )
                    or first.get(
                        "pass"
                    )
                    or ""
                )

                if not (
                    server
                    and port
                    and password
                ):

                    continue

                result.append(
                    {
                        "name": uniq_name(
                            tag
                            or f"trojan-{server}"
                        ),
                        "type": "trojan",
                        "server": server,
                        "port": port,
                        "password": password,
                        "udp": True
                    }
                )

            # -----------------------------
            # SHADOWSOCKS
            # -----------------------------

            elif proto in (
                "shadowsocks",
                "ss"
            ):

                settings = (
                    outbound.get(
                        "settings"
                    )
                    or {}
                )

                servers = (
                    settings.get(
                        "servers"
                    )
                    or []
                )

                first = (
                    servers[0]
                    if servers
                    else {}
                )

                server = (
                    first.get(
                        "address"
                    )
                    or first.get(
                        "server"
                    )
                    or ""
                )

                port = safe_int(
                    first.get(
                        "port"
                    )
                    or 0
                )

                cipher = (
                    first.get(
                        "method"
                    )
                    or first.get(
                        "cipher"
                    )
                    or ""
                )

                password = (
                    first.get(
                        "password"
                    )
                    or first.get(
                        "passwd"
                    )
                    or ""
                )

                if not (
                    server
                    and port
                    and cipher
                    and password
                ):

                    continue

                result.append(
                    {
                        "name": uniq_name(
                            tag
                            or f"ss-{server}"
                        ),
                        "type": "ss",
                        "server": server,
                        "port": port,
                        "cipher": cipher,
                        "password": password,
                        "udp": True
                    }
                )

        return result

    except Exception:

        return result


# ============================================================
# YAML PARSER
# ============================================================

def parse_yaml_nodes(
    text
):

    result = []

    try:

        documents = yaml.safe_load_all(
            text
        )

        for doc in documents:

            if not isinstance(
                doc,
                dict
            ):

                continue

            nodes = (
                doc.get("proxies")
                or doc.get("proxy")
                or []
            )

            if isinstance(
                nodes,
                dict
            ):

                nodes = [
                    nodes
                ]

            for proxy in nodes:

                if (
                    isinstance(
                        proxy,
                        dict
                    )
                    and proxy.get(
                        "type"
                    )
                    and proxy.get(
                        "server"
                    )
                ):

                    result.append(
                        dict(proxy)
                    )

    except Exception:

        pass

    return result


# ============================================================
# BASE64 SUBSCRIPTION
# ============================================================

def parse_base64_bundle(
    line
):

    result = []

    decoded = b64decode_text(
        line
    )

    if not decoded:

        return result

    stripped = decoded.strip()

    # JSON
    if stripped.startswith(
        "{"
    ):

        try:

            result.extend(
                parse_json_node(
                    json.loads(
                        stripped
                    )
                )
            )

            return result

        except Exception:

            pass

    # YAML
    if (
        "proxies:" in stripped
        or "proxy-groups:" in stripped
    ):

        result.extend(
            parse_yaml_nodes(
                stripped
            )
        )

    # URL list
    for line_item in (
        stripped.splitlines()
    ):

        line_item = (
            line_item.strip()
        )

        if not line_item:

            continue

        result.extend(
            parse_line_any(
                line_item
            )
        )

    return result


# ============================================================
# SINGLE LINE DISPATCHER
# ============================================================

def parse_line_any(
    line
):

    line = line.strip()

    if not line:

        return []

    lower = line.lower()

    try:

        if lower.startswith(
            "vless://"
        ):

            p = parse_vless(line)

            return [p] if p else []

        if lower.startswith(
            "vmess://"
        ):

            p = parse_vmess(line)

            return [p] if p else []

        if lower.startswith(
            "trojan://"
        ):

            p = parse_trojan(line)

            return [p] if p else []

        if lower.startswith(
            "ss://"
        ):

            p = parse_ss(line)

            return [p] if p else []

        if lower.startswith(
            "ssr://"
        ):

            p = parse_ssr(line)

            return [p] if p else []

        if (
            lower.startswith(
                "hy://"
            )
            or lower.startswith(
                "hysteria://"
            )
        ):

            p = parse_hysteria1(
                line
            )

            return [p] if p else []

        if (
            lower.startswith(
                "hy2://"
            )
            or lower.startswith(
                "hysteria2://"
            )
        ):

            p = parse_hysteria2(
                line
            )

            return [p] if p else []

        if lower.startswith(
            "tuic://"
        ):

            p = parse_tuic(line)

            return [p] if p else []

        if lower.startswith(
            "wg://"
        ):

            p = parse_wireguard(
                line
            )

            return [p] if p else []

        if (
            "[Interface]" in line
            and "[Peer]" in line
        ):

            p = parse_wireguard(
                line
            )

            return [p] if p else []

        if lower.startswith(
            "h2://"
        ):

            p = parse_h2(line)

            return [p] if p else []

        if lower.startswith(
            "quic://"
        ):

            p = parse_quic(line)

            return [p] if p else []

        if lower.startswith(
            "reality://"
        ):

            p = parse_reality(
                line
            )

            return [p] if p else []

        if lower.startswith(
            "grpc://"
        ):

            p = parse_grpc(line)

            return [p] if p else []

        if lower.startswith(
            "http://"
        ) or lower.startswith(
            "https://"
        ):

            p = parse_http(line)

            return [p] if p else []

        if (
            lower.startswith(
                "socks://"
            )
            or lower.startswith(
                "socks5://"
            )
        ):

            p = parse_socks(line)

            return [p] if p else []

        if (
            "[Interface]" in line
            or "[Peer]" in line
        ):

            p = parse_wireguard(
                line
            )

            return [p] if p else []

        if is_probably_base64(
            line
        ):

            return parse_base64_bundle(
                line
            )

        if (
            line.startswith("{")
            and line.endswith("}")
        ):

            try:

                return parse_json_node(
                    json.loads(
                        line
                    )
                )

            except Exception:

                return []

    except Exception:

        return []

    return []


# ============================================================
# JSON FRAGMENT EXTRACTION
# ============================================================

def extract_json_objects(
    text
):

    objects = []

    stack = []

    start = None

    in_string = False

    escaped = False

    for index, char in enumerate(
        text
    ):

        if char == '"' and not escaped:

            in_string = not in_string

        if in_string:

            escaped = (
                char == "\\"
                and not escaped
            )

            continue

        escaped = False

        if char == "{":

            if not stack:

                start = index

            stack.append(
                "{"
            )

        elif char == "}":

            if stack:

                stack.pop()

                if (
                    not stack
                    and start is not None
                ):

                    objects.append(
                        text[
                            start:
                            index + 1
                        ]
                    )

                    start = None

    return objects


# ============================================================
# MASTER PARSER
# ============================================================

def parse_any(
    text,
    statistics=None
):

    result = []

    if not text.strip():

        return result

    # JSON fragments
    for fragment in extract_json_objects(
        text
    ):

        try:

            obj = json.loads(
                fragment
            )

            result.extend(
                parse_json_node(
                    obj
                )
            )

        except Exception:

            pass

    # Whole YAML
    try:

        result.extend(
            parse_yaml_nodes(
                text
            )
        )

    except Exception:

        pass

    # Individual lines
    for line in text.splitlines():

        line = line.strip()

        if not line:

            continue

        # Do not treat normal URLs as base64.
        if (
            is_probably_base64(
                line
            )
            and not "://" in line
        ):

            result.extend(
                parse_base64_bundle(
                    line
                )

            )

            continue

        result.extend(
            parse_line_any(
                line
            )
        )

    normalized = []

    for proxy in result:

        if not isinstance(
            proxy,
            dict
        ):

            continue

        proxy = dict(proxy)

        proxy["server"] = normalize_host(
            proxy.get(
                "server"
            )
        )

        proxy["port"] = safe_int(
            proxy.get(
                "port"
            )
        )

        if not proxy.get(
            "name"
        ):

            proxy["name"] = uniq_name(
                f"{proxy.get('type','proxy')}-"
                f"{proxy.get('server','unknown')}-"
                f"{proxy.get('port',0)}"
            )

        else:

            proxy["name"] = uniq_name(
                proxy["name"]
            )

        normalized.append(
            proxy
        )

    return normalized


# ============================================================
# VALIDATOR
# ============================================================

SUPPORTED_TYPES = {
    "vless",
    "vmess",
    "trojan",
    "ss",
    "ssr",
    "hysteria",
    "hysteria2",
    "tuic",
    "wireguard",
    "http",
    "socks5",
    "h2",
    "quic"
}


def validate_proxy(
    proxy
):

    if not isinstance(
        proxy,
        dict
    ):

        return False

    proxy_type = normalize_protocol(
        proxy.get("type")
    )

    server = proxy.get(
        "server"
    )

    port = safe_int(
        proxy.get("port")
    )

    if not proxy_type:

        return False

    if proxy_type not in SUPPORTED_TYPES:

        return False

    if not server:

        return False

    if not (
        1 <= port <= 65535
    ):

        return False

    if proxy_type in (
        "vless",
        "vmess"
    ):

        if not proxy.get(
            "uuid"
        ):

            return False

    elif proxy_type == "trojan":

        if not proxy.get(
            "password"
        ):

            return False

    elif proxy_type == "ss":

        if not (
            proxy.get("cipher")
            and proxy.get("password")
        ):

            return False

    elif proxy_type == "ssr":

        if not proxy.get(
            "password"
        ):

            return False

    elif proxy_type == "tuic":

        if not proxy.get(
            "uuid"
        ):

            return False

    elif proxy_type == "hysteria2":

        if not proxy.get(
            "password"
        ):

            return False

    return True


# ============================================================
# ADAPTIVE WORKERS
# ============================================================

def adaptive_workers(
    count
):

    if count <= 50:

        return 4

    if count <= 100:

        return 8

    if count <= 500:

        return 16

    if count <= 1000:

        return 20

    if count <= 2000:

        return 24

    if count <= 5000:

        return 32

    return MAX_WORKERS


def adaptive_batch(
    count
):

    if count <= 100:

        return 50

    if count <= 1000:

        return 100

    if count <= 3000:

        return 125

    return MAX_BATCH


# ============================================================
# LOW DATA TEST
# ============================================================

def test_proxy(
    proxy
):

    host = proxy.get(
        "server"
    )

    port = safe_int(
        proxy.get("port")
    )

    fingerprint = proxy_fingerprint(
        proxy
    )

    cached = cache_get(
        fingerprint
    )

    if cached:

        return {
            "fingerprint":
                fingerprint,
            "status":
                cached.get(
                    "status"
                ),
            "latency":
                cached.get(
                    "latency"
                ),
            "family":
                cached.get(
                    "family"
                ),
            "cached":
                True
        }

    result = tcp_check(
        host,
        port,
        timeout=DEFAULT_TIMEOUT
    )

    cache_set(
        fingerprint,
        result
    )

    return {
        "fingerprint":
            fingerprint,
        "status":
            result["status"],
        "latency":
            result["latency"],
        "family":
            result["family"],
        "cached":
            False
    }


# ============================================================
# SCORE ENGINE
# ============================================================

def calculate_score(
    proxy,
    test
):

    score = 0

    # Config validity
    score += 10

    # Protocol recognized
    if normalize_protocol(
        proxy.get("type")
    ) in SUPPORTED_TYPES:

        score += 20

    status = test.get(
        "status"
    )

    if status == "TCP_OK":

        score += 30

    elif status == "DNS_FAIL":

        score += 0

    elif status == "TCP_FAIL":

        score += 5

    latency = test.get(
        "latency"
    )

    if latency is not None:

        if latency <= 50:

            score += 30

        elif latency <= 100:

            score += 25

        elif latency <= 200:

            score += 20

        elif latency <= 400:

            score += 15

        elif latency <= 800:

            score += 8

        else:

            score += 3

    return min(
        100,
        score
    )


# ============================================================
# CLASH / MIHOMO NORMALIZATION
# ============================================================

def to_clash_meta_entry(
    proxy
):

    t = normalize_protocol(
        proxy.get("type")
    )

    base = {
        "name":
            proxy.get("name"),
        "type":
            t,
        "server":
            proxy.get("server"),
        "port":
            safe_int(
                proxy.get("port")
            )
    }

    if t == "vless":

        base["uuid"] = proxy.get(
            "uuid"
        )

        base["encryption"] = (
            proxy.get(
                "encryption",
                "none"
            )
        )

        if proxy.get(
            "network"
        ):

            base["network"] = proxy[
                "network"
            ]

        if proxy.get("tls"):

            base["tls"] = True

        if proxy.get(
            "servername"
        ):

            base[
                "servername"
            ] = proxy[
                "servername"
            ]

        if proxy.get(
            "ws-opts"
        ):

            base[
                "ws-opts"
            ] = proxy[
                "ws-opts"
            ]

        if proxy.get(
            "grpc-opts"
        ):

            base[
                "grpc-opts"
            ] = proxy[
                "grpc-opts"
            ]

        if proxy.get(
            "reality-opts"
        ):

            base[
                "reality-opts"
            ] = proxy[
                "reality-opts"
            ]

    elif t == "vmess":

        base["uuid"] = proxy.get(
            "uuid"
        )

        base["alterId"] = safe_int(
            proxy.get(
                "alterId",
                0
            )
        )

        base["cipher"] = proxy.get(
            "cipher",
            "auto"
        )

        if proxy.get(
            "network"
        ):

            base["network"] = proxy[
                "network"
            ]

        if proxy.get("tls"):

            base["tls"] = True

        if proxy.get(
            "servername"
        ):

            base[
                "servername"
            ] = proxy[
                "servername"
            ]

        if proxy.get(
            "ws-opts"
        ):

            base[
                "ws-opts"
            ] = proxy[
                "ws-opts"
            ]

        if proxy.get(
            "grpc-opts"
        ):

            base[
                "grpc-opts"
            ] = proxy[
                "grpc-opts"
            ]

    elif t == "trojan":

        base["password"] = proxy.get(
            "password"
        )

        if proxy.get("sni"):

            base["sni"] = proxy[
                "sni"
            ]

        if proxy.get(
            "network"
        ):

            base["network"] = proxy[
                "network"
            ]

        if proxy.get(
            "ws-opts"
        ):

            base[
                "ws-opts"
            ] = proxy[
                "ws-opts"
            ]

    elif t == "ss":

        base["cipher"] = proxy.get(
            "cipher"
        )

        base["password"] = proxy.get(
            "password"
        )

    elif t == "ssr":

        for key in (
            "cipher",
            "password",
            "protocol",
            "obfs",
            "obfs-param",
            "protocol-param"
        ):

            if proxy.get(key) is not None:

                base[key] = proxy[key]

    elif t == "hysteria":

        if proxy.get("auth"):

            base["password"] = proxy[
                "auth"
            ]

        if proxy.get("sni"):

            base["sni"] = proxy[
                "sni"
            ]

        if proxy.get("alpn"):

            base["alpn"] = proxy[
                "alpn"
            ]

    elif t == "hysteria2":

        base["password"] = proxy.get(
            "password"
        )

        if proxy.get("sni"):

            base["sni"] = proxy[
                "sni"
            ]

        if proxy.get("alpn"):

            base["alpn"] = proxy[
                "alpn"
            ]

    elif t == "tuic":

        base["uuid"] = proxy.get(
            "uuid"
        )

        base["password"] = proxy.get(
            "password"
        )

        base[
            "congestion-controller"
        ] = proxy.get(
            "congestion-controller",
            "bbr"
        )

        if proxy.get("sni"):

            base["sni"] = proxy[
                "sni"
            ]

        if proxy.get("alpn"):

            base["alpn"] = proxy[
                "alpn"
            ]

        if proxy.get(
            "zeroRTT"
        ):

            base[
                "zeroRTT"
            ] = True

    elif t == "wireguard":

        for key in (
            "public_key",
            "private_key",
            "address",
            "mtu",
            "allowed-ips"
        ):

            if proxy.get(key) is not None:

                base[key] = proxy[key]

    elif t == "http":

        if proxy.get(
            "username"
        ):

            base["username"] = proxy[
                "username"
            ]

        if proxy.get(
            "password"
        ):

            base["password"] = proxy[
                "password"
            ]

    elif t == "socks5":

        if proxy.get(
            "username"
        ):

            base["username"] = proxy[
                "username"
            ]

        if proxy.get(
            "password"
        ):

            base["password"] = proxy[
                "password"
            ]

    else:

        # Preserve recognized fields
        # for formats that can be represented.

        for key in (
            "uuid",
            "password",
            "cipher",
            "network",
            "tls",
            "servername",
            "sni",
            "alpn",
            "udp",
            "ws-opts",
            "grpc-opts",
            "reality-opts"
        ):

            if key in proxy:

                base[key] = proxy[key]

    # UDP is useful for supported proxy types.
    if (
        "udp" in proxy
        and t not in (
            "wireguard",
        )
    ):

        base["udp"] = bool(
            proxy["udp"]
        )

    return base


# ============================================================
# MIHOMO COMPATIBILITY CHECK
# ============================================================

def mihomo_compatibility(
    proxy
):

    errors = []

    warnings = []

    t = normalize_protocol(
        proxy.get("type")
    )

    if t not in SUPPORTED_TYPES:

        errors.append(
            "unsupported-type"
        )

        return False, errors, warnings

    if not proxy.get(
        "name"
    ):

        errors.append(
            "missing-name"
        )

    if not proxy.get(
        "server"
    ):

        errors.append(
            "missing-server"
        )

    port = safe_int(
        proxy.get("port")
    )

    if not (
        1 <= port <= 65535
    ):

        errors.append(
            "invalid-port"
        )

    if t in (
        "vless",
        "vmess"
    ) and not proxy.get(
        "uuid"
    ):

        errors.append(
            "missing-uuid"
        )

    if t == "trojan" and not proxy.get(
        "password"
    ):

        errors.append(
            "missing-password"
        )

    if t == "ss":

        if not proxy.get(
            "cipher"
        ):

            errors.append(
                "missing-cipher"
            )

        if not proxy.get(
            "password"
        ):

            errors.append(
                "missing-password"
            )

    if t == "ssr":

        if not proxy.get(
            "password"
        ):

            errors.append(
                "missing-password"
            )

    if (
        proxy.get("network")
        == "ws"
        and not proxy.get(
            "ws-opts"
        )
    ):

        warnings.append(
            "ws-without-ws-opts"
        )

    if (
        proxy.get("network")
        == "grpc"
        and not proxy.get(
            "grpc-opts"
        )
    ):

        warnings.append(
            "grpc-without-grpc-opts"
        )

    if proxy.get(
        "reality-opts"
    ):

        reality = proxy[
            "reality-opts"
        ]

        if not reality.get(
            "public-key"
        ):

            warnings.append(
                "reality-without-public-key"
            )

    return (
        not errors,
        errors,
        warnings
    )


# ============================================================
# FINAL YAML VALIDATOR
# ============================================================

def validate_final_config(
    config
):

    errors = []

    if not isinstance(
        config,
        dict
    ):

        return False, [
            "config-not-dict"
        ]

    proxies = config.get(
        "proxies"
    )

    groups = config.get(
        "proxy-groups"
    )

    rules = config.get(
        "rules"
    )

    if not isinstance(
        proxies,
        list
    ):

        errors.append(
            "proxies-not-list"
        )

    if not isinstance(
        groups,
        list
    ):

        errors.append(
            "proxy-groups-not-list"
        )

    if not isinstance(
        rules,
        list
    ):

        errors.append(
            "rules-not-list"
        )

    if errors:

        return False, errors

    names = set()

    for proxy in proxies:

        if not isinstance(
            proxy,
            dict
        ):

            errors.append(
                "proxy-not-dict"
            )

            continue

        name = proxy.get(
            "name"
        )

        if not name:

            errors.append(
                "proxy-missing-name"
            )

            continue

        if name in names:

            errors.append(
                "duplicate-proxy-name:"
                + str(name)
            )

        names.add(
            name
        )

        if not proxy.get(
            "server"
        ):

            errors.append(
                "proxy-missing-server:"
                + str(name)
            )

        port = safe_int(
            proxy.get("port")
        )

        if not (
            1 <= port <= 65535
        ):

            errors.append(
                "proxy-invalid-port:"
                + str(name)
            )

    group_names = set()

    for group in groups:

        if not isinstance(
            group,
            dict
        ):

            errors.append(
                "group-not-dict"
            )

            continue

        group_name = group.get(
            "name"
        )

        if not group_name:

            errors.append(
                "group-missing-name"
            )

            continue

        group_names.add(
            group_name
        )

        members = group.get(
            "proxies",
            []
        )

        if not isinstance(
            members,
            list
        ):

            errors.append(
                "group-proxies-not-list:"
                + str(group_name)
            )

            continue

        for member in members:

            if (
                member != "DIRECT"
                and member not in names
                and member not in group_names
            ):

                # Nested groups can be declared later.
                continue

    return (
        not errors,
        errors
    )


# ============================================================
# BUILD INDUSTRIAL GROUPS
# ============================================================

def build_groups(
    proxy_names
):

    MANUAL = "MANUAL💚"

    AUTO = "AUTO💛"

    FAST = "FAST❤"

    STABLE = "STABLE🔰"

    FALLBACK = "FALLBACK💙"

    ALL = "[ALL]"

    groups = [

        {
            "name": MANUAL,
            "type": "select",
            "proxies": [
                AUTO,
                FAST,
                STABLE,
                FALLBACK,
                "DIRECT"
            ] + proxy_names
        },

        {
            "name": AUTO,
            "type": "url-test",
            "url":
                "https://www.gstatic.com/generate_204",
            "interval": 300,
            "tolerance": 50,
            "proxies":
                proxy_names
        },

        {
            "name": FAST,
            "type": "url-test",
            "url":
                "https://www.gstatic.com/generate_204",
            "interval": 300,
            "tolerance": 30,
            "proxies":
                proxy_names
        },

        {
            "name": STABLE,
            "type": "fallback",
            "url":
                "https://www.gstatic.com/generate_204",
            "interval": 300,
            "proxies":
                proxy_names
        },

        {
            "name": FALLBACK,
            "type": "fallback",
            "url":
                "https://www.gstatic.com/generate_204",
            "interval": 300,
            "timeout": 5,
            "proxies":
                proxy_names
        },

        {
            "name": ALL,
            "type": "select",
            "proxies":
                proxy_names
        }

    ]

    return groups


# ============================================================
# DNS SECTION
# ============================================================

def build_dns_section():

    return {

        "enable": True,

        "listen":
            "0.0.0.0:1053",

        "ipv6": True,

        "enhanced-mode":
            "fake-ip",

        "fake-ip-range":
            "198.18.0.1/16",

        "nameserver": [

            "223.5.5.5",

            "1.1.1.1",

            "8.8.8.8"

        ],

        "fallback": [

            "1.0.0.1",

            "8.8.4.4"

        ],

        "fallback-filter": {

            "geoip": True,

            "geoip-code": "IR",

            "ipcidr": [

                "240.0.0.0/4",

                "0.0.0.0/32"

            ]

        }

    }


# ============================================================
# ATOMIC YAML WRITE
# ============================================================

def atomic_yaml_write(
    config,
    path
):

    directory = os.path.dirname(
        path
    )

    fd, temp_path = (
        tempfile.mkstemp(
            prefix=".mihomo_",
            suffix=".tmp",
            dir=directory
        )
    )

    try:

        with os.fdopen(
            fd,
            "w",
            encoding=OUTPUT_ENCODING
        ) as f:

            yaml.safe_dump(
                config,
                f,
                allow_unicode=True,
                sort_keys=False,
                default_flow_style=False
            )

            f.flush()

            os.fsync(
                f.fileno()
            )

        os.replace(
            temp_path,
            path
        )

    except Exception:

        try:

            os.remove(
                temp_path
            )

        except Exception:

            pass

        raise


# ============================================================
# OUTPUT VALIDATION AFTER WRITE
# ============================================================

def validate_written_yaml(
    path
):

    try:

        with open(
            path,
            "r",
            encoding=OUTPUT_ENCODING
        ) as f:

            loaded = yaml.safe_load(
                f
            )

        valid, errors = (
            validate_final_config(
                loaded
            )
        )

        return valid, errors

    except Exception as e:

        return False, [
            "yaml-read-error:"
            + str(e)
        ]


# ============================================================
# REPORT
# ============================================================

def write_report(
    path,
    stats,
    latency_values
):

    lines = []

    lines.append(
        "=" * 70
    )

    lines.append(
        "MIHOMO INDUSTRIAL PARSER REPORT"
    )

    lines.append(
        "=" * 70
    )

    for key, value in stats.items():

        lines.append(
            f"{key}: {value}"
        )

    if latency_values:

        ordered = sorted(
            latency_values
        )

        lines.append("")

        lines.append(
            "Latency:"
        )

        lines.append(
            f"  Min: {ordered[0]} ms"
        )

        lines.append(
            f"  Max: {ordered[-1]} ms"
        )

        lines.append(
            f"  Median: "
            f"{ordered[len(ordered)//2]} ms"
        )

    lines.append("")

    lines.append(
        "Runtime testing:"
    )

    lines.append(
        "  DNS resolution: ON"
    )

    lines.append(
        "  TCP connect: ON"
    )

    lines.append(
        "  HTTP download: OFF"
    )

    lines.append(
        "  Payload download: OFF"
    )

    lines.append(
        "  Persistent cache: ON"
    )

    lines.append(
        f"  DNS TTL: {DNS_TTL}s"
    )

    lines.append(
        f"  TCP TTL: {TCP_TTL}s"
    )

    lines.append(
        "=" * 70
    )

    with open(
        path,
        "w",
        encoding=OUTPUT_ENCODING
    ) as f:

        f.write(
            "\n".join(lines)
        )


# ============================================================
# FAILED REPORT
# ============================================================

def write_failed_report(
    path,
    failed_lines
):

    with open(
        path,
        "w",
        encoding=OUTPUT_ENCODING
    ) as f:

        for item in failed_lines:

            f.write(
                str(item).rstrip()
                + "\n"
            )


# ============================================================
# MAIN PROCESSOR
# ============================================================

def process_input_and_write(
    input_text,
    out_path
):

    load_cache()

    stats = Counter()

    failed_lines = []

    start_time = time.monotonic()

    # --------------------------------------------------------
    # PARSE
    # --------------------------------------------------------

    print()

    print(
        "[1/9] Parsing input..."
    )

    parsed = parse_any(
        input_text,
        stats
    )

    stats[
        "Input parsed objects"
    ] = len(parsed)

    if not parsed:

        print(
            "[ERROR] No valid proxy objects parsed."
        )

        return False

    # --------------------------------------------------------
    # DEDUP
    # --------------------------------------------------------

    print(
        "[2/9] Smart deduplication..."
    )

    before_dedupe = len(
        parsed
    )

    parsed = dedupe_proxies(
        parsed
    )

    stats[
        "Duplicates removed"
    ] = (
        before_dedupe
        - len(parsed)
    )

    # --------------------------------------------------------
    # VALIDATION
    # --------------------------------------------------------

    print(
        "[3/9] Format validation..."
    )

    valid = []

    for proxy in parsed:

        if validate_proxy(
            proxy
        ):

            compatible, errors, warnings = (
                mihomo_compatibility(
                    proxy
                )
            )

            if compatible:

                valid.append(
                    proxy
                )

            else:

                failed_lines.append(
                    f"INVALID | "
                    f"{proxy.get('server','?')} | "
                    f"{','.join(errors)}"
                )

        else:

            failed_lines.append(
                f"INVALID | "
                f"{proxy.get('server','?')} | "
                f"basic-validation"
            )

    stats[
        "Basic valid"
    ] = len(valid)

    stats[
        "Invalid"
    ] = (
        len(parsed)
        - len(valid)
    )

    if not valid:

        print(
            "[ERROR] No valid proxies remain."
        )

        return False

    # --------------------------------------------------------
    # TEST PLAN
    # --------------------------------------------------------

    workers = adaptive_workers(
        len(valid)
    )

    batch_size = adaptive_batch(
        len(valid)
    )

    stats[
        "Adaptive workers"
    ] = workers

    stats[
        "Batch size"
    ] = batch_size

    print(
        "[4/9] Low-data DNS/TCP testing..."
    )

    print(
        f"      Candidates : {len(valid)}"
    )

    print(
        f"      Workers    : {workers}"
    )

    print(
        f"      Batch      : {batch_size}"
    )

    alive = []

    cached_count = 0

    tcp_ok_count = 0

    tcp_fail_count = 0

    dns_fail_count = 0

    latency_values = []

    # --------------------------------------------------------
    # BATCH TEST
    # --------------------------------------------------------

    for batch_start in range(
        0,
        len(valid),
        batch_size
    ):

        batch = valid[
            batch_start:
            batch_start + batch_size
        ]

        print(
            f"      Batch "
            f"{batch_start + 1}-"
            f"{batch_start + len(batch)} / "
            f"{len(valid)}"
        )

        with ThreadPoolExecutor(
            max_workers=workers
        ) as executor:

            future_map = {
                executor.submit(
                    test_proxy,
                    proxy
                ): proxy
                for proxy in batch
            }

            for future in as_completed(
                future_map
            ):

                proxy = future_map[
                    future
                ]

                try:

                    result = future.result()

                except Exception:

                    result = {
                        "status":
                            "TCP_FAIL",
                        "latency":
                            None,
                        "family":
                            None,
                        "cached":
                            False
                    }

                status = result.get(
                    "status"
                )

                if result.get(
                    "cached"
                ):

                    cached_count += 1

                if status == "TCP_OK":

                    tcp_ok_count += 1

                    latency = result.get(
                        "latency"
                    )

                    if latency is not None:

                        latency_values.append(
                            latency
                        )

                    proxy["_test"] = result

                    proxy["_score"] = (
                        calculate_score(
                            proxy,
                            result
                        )
                    )

                    alive.append(
                        proxy
                    )

                elif status == "DNS_FAIL":

                    dns_fail_count += 1

                    failed_lines.append(
                        f"DNS_FAIL | "
                        f"{proxy.get('server')} | "
                        f"{proxy.get('port')}"
                    )

                else:

                    tcp_fail_count += 1

                    failed_lines.append(
                        f"TCP_FAIL | "
                        f"{proxy.get('server')} | "
                        f"{proxy.get('port')}"
                    )

    # Save cache once, not once per proxy.
    save_cache()

    stats[
        "Cache hits"
    ] = cached_count

    stats[
        "TCP reachable"
    ] = tcp_ok_count

    stats[
        "TCP unreachable"
    ] = tcp_fail_count

    stats[
        "DNS failed"
    ] = dns_fail_count

    if not alive:

        print(
            "[ERROR] No TCP-reachable proxies."
        )

        write_failed_report(
            FAILED_OUT,
            failed_lines
        )

        return False

    # --------------------------------------------------------
    # SORT
    # --------------------------------------------------------

    print(
        "[5/9] Ranking proxies..."
    )

    alive.sort(
        key=lambda p: (
            -safe_int(
                p.get("_score"),
                0
            ),
            safe_int(
                p.get("_test", {}).get(
                    "latency",
                    999999
                ),
                999999
            )
        )
    )

    # --------------------------------------------------------
    # CONVERSION
    # --------------------------------------------------------

    print(
        "[6/9] Mihomo normalization..."
    )

    final_entries = []

    for proxy in alive:

        entry = to_clash_meta_entry(
            proxy
        )

        compatible, errors, warnings = (
            mihomo_compatibility(
                entry
            )
        )

        if not compatible:

            failed_lines.append(
                f"MIHOMO_INVALID | "
                f"{entry.get('name','?')} | "
                f"{','.join(errors)}"
            )

            continue

        final_entries.append(
            entry
        )

    # Final name deduplication
    names = set()

    clean_entries = []

    for entry in final_entries:

        name = entry.get(
            "name"
        )

        if name in names:

            continue

        names.add(
            name
        )

        clean_entries.append(
            entry
        )

    final_entries = clean_entries

    if not final_entries:

        print(
            "[ERROR] No compatible final entries."
        )

        return False

    # --------------------------------------------------------
    # BUILD CONFIG
    # --------------------------------------------------------

    print(
        "[7/9] Building Mihomo configuration..."
    )

    proxy_names = [
        entry["name"]
        for entry in final_entries
    ]

    config = {

        "mixed-port": 7890,

        "allow-lan": False,

        "mode": "rule",

        "log-level": "info",

        "ipv6": True,

        "dns":
            build_dns_section(),

        "proxies":
            final_entries,

        "proxy-groups":
            build_groups(
                proxy_names
            ),

        "rules": [
            "MATCH,MANUAL💚"
        ]
    }

    # --------------------------------------------------------
    # VALIDATE CONFIG OBJECT
    # --------------------------------------------------------

    print(
        "[8/9] Final schema validation..."
    )

    valid_config, errors = (
        validate_final_config(
            config
        )
    )

    if not valid_config:

        print(
            "[ERROR] Final configuration invalid:"
        )

        for error in errors:

            print(
                "  -",
                error
            )

        return False

    # --------------------------------------------------------
    # WRITE ATOMICALLY
    # --------------------------------------------------------

    try:

        atomic_yaml_write(
            config,
            out_path
        )

    except Exception as e:

        print(
            "[ERROR] YAML write failed:"
        )

        print(e)

        return False

    # --------------------------------------------------------
    # READ BACK + VALIDATE
    # --------------------------------------------------------

    print(
        "[9/9] Reading output back and validating..."
    )

    output_valid, output_errors = (
        validate_written_yaml(
            out_path
        )
    )

    if not output_valid:

        print(
            "[ERROR] Written YAML failed validation."
        )

        for error in output_errors:

            print(
                "  -",
                error
            )

        try:

            os.remove(
                out_path
            )

        except Exception:

            pass

        return False

    # --------------------------------------------------------
    # REPORT
    # --------------------------------------------------------

    elapsed = (
        time.monotonic()
        - start_time
    )

    stats[
        "Final proxies"
    ] = len(
        final_entries
    )

    stats[
        "Runtime seconds"
    ] = round(
        elapsed,
        2
    )

    stats[
        "Output"
    ] = out_path

    stats[
        "Groups"
    ] = 6

    stats[
        "URL-Test runtime testing"
    ] = "OFF"

    stats[
        "HTTP download testing"
    ] = "OFF"

    stats[
        "DNS section"
    ] = "AUTO"

    write_report(
        REPORT_OUT,
        stats,
        latency_values
    )

    write_failed_report(
        FAILED_OUT,
        failed_lines
    )

    # --------------------------------------------------------
    # CLEAR INPUT ONLY AFTER SUCCESS
    # --------------------------------------------------------

    try:

        with open(
            INPUT_PATH,
            "w",
            encoding=OUTPUT_ENCODING
        ) as f:

            f.write("")

    except Exception as e:

        print(
            "[WARNING] Could not clear input.txt:"
        )

        print(e)

    # --------------------------------------------------------
    # FINAL OUTPUT
    # --------------------------------------------------------

    print()

    print(
        "=" * 70
    )

    print(
        "[SUCCESS] INDUSTRIAL MIHOMO YAML CREATED"
    )

    print(
        "=" * 70
    )

    print(
        f"Output        : {out_path}"
    )

    print(
        f"Final proxies : {len(final_entries)}"
    )

    print(
        f"TCP reachable : {tcp_ok_count}"
    )

    print(
        f"DNS failed    : {dns_fail_count}"
    )

    print(
        f"TCP failed    : {tcp_fail_count}"
    )

    print(
        f"Cache hits    : {cached_count}"
    )

    print(
        f"Workers       : {workers}"
    )

    print(
        f"Batch         : {batch_size}"
    )

    print(
        f"Runtime       : {elapsed:.2f}s"
    )

    print()

    print(
        f"Report        : {REPORT_OUT}"
    )

    print(
        f"Failed        : {FAILED_OUT}"
    )

    print(
        f"Cache         : {CACHE_PATH}"
    )

    print()

    print(
        "Runtime DNS test       : ON"
    )

    print(
        "Runtime TCP test       : ON"
    )

    print(
        "HTTP download test     : OFF"
    )

    print(
        "URL-Test in YAML       : ON"
    )

    print(
        "Persistent cache       : ON"
    )

    print(
        "IPv4/IPv6 intelligence : ON"
    )

    print(
        "Adaptive workers       : ON"
    )

    print(
        "Batch processing       : ON"
    )

    print(
        "Smart deduplication    : ON"
    )

    print(
        "Mihomo validation      : ON"
    )

    print(
        "Input cleared          : YES"
    )

    print(
        "=" * 70
    )

    return True


# ============================================================
# ENTRY POINT
# ============================================================

def main():

    try:

        with open(
            INPUT_PATH,
            "r",
            encoding=OUTPUT_ENCODING
        ) as f:

            input_text = f.read()

    except Exception as e:

        print(
            "[ERROR] Cannot read input.txt:"
        )

        print(e)

        return 1

    if not input_text.strip():

        print()

        print(
            "[ERROR] input.txt is empty."
        )

        print(
            "Put your configurations in Nano and run again."
        )

        return 1

    success = process_input_and_write(
        input_text,
        OUT_PATH
    )

    if success:

        return 0

    print()

    print(
        "[FAILED] No final YAML generated."
    )

    print(
        f"Input file: {INPUT_PATH}"
    )

    return 1


if __name__ == "__main__":

    sys.exit(
        main()
    )
