#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
import os,re,sys,json,time,socket,base64,tempfile,subprocess,hashlib,ipaddress,platform
from pathlib import Path
from urllib.parse import urlparse,parse_qs,unquote
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import yaml

BASE_DIR=Path("/storage/emulated/0/Download/Akbar98"); BASE_DIR.mkdir(parents=True,exist_ok=True)
DOWNLOAD_DIR=Path("/storage/emulated/0/Download")
INPUT_PATH=BASE_DIR/"input.txt"
CACHE_PATH=BASE_DIR/".mihomo_test_cache.json"

GROUP="Mobile-Fast❤"
TCP_TIMEOUT=1.35
CACHE_TTL=600
DNS_TTL=300
BATCH_SIZE=100
MAX_DNS_ADDRESSES=16
CONNECT_ATTEMPTS=1
CACHE_SAVE_INTERVAL=500
MAX_INPUT_BYTES=8*1024*1024
ENGINE_VERSION="INDUSTRIAL-V4"
MAX_REPORT_ITEMS=10000
MAX_DNS_ADDRESSES=16

MAX_WORKERS=32
MIN_WORKERS=6
MAX_CACHE_ITEMS=20000
SUPPORTED={"vless","vmess","trojan","ss","ssr","hysteria","hysteria2","tuic","wireguard"}
_lock=__import__("threading").Lock()
DNS_CACHE={}
USED=set()

def s(v): return "" if v is None else str(v).strip()
def i(v,d=0):
    try:return int(v)
    except:
        try:return int(float(v))
        except:return d
def port(v,d=443):
    x=i(v,d); return x if 1<=x<=65535 else d
def b64(v):
    x=re.sub(r"\s+","",s(v)).replace("-","+").replace("_","/")
    x+="="*((4-len(x)%4)%4)
    try:return base64.b64decode(x).decode("utf-8","ignore")
    except:return ""
def qs(q): return {k:(v[0] if v else "") for k,v in parse_qs(q,keep_blank_values=True).items()}
def tail(v,n=6):
    x=re.sub(r"[^A-Za-z0-9]","",s(v)); return x[-n:] if len(x)>n else x
def name(v):
    x=re.sub(r"[^A-Za-z0-9_\-. \u0600-\u06FF❤💚💛💙🔰]","",s(v)).strip() or "Proxy"
    z=x;n=2
    while z in USED:z=f"{x} {n}";n+=1
    USED.add(z);return z

def _canon(v):
    if isinstance(v, dict):
        return {str(k): _canon(v[k]) for k in sorted(v)}
    if isinstance(v, (list, tuple)):
        return [_canon(x) for x in v]
    if isinstance(v, bool) or v is None:
        return v
    return str(v).strip()

def canonical_proxy(p):
    ignored={"name","ping","status","cached","score","_ping","_status","_score","_fingerprint"}
    return _canon({k:v for k,v in p.items() if k not in ignored and not k.startswith("_")})

def fingerprint(p):
    raw=json.dumps(canonical_proxy(p),ensure_ascii=False,sort_keys=True,separators=(",",":"))
    return hashlib.sha256(raw.encode("utf-8","ignore")).hexdigest()

def fp(p):
    return fingerprint(p)

def open_input():
    INPUT_PATH.write_text("",encoding="utf-8")
    try: subprocess.run(["nano",str(INPUT_PATH)],check=False)
    except Exception: input("Edit input.txt then press Enter...")
def clear_input():
    try: INPUT_PATH.write_text("",encoding="utf-8")
    except: pass

def vless(x):
    try:
        raw=x[8:];frag=""
        if "#" in raw:raw,frag=raw.split("#",1);frag=unquote(frag)
        main,qraw=(raw.split("?",1)+[""])[:2] if "?" in raw else (raw,"")
        uid,ep=main.rsplit("@",1);q=qs(qraw)
        if ep.startswith("["):
            k=ep.find("]");host=ep[1:k];ps=ep[k+2:] if ep[k+1:k+2]==":" else "443"
        else:host,_,ps=ep.rpartition(":");host=host or ep;ps=ps or "443"
        net=(q.get("type") or q.get("network") or "tcp").lower();sec=q.get("security","").lower()
        p={"name":frag or q.get("remark") or f"vless-{host}-{tail(uid)}","type":"vless","server":host,"port":port(ps),"uuid":unquote(uid),"encryption":q.get("encryption") or "none","network":net,"udp":True}
        if sec in ("tls","reality") or q.get("pbk"):p["tls"]=True;p["servername"]=q.get("sni") or q.get("servername") or q.get("host") or host
        if net=="ws":
            p["ws-opts"]={"path":q.get("path") or "/"};h=q.get("host") or q.get("Host")
            if h:p["ws-opts"]["headers"]={"Host":h}
        if net=="grpc" and (sv:=q.get("serviceName") or q.get("service")):p["grpc-opts"]={"grpc-service-name":sv}
        if sec=="reality" or q.get("pbk") or q.get("sid"):p["reality-opts"]={"public-key":q.get("pbk",""),"short-id":q.get("sid",""),"server-name":q.get("sni") or host};p["tls"]=True
        return p
    except:return None

def vmess(x):
    try:
        o=json.loads(b64(x[8:]) or unquote(x[8:]));h=o.get("add") or o.get("address") or o.get("server");u=o.get("id") or o.get("uuid")
        if not(h and u):return None
        net=(o.get("net") or "tcp").lower()
        p={"name":o.get("ps") or f"vmess-{h}-{tail(u)}","type":"vmess","server":h,"port":port(o.get("port"),443),"uuid":u,"alterId":i(o.get("aid",o.get("alterId",0))),"cipher":o.get("scy") or o.get("cipher") or "auto","network":net,"udp":True}
        if str(o.get("tls","")).lower() in ("tls","true","1"):p["tls"]=True;p["servername"]=o.get("sni") or o.get("host") or h
        if net=="ws":p["ws-opts"]={"path":o.get("path") or "/"};p["ws-opts"].update({"headers":{"Host":o["host"]}} if o.get("host") else {})
        if net=="grpc" and o.get("serviceName"):p["grpc-opts"]={"grpc-service-name":o["serviceName"]}
        return p
    except:return None

def trojan(x):
    try:
        u=urlparse(x);q=parse_qs(u.query,keep_blank_values=True);h=u.hostname or "";pwd=unquote(u.username or "")
        if not(h and pwd):return None
        p={"name":unquote(u.fragment or "") or f"trojan-{h}-{tail(pwd)}","type":"trojan","server":h,"port":u.port or 443,"password":pwd,"network":"tcp","tls":True,"sni":q.get("sni",[h])[0],"udp":True}
        if q.get("type",["tcp"])[0]=="ws":p["network"]="ws";p["ws-opts"]={"path":q.get("path",["/"])[0],"headers":{"Host":q.get("host",[""])[0]}}
        return p
    except:return None

def ss(x):
    try:
        body=x[5:];frag=""
        if "#" in body:body,frag=body.split("#",1);frag=unquote(frag)
        if "@" in body:
            c,a=body.rsplit("@",1);d=b64(c)
            if ":" in d:c=d
            m,pw=c.split(":",1);h,_,ps=a.rpartition(":")
        else:
            d=b64(body);c,a=d.rsplit("@",1);m,pw=c.split(":",1);h,_,ps=a.rpartition(":")
        return {"name":frag or f"ss-{h}-{ps}","type":"ss","server":h,"port":port(ps,8388),"cipher":m,"password":pw,"udp":True} if h and m and pw else None
    except:return None

def ssr(x):
    try:
        d=b64(x[6:]);main,_,par=d.partition("/?");a=main.split(":")
        if len(a)!=6:return None
        h,ps,proto,ciph,obfs,pwb=a;pw=b64(pwb);q={}
        for k,v in parse_qs(par,keep_blank_values=True).items():q[k]=b64(v[0]) or v[0]
        return {"name":q.get("remarks") or f"ssr-{h}-{ps}","type":"ssr","server":h,"port":port(ps),"cipher":ciph,"password":pw,"protocol":proto,"obfs":obfs,"obfs-param":q.get("obfsparam",""),"protocol-param":q.get("protoparam",""),"udp":True}
    except:return None

def hy(x):
    try:
        raw=re.sub(r"^(hysteria|hy)://","",x,flags=re.I);frag=""
        if "#" in raw:raw,frag=raw.split("#",1);frag=unquote(frag)
        main,qraw=(raw.split("?",1)+[""])[:2] if "?" in raw else (raw,"")
        auth,ep=main.rsplit("@",1);h,_,ps=ep.rpartition(":");q=qs(qraw)
        return {"name":frag or f"hysteria-{h}","type":"hysteria","server":h,"port":port(ps),"password":unquote(auth),"sni":q.get("sni") or h,"alpn":[z for z in q.get("alpn","").split(",") if z],"udp":True}
    except:return None

def hy2(x):
    try:
        raw=re.sub(r"^(hysteria2|hy2)://","",x,flags=re.I);frag=""
        if "#" in raw:raw,frag=raw.split("#",1);frag=unquote(frag)
        main,qraw=(raw.split("?",1)+[""])[:2] if "?" in raw else (raw,"");auth,ep=main.rsplit("@",1);h,_,ps=ep.rpartition(":");q=qs(qraw)
        return {"name":frag or f"hysteria2-{h}","type":"hysteria2","server":h,"port":port(ps),"password":unquote(auth.split(":",1)[-1]),"sni":q.get("sni") or h,"alpn":[z for z in q.get("alpn","").split(",") if z],"udp":True}
    except:return None

def tuic(x):
    try:
        raw=x[7:];frag=""
        if "#" in raw:raw,frag=raw.split("#",1);frag=unquote(frag)
        main,qraw=(raw.split("?",1)+[""])[:2] if "?" in raw else (raw,"");auth,ep=main.rsplit("@",1);uid,_,pw=auth.partition(":");h,_,ps=ep.rpartition(":");q=qs(qraw)
        return {"name":frag or f"tuic-{h}-{tail(uid)}","type":"tuic","server":h,"port":port(ps),"uuid":uid,"password":pw,"congestion-controller":q.get("congestion") or "bbr","alpn":[z for z in (q.get("alpn") or "h3").split(",") if z],"sni":q.get("sni") or h,"udp":True}
    except:return None

def wireguard(x):
    try:
        if x.lower().startswith("wg://"):
            u=urlparse(x);q=parse_qs(u.query,keep_blank_values=True);h=u.hostname or ""
            return {"name":unquote(u.fragment or "") or f"wg-{h}","type":"wireguard","server":h,"port":u.port or 51820,"public_key":u.username or "","private_key":q.get("privateKey",[""])[0],"address":q.get("address",[""])[0],"mtu":i(q.get("mtu",["1280"])[0],1280),"udp":True}
        e=re.search(r"(?im)^\s*Endpoint\s*=\s*(.+?):(\d+)\s*$",x)
        if not e:return None
        pk=re.search(r"(?im)^\s*PublicKey\s*=\s*(.+?)\s*$",x)
        return {"name":f"wg-{e.group(1)}","type":"wireguard","server":e.group(1),"port":port(e.group(2),51820),"public_key":pk.group(1).strip() if pk else "","udp":True}
    except:return None

def json_nodes(o):
    out=[]
    if not isinstance(o,dict):return out
    obs=o.get("outbounds") or o.get("proxy") or []
    if isinstance(obs,dict):obs=[obs]
    for ob in obs:
        if not isinstance(ob,dict):continue
        t=s(ob.get("protocol") or ob.get("type")).lower();st=ob.get("settings") or {}
        if t in ("vless","vmess"):
            vs=st.get("vnext") or st.get("servers") or [];v=vs[0] if vs else {};us=v.get("users") or [];u=us[0] if us else {};h=v.get("address") or v.get("server") or ob.get("address");uid=u.get("id") or u.get("uuid")
            if not(h and uid):continue
            stream=ob.get("streamSettings") or {};net=stream.get("network") or "tcp";p={"name":ob.get("tag") or f"{t}-{h}-{tail(uid)}","type":t,"server":h,"port":port(v.get("port") or ob.get("port")),"uuid":uid,"network":net,"udp":True}
            if t=="vless":p["encryption"]="none"
            else:p["alterId"]=i(u.get("alterId",u.get("aid",0)));p["cipher"]=u.get("cipher") or u.get("scy") or "auto"
            sec=s(stream.get("security")).lower()
            if sec in ("tls","reality"):p["tls"]=True;p["servername"]=(stream.get("tlsSettings") or {}).get("serverName") or h
            if net=="ws":
                w=stream.get("wsSettings") or {};p["ws-opts"]={"path":w.get("path") or "/"};p["ws-opts"].update({"headers":w["headers"]} if w.get("headers") else {})
            if net=="grpc" and (g:=stream.get("grpcSettings") or {}).get("serviceName"):p["grpc-opts"]={"grpc-service-name":g["serviceName"]}
            out.append(p)
        elif t=="trojan":
            a=(st.get("servers") or [{}])[0];h=a.get("address") or a.get("server") or ob.get("address");pw=a.get("password") or a.get("pass")
            if h and pw:out.append({"name":ob.get("tag") or f"trojan-{h}","type":"trojan","server":h,"port":port(a.get("port"),443),"password":pw,"tls":True,"sni":h,"udp":True})
        elif t in ("ss","shadowsocks"):
            a=(st.get("servers") or [{}])[0];h=a.get("address") or a.get("server") or ob.get("address");m=a.get("method") or a.get("cipher");pw=a.get("password") or a.get("passwd")
            if h and m and pw:out.append({"name":ob.get("tag") or f"ss-{h}","type":"ss","server":h,"port":port(a.get("port"),8388),"cipher":m,"password":pw,"udp":True})
    return out

def parse_text(text, depth=0, seen_b64=None):
    # Defensive parser: bounded recursion prevents malformed/base64 input from
    # consuming unbounded CPU/RAM.
    if not text or depth > 3:
        return []
    if len(text.encode("utf-8", "ignore")) > MAX_INPUT_BYTES:
        text = text[:MAX_INPUT_BYTES]
    if seen_b64 is None:
        seen_b64 = set()

    out=[]
    try:
        for d in yaml.safe_load_all(text):
            if isinstance(d,dict):
                ps=d.get("proxies") or d.get("proxy") or []
                if isinstance(ps,dict): ps=[ps]
                out += [dict(p) for p in ps if isinstance(p,dict)]
                out += json_nodes(d)
    except Exception:
        pass

    for m in re.findall(r'\\{(?:[^{}]|"(?:\\\\.|[^"])*")*\\}',text,re.S):
        try: out += json_nodes(json.loads(m))
        except Exception: pass

    for line in text.splitlines():
        x=line.strip()
        if not x: continue
        low=x.lower()
        parser=next((f for pre,f in [
            ("vless://",vless),("vmess://",vmess),("trojan://",trojan),
            ("ss://",ss),("ssr://",ssr),("hysteria://",hy),("hy://",hy),
            ("hysteria2://",hy2),("hy2://",hy2),("tuic://",tuic),("wg://",wireguard)
        ] if low.startswith(pre)),None)

        if parser:
            try:
                p=parser(x)
                if p: out.append(p)
            except Exception: pass
        elif "[Interface]" in x and "[Peer]" in x:
            p=wireguard(x)
            if p: out.append(p)
        elif len(x)>12 and "://" not in x:
            key=hashlib.sha256(x.encode("utf-8","ignore")).hexdigest()
            if key in seen_b64: continue
            d=b64(x)
            if d and d != x:
                seen_b64.add(key)
                out += parse_text(d, depth+1, seen_b64)
    return out

def valid(p):
    if not isinstance(p,dict) or s(p.get("type")).lower() not in SUPPORTED or not s(p.get("server")) or not 1<=i(p.get("port"))<=65535:return False
    t=p["type"].lower()
    if t in ("vless","vmess") and not s(p.get("uuid")):return False
    if t in ("trojan","hysteria2") and not s(p.get("password")):return False
    if t=="ss" and not(s(p.get("cipher")) and s(p.get("password"))):return False
    if t=="ssr" and not s(p.get("password")):return False
    if t=="tuic" and not(s(p.get("uuid")) and s(p.get("password"))):return False
    return True

def load_cache():
    try:
        d=json.loads(CACHE_PATH.read_text());return d if isinstance(d,dict) else {}
    except:return {}
RESULT_CACHE=load_cache()

def resolve(h):
    now=time.time();k=h.lower()
    with _lock:
        z=DNS_CACHE.get(k)
        if z and now-z["time"]<=DNS_TTL:return z["addresses"]
    try:
        infos=socket.getaddrinfo(k,None,socket.AF_UNSPEC,socket.SOCK_STREAM)
        a=list(dict.fromkeys(v[4][0] for v in infos))[:MAX_DNS_ADDRESSES][:MAX_DNS_ADDRESSES]
        if a:
            with _lock:DNS_CACHE[k]={"time":now,"addresses":a}
        return a
    except:return []

def _connect_one(addr, family, host, prt):
    try:
        so=socket.socket(family, socket.SOCK_STREAM)
        so.settimeout(TCP_TIMEOUT)
        t=time.monotonic()
        if family == socket.AF_INET6:
            so.connect((addr, prt, 0, 0))
        else:
            so.connect((addr, prt))
        ms=int((time.monotonic()-t)*1000)
        so.close()
        return ms
    except Exception:
        return None

def check(p):
    f=fp(p); now=time.time()
    with _lock:
        z=RESULT_CACHE.get(f)
    if z and now-z.get("time",0) <= CACHE_TTL:
        z=dict(z); z["cached"]=True; return z

    addrs=resolve(p["server"])
    if not addrs:
        r={"status":"dns_failed","ping":None,"family":"","time":now,"addresses":0}
    else:
        futures=[]
        good=[]
        # One tiny per-endpoint TCP connect. No HTTP request, no payload download.
        with ThreadPoolExecutor(max_workers=min(4,len(addrs))) as ex:
            for a in addrs:
                fam=socket.AF_INET6 if ":" in a else socket.AF_INET
                futures.append((fam,a,ex.submit(_connect_one,a,fam,p["server"],p["port"])))
            for fam,a,fut in futures:
                try: ms=fut.result()
                except Exception: ms=None
                if ms is not None:
                    good.append((ms,"IPv6" if fam==socket.AF_INET6 else "IPv4"))
        fams=sorted(set(x[1] for x in good))
        r={
            "status":"tcp_ok" if good else "tcp_failed",
            "ping":min((x[0] for x in good),default=None),
            "family":"+" .join(fams),
            "time":now,
            "addresses":len(addrs)
        }
    with _lock:
        RESULT_CACHE[f]=r
    return r

def workers(n):return 8 if n<=100 else 16 if n<=500 else 24 if n<=2000 else MAX_WORKERS

def entry(p):
    t=p["type"];b={"name":p["name"],"type":t,"server":p["server"],"port":i(p["port"])}
    keys={
      "vless":["uuid","encryption","network","tls","servername","ws-opts","grpc-opts","reality-opts","udp"],
      "vmess":["uuid","alterId","cipher","network","tls","servername","ws-opts","grpc-opts","udp"],
      "trojan":["password","network","tls","sni","ws-opts","udp"],
      "ss":["cipher","password","udp"],
      "ssr":["cipher","password","protocol","obfs","obfs-param","protocol-param","udp"],
      "hysteria":["password","sni","alpn","udp"],"hysteria2":["password","sni","alpn","udp"],
      "tuic":["uuid","password","congestion-controller","alpn","sni","udp"],
      "wireguard":["public_key","private_key","address","mtu","dns","allowed-ips","udp"]}[t]
    for k in keys:
        if k in p and p[k] not in ("",None,[]):b[k]=p[k]
    return b

def atomic_yaml(path,cfg):
    names=[p["name"] for p in cfg["proxies"]];g=cfg["proxy-groups"]
    assert len(g)==1 and g[0]["type"]=="select" and g[0]["name"]==GROUP
    assert all(x=="DIRECT" or x in names for x in g[0]["proxies"])
    text=yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False)
    assert isinstance(yaml.safe_load(text),dict)
    fd,tmp=tempfile.mkstemp(dir=str(path.parent),suffix=".tmp")
    with os.fdopen(fd,"w",encoding="utf-8") as f:f.write(text);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def validate_final_config(cfg):
    if not isinstance(cfg,dict): return False
    proxies=cfg.get("proxies")
    groups=cfg.get("proxy-groups")
    rules=cfg.get("rules")
    if not isinstance(proxies,list) or not isinstance(groups,list) or len(groups)!=1: return False
    if groups[0].get("name") != GROUP or groups[0].get("type") != "select": return False
    names=[p.get("name") for p in proxies if isinstance(p,dict)]
    if len(names) != len(set(names)): return False
    if not isinstance(rules,list) or rules != [f"MATCH,{GROUP}"]: return False
    allowed=set(names)|{"DIRECT"}
    if any(x not in allowed for x in groups[0].get("proxies",[])): return False
    for p in proxies:
        if not isinstance(p,dict): return False
        if not p.get("name") or not p.get("type") or not p.get("server"): return False
        if not 1 <= i(p.get("port")) <= 65535: return False
    return True

def save_cache():
    try:
        items=sorted(RESULT_CACHE.items(),key=lambda x:x[1].get("time",0),reverse=True)[:MAX_CACHE_ITEMS]
        tmp=CACHE_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(dict(items),ensure_ascii=False,separators=(",",":")),encoding="utf-8")
        os.replace(tmp,CACHE_PATH)
    except Exception:
        pass


def validate_detailed(p):
    errors=[]
    t=str(p.get("type","")).lower()
    host=str(p.get("server","")).strip()
    port=i(p.get("port",0))
    if not t: errors.append("MISSING_TYPE")
    if not host: errors.append("MISSING_SERVER")
    if not 1 <= port <= 65535: errors.append("INVALID_PORT")
    if t in ("vless","vmess") and not p.get("uuid"): errors.append("MISSING_UUID")
    if t=="trojan" and not p.get("password"): errors.append("MISSING_PASSWORD")
    if t=="ss" and (not p.get("cipher") or not p.get("password")): errors.append("SS_AUTH_FIELDS")
    if t=="ssr" and not p.get("password"): errors.append("SSR_PASSWORD")
    if t=="tuic" and (not p.get("uuid") or not p.get("password")): errors.append("TUIC_AUTH_FIELDS")
    if t=="hysteria2" and not p.get("password"): errors.append("HY2_PASSWORD")
    return errors

def build_report(stats, failures, final_count):
    lines=[
        f"ENGINE={ENGINE_VERSION}",
        f"PYTHON={platform.python_version()}",
        "",
        "[COUNTS]"
    ]
    lines += [f"{k}={v}" for k,v in stats.items()]
    lines += [
        "",
        "[FINAL]",
        f"FINAL_PROXIES={final_count}",
        "GROUP=Mobile-Fast❤",
        "GROUP_TYPE=select",
        "AUTO_SWITCH=OFF",
        "URL_TEST=OFF",
        "FALLBACK=OFF",
        "LOAD_BALANCE=OFF",
        "HTTP_DOWNLOAD_TEST=OFF",
        "LIVE_PING_IN_YAML=OFF",
        ""
    ]
    if failures:
        lines.append("[FAILURES]")
        lines.extend(str(x) for x in failures[:MAX_REPORT_ITEMS])
    return "\n".join(lines)+"\n"



# ============================================================
# V4 INDUSTRIAL HARDENING LAYER
# ============================================================

SUPPORTED_TYPES = {
    "vless","vmess","trojan","ss","ssr",
    "hysteria","hysteria2","tuic","wireguard",
    "http","socks5","h2","quic"
}

DROP_EMPTY = object()

def clean_scalar(v):
    if isinstance(v, str):
        return v.strip()
    return v

def deep_clean(v):
    """Remove None/empty containers without destroying meaningful False/0."""
    if isinstance(v, dict):
        out={}
        for k,val in v.items():
            val=deep_clean(val)
            if val is DROP_EMPTY:
                continue
            out[k]=val
        return out
    if isinstance(v, list):
        out=[]
        for x in v:
            x=deep_clean(x)
            if x is not DROP_EMPTY:
                out.append(x)
        return out
    if v is None:
        return DROP_EMPTY
    if isinstance(v,str) and not v.strip():
        return DROP_EMPTY
    return clean_scalar(v)

def normalize_final_entry(p):
    """Canonical Mihomo-facing normalization; preserves meaningful options."""
    if not isinstance(p,dict):
        return None
    q=dict(p)

    # Internal fields must never leak into YAML.
    for k in list(q):
        if k.startswith("_") or k in {
            "ping","status","score","cached","dns_status",
            "resolved_ips","fingerprint"
        }:
            q.pop(k,None)

    q["type"]=str(q.get("type","")).lower().strip()
    q["server"]=str(q.get("server","")).strip()
    q["port"]=i(q.get("port",0))

    if not q.get("name"):
        q["name"]=f'{q["type"]}-{q["server"]}-{q["port"]}'

    # Normalize common booleans.
    for k in ("tls","udp","skip-cert-verify","disable-sni"):
        if k in q:
            q[k]=bool(q[k])

    # Normalize ALPN and allowed IP lists.
    for k in ("alpn","allowed-ips","dns"):
        if k in q and isinstance(q[k],str):
            q[k]=[x.strip() for x in q[k].split(",") if x.strip()]

    # Remove empty optional structures, then return.
    q=deep_clean(q)
    return None if q is DROP_EMPTY else q

def strict_entry_validation(p):
    """Return a list of concrete problems; empty means structurally valid."""
    errors=[]
    if not isinstance(p,dict):
        return ["NOT_OBJECT"]

    t=str(p.get("type","")).lower()
    if t not in SUPPORTED_TYPES:
        errors.append("UNSUPPORTED_TYPE")
    if not str(p.get("name","")).strip():
        errors.append("MISSING_NAME")
    host=str(p.get("server","")).strip()
    if not host:
        errors.append("MISSING_SERVER")
    port=i(p.get("port",0))
    if not 1 <= port <= 65535:
        errors.append("INVALID_PORT")

    if t in ("vless","vmess") and not p.get("uuid"):
        errors.append("MISSING_UUID")
    if t=="trojan" and not p.get("password"):
        errors.append("MISSING_PASSWORD")
    if t=="ss" and (not p.get("cipher") or not p.get("password")):
        errors.append("SS_AUTH_FIELDS")
    if t=="ssr" and (not p.get("cipher") or not p.get("password")):
        errors.append("SSR_AUTH_FIELDS")
    if t=="tuic" and (not p.get("uuid") or not p.get("password")):
        errors.append("TUIC_AUTH_FIELDS")
    if t=="hysteria2" and not p.get("password"):
        errors.append("HY2_PASSWORD")

    # Transport-specific structural checks.
    network=str(p.get("network","")).lower()
    if network=="ws":
        ws=p.get("ws-opts")
        if not isinstance(ws,dict):
            errors.append("WS_OPTS_MISSING")
        elif not isinstance(ws.get("path","/"),str):
            errors.append("WS_PATH_INVALID")
    if network=="grpc":
        go=p.get("grpc-opts")
        if go is not None and not isinstance(go,dict):
            errors.append("GRPC_OPTS_INVALID")

    ro=p.get("reality-opts")
    if ro is not None and not isinstance(ro,dict):
        errors.append("REALITY_OPTS_INVALID")

    return errors

def validate_config_strict(cfg):
    errors=[]
    if not isinstance(cfg,dict):
        return ["CONFIG_NOT_OBJECT"]

    proxies=cfg.get("proxies")
    groups=cfg.get("proxy-groups")
    rules=cfg.get("rules")

    if not isinstance(proxies,list) or not proxies:
        errors.append("NO_PROXIES")
    if not isinstance(groups,list) or len(groups)!=1:
        errors.append("GROUP_COUNT_MUST_BE_ONE")
    if not isinstance(rules,list) or not rules:
        errors.append("NO_RULES")

    names=[]
    for p in proxies or []:
        e=strict_entry_validation(p)
        errors.extend([f'PROXY:{p.get("name","?")}:{x}' for x in e])
        names.append(p.get("name"))

    if len(names)!=len(set(names)):
        errors.append("DUPLICATE_PROXY_NAMES")

    if groups:
        g=groups[0]
        if g.get("name")!="Mobile-Fast❤":
            errors.append("GROUP_NAME_INVALID")
        if g.get("type")!="select":
            errors.append("GROUP_TYPE_MUST_BE_SELECT")
        refs=g.get("proxies",[])
        if not isinstance(refs,list):
            errors.append("GROUP_PROXIES_NOT_LIST")
        else:
            known=set(names)|{"DIRECT","REJECT"}
            for ref in refs:
                if ref not in known:
                    errors.append(f"BROKEN_GROUP_REFERENCE:{ref}")

    if rules:
        for r in rules:
            if not isinstance(r,str) or "," not in r:
                errors.append("INVALID_RULE")

    return errors

def yaml_roundtrip_validate(cfg):
    """Serialize and parse again to catch YAML serialization corruption."""
    try:
        dumped=yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False)
        loaded=yaml.safe_load(dumped)
        return loaded, []
    except Exception as e:
        return None,[f"YAML_ROUNDTRIP:{e}"]

def atomic_yaml_v4(path,cfg):
    """Atomic replace: failed writes never destroy an existing good YAML."""
    directory=os.path.dirname(path) or "."
    os.makedirs(directory,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=".mihomo_",suffix=".yaml",dir=directory)
    try:
        with os.fdopen(fd,"w",encoding="utf-8") as f:
            yaml.safe_dump(cfg,f,allow_unicode=True,sort_keys=False,
                           default_flow_style=False,width=1000)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp,path)
        return True,None
    except Exception as e:
        try: os.unlink(tmp)
        except Exception: pass
        return False,str(e)

def make_machine_report(stats,errors,output_path):
    lines=[
        f"ENGINE={ENGINE_VERSION}",
        f"OUTPUT={output_path}",
        "",
        "[ARCHITECTURE]",
        "GROUP_COUNT=1",
        "GROUP_TYPE=select",
        "GROUP_NAME=Mobile-Fast❤",
        "AUTO_SWITCH=OFF",
        "URL_TEST=OFF",
        "FALLBACK=OFF",
        "LOAD_BALANCE=OFF",
        "HTTP_DOWNLOAD_TEST=OFF",
        "LIVE_PING_AFTER_YAML=OFF",
        "",
        "[COUNTS]"
    ]
    lines += [f"{k}={v}" for k,v in stats.items()]
    if errors:
        lines += ["","[ERRORS]"] + [str(x) for x in errors[:MAX_REPORT_ITEMS]]
    return "\n".join(lines)+"\n"


def main():
    open_input()
    try:
        text=INPUT_PATH.read_text(encoding="utf-8",errors="ignore")
        if not text.strip():print("[ERROR] input.txt is empty.");return 1
        folder=input("Enter output folder name in Download: ").strip() or "ClashMetaExport"
        out=input("Enter output file name (without extension): ").strip() or f"clash_meta_{int(time.time())}"
        if not out.endswith(".yaml"):out+=".yaml"
        od=DOWNLOAD_DIR/folder;od.mkdir(parents=True,exist_ok=True);op=od/out
        raw=parse_text(text);st=Counter();st["Input lines"]=sum(bool(x.strip()) for x in text.splitlines());st["Parsed"]=len(raw)
        ps=[]
        for p in raw:
            p["type"]=s(p.get("type")).lower();p["server"]=s(p.get("server"));p["port"]=i(p.get("port"))
            if valid(p):ps.append(p)
            else:st["Invalid"]+=1
        seen=set();u=[]
        for p in ps:
            f=fp(p)
            if f not in seen:seen.add(f);u.append(p)
        st["Duplicate removed"]=len(ps)-len(u);st["Unique"]=len(u)
        st["Cache entries before run"]=len(RESULT_CACHE)
        final=[];fails=[];w=min(workers(len(u)),max(MIN_WORKERS,len(u)))
        for start in range(0,len(u),BATCH_SIZE):
            batch=u[start:start+BATCH_SIZE];print(f"[*] Batch {start+1}-{start+len(batch)} / {len(u)} | workers={w}")
            with ThreadPoolExecutor(max_workers=w) as ex:
                fs={ex.submit(check,p):p for p in batch}
                for f in as_completed(fs):
                    p=fs[f]
                    try:r=f.result()
                    except:r={"status":"test_error","ping":None}
                    p["_test"]=r
                    if r["status"]=="tcp_ok":p["_score"]=max(1,100-min(r["ping"] or 999,99));final.append(p)
                    else:fails.append(f"{r['status']}\t{p['type']}\t{p['server']}:{p['port']}")
        final.sort(key=lambda p:(-p.get("_score",0),p["_test"].get("ping",999999)))
        USED.clear();entries=[]
        for p in final:
            e=entry(p);e["name"]=name(e["name"]);entries.append(e)
        cfg={"proxies":entries,"proxy-groups":[{"name":GROUP,"type":"select","proxies":["DIRECT"]+[x["name"] for x in entries]}],"rules":[f"MATCH,{GROUP}"]}
        if not validate_final_config(cfg):
            print("[ERROR] Final configuration validation failed; YAML was not written.")
            return 1
        # FINAL_CONFIG_GUARD_V3
        _groups=cfg.get("proxy-groups",[])
        if (len(_groups)!=1 or _groups[0].get("type")!="select"
            or _groups[0].get("name")!="Mobile-Fast❤"):
            print("[ERROR] V3 final group validation failed.")
            return 1
        _names={p.get("name") for p in cfg.get("proxies",[]) if isinstance(p,dict)}
        if len(_names)!=len(cfg.get("proxies",[])):
            print("[ERROR] V3 duplicate proxy names detected.")
            return 1
        if any(x not in _names and x!="DIRECT" for x in _groups[0].get("proxies",[])):
            print("[ERROR] V3 broken group reference detected.")
            return 1
        # FINAL_CONFIG_GUARD_V4
        _cfg_errors=validate_config_strict(cfg)
        if _cfg_errors:
            print("[ERROR] Strict final validation failed:")
            for _e in _cfg_errors[:50]:
                print("  -",_e)
            return 1
        _round,_round_errors=yaml_roundtrip_validate(cfg)
        if _round_errors:
            print("[ERROR] YAML round-trip validation failed:")
            for _e in _round_errors:
                print("  -",_e)
            return 1
        cfg=_round
        
        atomic_yaml_v4(op,cfg)
        report=od/(op.stem+"_report.txt");failed=od/(op.stem+"_failed.txt")
        report.write_text("\n".join([f"{k}: {v}" for k,v in st.items()]+[f"Final: {len(entries)}","Group: "+GROUP,"Groups: 1","URL-Test: OFF","Fallback: OFF","Load-Balance: OFF","Automatic switching: OFF","Post-output ping: OFF","HTTP download test: OFF",f"Cache TTL: {CACHE_TTL} seconds",f"DNS TTL: {DNS_TTL} seconds",f"Batch size: {BATCH_SIZE}",f"Workers: {w}"])+"\n",encoding="utf-8")
        failed.write_text("\n".join(fails)+("\n" if fails else ""),encoding="utf-8")
        # Persist bounded cache atomically.
        save_cache()
        print("="*60);print("[DONE]");print("Output:",op);print("Final:",len(entries));print("Group:",GROUP);print("Groups: 1");print("Auto switch: OFF");print("Post-output ping: OFF");print("="*60)
        return 0
    finally: clear_input()

if __name__=="__main__":raise SystemExit(main())

