#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
import os,re,sys,json,time,socket,base64,tempfile,subprocess,hashlib
from pathlib import Path
from urllib.parse import urlparse,parse_qs,unquote
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import yaml

BASE_DIR=Path("/storage/emulated/0/Download/Akbar98"); BASE_DIR.mkdir(parents=True,exist_ok=True)
DOWNLOAD_DIR=Path("/storage/emulated/0/Download")
INPUT_PATH=BASE_DIR/"input.txt"
CACHE_PATH=BASE_DIR/".mihomo_test_cache.json"

GROUP="Mobile-Fast❤"
TCP_TIMEOUT=1.35
CACHE_TTL=600
DNS_TTL=300
BATCH_SIZE=100
MAX_WORKERS=32
MIN_WORKERS=6
MAX_CACHE_ITEMS=20000
SUPPORTED={"vless","vmess","trojan","ss","ssr","hysteria","hysteria2","tuic","wireguard"}
_lock=__import__("threading").Lock()
DNS_CACHE={}
USED=set()

def s(v): return "" if v is None else str(v).strip()
def i(v,d=0):
    try:return int(v)
    except:
        try:return int(float(v))
        except:return d
def port(v,d=443):
    x=i(v,d); return x if 1<=x<=65535 else d
def b64(v):
    x=re.sub(r"\s+","",s(v)).replace("-","+").replace("_","/")
    x+="="*((4-len(x)%4)%4)
    try:return base64.b64decode(x).decode("utf-8","ignore")
    except:return ""
def qs(q): return {k:(v[0] if v else "") for k,v in parse_qs(q,keep_blank_values=True).items()}
def tail(v,n=6):
    x=re.sub(r"[^A-Za-z0-9]","",s(v)); return x[-n:] if len(x)>n else x
def name(v):
    x=re.sub(r"[^A-Za-z0-9_\-. \u0600-\u06FF❤💚💛💙🔰]","",s(v)).strip() or "Proxy"
    z=x;n=2
    while z in USED:z=f"{x} {n}";n+=1
    USED.add(z);return z
def fp(p):
    q={k:v for k,v in p.items() if k not in {"name","_test","_score"}}
    return hashlib.sha256(json.dumps(q,sort_keys=True,ensure_ascii=False,default=str,separators=(",",":")).encode()).hexdigest()

def open_input():
    INPUT_PATH.write_text("",encoding="utf-8")
    try: subprocess.run(["nano",str(INPUT_PATH)],check=False)
    except Exception: input("Edit input.txt then press Enter...")
def clear_input():
    try: INPUT_PATH.write_text("",encoding="utf-8")
    except: pass

def vless(x):
    try:
        raw=x[8:];frag=""
        if "#" in raw:raw,frag=raw.split("#",1);frag=unquote(frag)
        main,qraw=(raw.split("?",1)+[""])[:2] if "?" in raw else (raw,"")
        uid,ep=main.rsplit("@",1);q=qs(qraw)
        if ep.startswith("["):
            k=ep.find("]");host=ep[1:k];ps=ep[k+2:] if ep[k+1:k+2]==":" else "443"
        else:host,_,ps=ep.rpartition(":");host=host or ep;ps=ps or "443"
        net=(q.get("type") or q.get("network") or "tcp").lower();sec=q.get("security","").lower()
        p={"name":frag or q.get("remark") or f"vless-{host}-{tail(uid)}","type":"vless","server":host,"port":port(ps),"uuid":unquote(uid),"encryption":q.get("encryption") or "none","network":net,"udp":True}
        if sec in ("tls","reality") or q.get("pbk"):p["tls"]=True;p["servername"]=q.get("sni") or q.get("servername") or q.get("host") or host
        if net=="ws":
            p["ws-opts"]={"path":q.get("path") or "/"};h=q.get("host") or q.get("Host")
            if h:p["ws-opts"]["headers"]={"Host":h}
        if net=="grpc" and (sv:=q.get("serviceName") or q.get("service")):p["grpc-opts"]={"grpc-service-name":sv}
        if sec=="reality" or q.get("pbk") or q.get("sid"):p["reality-opts"]={"public-key":q.get("pbk",""),"short-id":q.get("sid",""),"server-name":q.get("sni") or host};p["tls"]=True
        return p
    except:return None

def vmess(x):
    try:
        o=json.loads(b64(x[8:]) or unquote(x[8:]));h=o.get("add") or o.get("address") or o.get("server");u=o.get("id") or o.get("uuid")
        if not(h and u):return None
        net=(o.get("net") or "tcp").lower()
        p={"name":o.get("ps") or f"vmess-{h}-{tail(u)}","type":"vmess","server":h,"port":port(o.get("port"),443),"uuid":u,"alterId":i(o.get("aid",o.get("alterId",0))),"cipher":o.get("scy") or o.get("cipher") or "auto","network":net,"udp":True}
        if str(o.get("tls","")).lower() in ("tls","true","1"):p["tls"]=True;p["servername"]=o.get("sni") or o.get("host") or h
        if net=="ws":p["ws-opts"]={"path":o.get("path") or "/"};p["ws-opts"].update({"headers":{"Host":o["host"]}} if o.get("host") else {})
        if net=="grpc" and o.get("serviceName"):p["grpc-opts"]={"grpc-service-name":o["serviceName"]}
        return p
    except:return None

def trojan(x):
    try:
        u=urlparse(x);q=parse_qs(u.query,keep_blank_values=True);h=u.hostname or "";pwd=unquote(u.username or "")
        if not(h and pwd):return None
        p={"name":unquote(u.fragment or "") or f"trojan-{h}-{tail(pwd)}","type":"trojan","server":h,"port":u.port or 443,"password":pwd,"network":"tcp","tls":True,"sni":q.get("sni",[h])[0],"udp":True}
        if q.get("type",["tcp"])[0]=="ws":p["network"]="ws";p["ws-opts"]={"path":q.get("path",["/"])[0],"headers":{"Host":q.get("host",[""])[0]}}
        return p
    except:return None

def ss(x):
    try:
        body=x[5:];frag=""
        if "#" in body:body,frag=body.split("#",1);frag=unquote(frag)
        if "@" in body:
            c,a=body.rsplit("@",1);d=b64(c)
            if ":" in d:c=d
            m,pw=c.split(":",1);h,_,ps=a.rpartition(":")
        else:
            d=b64(body);c,a=d.rsplit("@",1);m,pw=c.split(":",1);h,_,ps=a.rpartition(":")
        return {"name":frag or f"ss-{h}-{ps}","type":"ss","server":h,"port":port(ps,8388),"cipher":m,"password":pw,"udp":True} if h and m and pw else None
    except:return None

def ssr(x):
    try:
        d=b64(x[6:]);main,_,par=d.partition("/?");a=main.split(":")
        if len(a)!=6:return None
        h,ps,proto,ciph,obfs,pwb=a;pw=b64(pwb);q={}
        for k,v in parse_qs(par,keep_blank_values=True).items():q[k]=b64(v[0]) or v[0]
        return {"name":q.get("remarks") or f"ssr-{h}-{ps}","type":"ssr","server":h,"port":port(ps),"cipher":ciph,"password":pw,"protocol":proto,"obfs":obfs,"obfs-param":q.get("obfsparam",""),"protocol-param":q.get("protoparam",""),"udp":True}
    except:return None

def hy(x):
    try:
        raw=re.sub(r"^(hysteria|hy)://","",x,flags=re.I);frag=""
        if "#" in raw:raw,frag=raw.split("#",1);frag=unquote(frag)
        main,qraw=(raw.split("?",1)+[""])[:2] if "?" in raw else (raw,"")
        auth,ep=main.rsplit("@",1);h,_,ps=ep.rpartition(":");q=qs(qraw)
        return {"name":frag or f"hysteria-{h}","type":"hysteria","server":h,"port":port(ps),"password":unquote(auth),"sni":q.get("sni") or h,"alpn":[z for z in q.get("alpn","").split(",") if z],"udp":True}
    except:return None

def hy2(x):
    try:
        raw=re.sub(r"^(hysteria2|hy2)://","",x,flags=re.I);frag=""
        if "#" in raw:raw,frag=raw.split("#",1);frag=unquote(frag)
        main,qraw=(raw.split("?",1)+[""])[:2] if "?" in raw else (raw,"");auth,ep=main.rsplit("@",1);h,_,ps=ep.rpartition(":");q=qs(qraw)
        return {"name":frag or f"hysteria2-{h}","type":"hysteria2","server":h,"port":port(ps),"password":unquote(auth.split(":",1)[-1]),"sni":q.get("sni") or h,"alpn":[z for z in q.get("alpn","").split(",") if z],"udp":True}
    except:return None

def tuic(x):
    try:
        raw=x[7:];frag=""
        if "#" in raw:raw,frag=raw.split("#",1);frag=unquote(frag)
        main,qraw=(raw.split("?",1)+[""])[:2] if "?" in raw else (raw,"");auth,ep=main.rsplit("@",1);uid,_,pw=auth.partition(":");h,_,ps=ep.rpartition(":");q=qs(qraw)
        return {"name":frag or f"tuic-{h}-{tail(uid)}","type":"tuic","server":h,"port":port(ps),"uuid":uid,"password":pw,"congestion-controller":q.get("congestion") or "bbr","alpn":[z for z in (q.get("alpn") or "h3").split(",") if z],"sni":q.get("sni") or h,"udp":True}
    except:return None

def wireguard(x):
    try:
        if x.lower().startswith("wg://"):
            u=urlparse(x);q=parse_qs(u.query,keep_blank_values=True);h=u.hostname or ""
            return {"name":unquote(u.fragment or "") or f"wg-{h}","type":"wireguard","server":h,"port":u.port or 51820,"public_key":u.username or "","private_key":q.get("privateKey",[""])[0],"address":q.get("address",[""])[0],"mtu":i(q.get("mtu",["1280"])[0],1280),"udp":True}
        e=re.search(r"(?im)^\s*Endpoint\s*=\s*(.+?):(\d+)\s*$",x)
        if not e:return None
        pk=re.search(r"(?im)^\s*PublicKey\s*=\s*(.+?)\s*$",x)
        return {"name":f"wg-{e.group(1)}","type":"wireguard","server":e.group(1),"port":port(e.group(2),51820),"public_key":pk.group(1).strip() if pk else "","udp":True}
    except:return None

def json_nodes(o):
    out=[]
    if not isinstance(o,dict):return out
    obs=o.get("outbounds") or o.get("proxy") or []
    if isinstance(obs,dict):obs=[obs]
    for ob in obs:
        if not isinstance(ob,dict):continue
        t=s(ob.get("protocol") or ob.get("type")).lower();st=ob.get("settings") or {}
        if t in ("vless","vmess"):
            vs=st.get("vnext") or st.get("servers") or [];v=vs[0] if vs else {};us=v.get("users") or [];u=us[0] if us else {};h=v.get("address") or v.get("server") or ob.get("address");uid=u.get("id") or u.get("uuid")
            if not(h and uid):continue
            stream=ob.get("streamSettings") or {};net=stream.get("network") or "tcp";p={"name":ob.get("tag") or f"{t}-{h}-{tail(uid)}","type":t,"server":h,"port":port(v.get("port") or ob.get("port")),"uuid":uid,"network":net,"udp":True}
            if t=="vless":p["encryption"]="none"
            else:p["alterId"]=i(u.get("alterId",u.get("aid",0)));p["cipher"]=u.get("cipher") or u.get("scy") or "auto"
            sec=s(stream.get("security")).lower()
            if sec in ("tls","reality"):p["tls"]=True;p["servername"]=(stream.get("tlsSettings") or {}).get("serverName") or h
            if net=="ws":
                w=stream.get("wsSettings") or {};p["ws-opts"]={"path":w.get("path") or "/"};p["ws-opts"].update({"headers":w["headers"]} if w.get("headers") else {})
            if net=="grpc" and (g:=stream.get("grpcSettings") or {}).get("serviceName"):p["grpc-opts"]={"grpc-service-name":g["serviceName"]}
            out.append(p)
        elif t=="trojan":
            a=(st.get("servers") or [{}])[0];h=a.get("address") or a.get("server") or ob.get("address");pw=a.get("password") or a.get("pass")
            if h and pw:out.append({"name":ob.get("tag") or f"trojan-{h}","type":"trojan","server":h,"port":port(a.get("port"),443),"password":pw,"tls":True,"sni":h,"udp":True})
        elif t in ("ss","shadowsocks"):
            a=(st.get("servers") or [{}])[0];h=a.get("address") or a.get("server") or ob.get("address");m=a.get("method") or a.get("cipher");pw=a.get("password") or a.get("passwd")
            if h and m and pw:out.append({"name":ob.get("tag") or f"ss-{h}","type":"ss","server":h,"port":port(a.get("port"),8388),"cipher":m,"password":pw,"udp":True})
    return out

def parse_text(text):
    out=[]
    try:
        for d in yaml.safe_load_all(text):
            if isinstance(d,dict):
                ps=d.get("proxies") or d.get("proxy") or []
                if isinstance(ps,dict):ps=[ps]
                out += [dict(p) for p in ps if isinstance(p,dict)]
    except:pass
    for m in re.findall(r'\{(?:[^{}]|"(?:\\.|[^"])*")*\}',text,re.S):
        try:out+=json_nodes(json.loads(m))
        except:pass
    for line in text.splitlines():
        x=line.strip()
        if not x:continue
        low=x.lower()
        parser=next((f for pre,f in [
            ("vless://",vless),("vmess://",vmess),("trojan://",trojan),
            ("ss://",ss),("ssr://",ssr),("hysteria://",hy),("hy://",hy),
            ("hysteria2://",hy2),("hy2://",hy2),("tuic://",tuic),("wg://",wireguard)] if low.startswith(pre)),None)
        if parser:
            p=parser(x)
            if p:out.append(p)
        elif "[Interface]" in x and "[Peer]" in x:
            p=wireguard(x)
            if p:out.append(p)
        elif len(x)>12 and "://" not in x:
            d=b64(x)
            if d and d!=x:out+=parse_text(d)
    return out

def valid(p):
    if not isinstance(p,dict) or s(p.get("type")).lower() not in SUPPORTED or not s(p.get("server")) or not 1<=i(p.get("port"))<=65535:return False
    t=p["type"].lower()
    if t in ("vless","vmess") and not s(p.get("uuid")):return False
    if t in ("trojan","hysteria2") and not s(p.get("password")):return False
    if t=="ss" and not(s(p.get("cipher")) and s(p.get("password"))):return False
    if t=="ssr" and not s(p.get("password")):return False
    if t=="tuic" and not(s(p.get("uuid")) and s(p.get("password"))):return False
    return True

def load_cache():
    try:
        d=json.loads(CACHE_PATH.read_text());return d if isinstance(d,dict) else {}
    except:return {}
RESULT_CACHE=load_cache()

def resolve(h):
    now=time.time();k=h.lower()
    with _lock:
        z=DNS_CACHE.get(k)
        if z and now-z["time"]<=DNS_TTL:return z["addresses"]
    try:
        infos=socket.getaddrinfo(k,None,socket.AF_UNSPEC,socket.SOCK_STREAM)
        a=list(dict.fromkeys(v[4][0] for v in infos))
        if a:
            with _lock:DNS_CACHE[k]={"time":now,"addresses":a}
        return a
    except:return []

def check(p):
    f=fp(p);now=time.time()
    with _lock:z=RESULT_CACHE.get(f)
    if z and now-z.get("time",0)<=CACHE_TTL:
        z=dict(z);z["cached"]=True;return z
    addrs=resolve(p["server"])
    if not addrs:r={"status":"dns_failed","ping":None,"family":"","time":now}
    else:
        good=[]
        for a in addrs[:8]:
            fam=socket.AF_INET6 if ":" in a else socket.AF_INET
            try:
                so=socket.socket(fam,socket.SOCK_STREAM);so.settimeout(TCP_TIMEOUT);t=time.monotonic()
                so.connect((a,p["port"],0,0) if fam==socket.AF_INET6 else (a,p["port"]));so.close()
                good.append((int((time.monotonic()-t)*1000),"IPv6" if fam==socket.AF_INET6 else "IPv4"))
            except:pass
        r={"status":"tcp_ok" if good else "tcp_failed","ping":min((x[0] for x in good),default=None),"family":"+".join(sorted(set(x[1] for x in good))),"time":now}
    with _lock:RESULT_CACHE[f]=r
    return r

def workers(n):return 8 if n<=100 else 16 if n<=500 else 24 if n<=2000 else MAX_WORKERS

def entry(p):
    t=p["type"];b={"name":p["name"],"type":t,"server":p["server"],"port":i(p["port"])}
    keys={
      "vless":["uuid","encryption","network","tls","servername","ws-opts","grpc-opts","reality-opts","udp"],
      "vmess":["uuid","alterId","cipher","network","tls","servername","ws-opts","grpc-opts","udp"],
      "trojan":["password","network","tls","sni","ws-opts","udp"],
      "ss":["cipher","password","udp"],
      "ssr":["cipher","password","protocol","obfs","obfs-param","protocol-param","udp"],
      "hysteria":["password","sni","alpn","udp"],"hysteria2":["password","sni","alpn","udp"],
      "tuic":["uuid","password","congestion-controller","alpn","sni","udp"],
      "wireguard":["public_key","private_key","address","mtu","dns","allowed-ips","udp"]}[t]
    for k in keys:
        if k in p and p[k] not in ("",None,[]):b[k]=p[k]
    return b

def atomic_yaml(path,cfg):
    names=[p["name"] for p in cfg["proxies"]];g=cfg["proxy-groups"]
    assert len(g)==1 and g[0]["type"]=="select" and g[0]["name"]==GROUP
    assert all(x=="DIRECT" or x in names for x in g[0]["proxies"])
    text=yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False)
    assert isinstance(yaml.safe_load(text),dict)
    fd,tmp=tempfile.mkstemp(dir=str(path.parent),suffix=".tmp")
    with os.fdopen(fd,"w",encoding="utf-8") as f:f.write(text);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def main():
    open_input()
    try:
        text=INPUT_PATH.read_text(encoding="utf-8",errors="ignore")
        if not text.strip():print("[ERROR] input.txt is empty.");return 1
        folder=input("Enter output folder name in Download: ").strip() or "ClashMetaExport"
        out=input("Enter output file name (without extension): ").strip() or f"clash_meta_{int(time.time())}"
        if not out.endswith(".yaml"):out+=".yaml"
        od=DOWNLOAD_DIR/folder;od.mkdir(parents=True,exist_ok=True);op=od/out
        raw=parse_text(text);st=Counter();st["Input lines"]=sum(bool(x.strip()) for x in text.splitlines());st["Parsed"]=len(raw)
        ps=[]
        for p in raw:
            p["type"]=s(p.get("type")).lower();p["server"]=s(p.get("server"));p["port"]=i(p.get("port"))
            if valid(p):ps.append(p)
            else:st["Invalid"]+=1
        seen=set();u=[]
        for p in ps:
            f=fp(p)
            if f not in seen:seen.add(f);u.append(p)
        st["Duplicate removed"]=len(ps)-len(u);st["Unique"]=len(u)
        final=[];fails=[];w=min(workers(len(u)),max(MIN_WORKERS,len(u)))
        for start in range(0,len(u),BATCH_SIZE):
            batch=u[start:start+BATCH_SIZE];print(f"[*] Batch {start+1}-{start+len(batch)} / {len(u)} | workers={w}")
            with ThreadPoolExecutor(max_workers=w) as ex:
                fs={ex.submit(check,p):p for p in batch}
                for f in as_completed(fs):
                    p=fs[f]
                    try:r=f.result()
                    except:r={"status":"test_error","ping":None}
                    p["_test"]=r
                    if r["status"]=="tcp_ok":p["_score"]=100-min(r["ping"] or 1000,99);final.append(p)
                    else:fails.append(f"{r['status']}\t{p['type']}\t{p['server']}:{p['port']}")
        final.sort(key=lambda p:(-p.get("_score",0),p["_test"].get("ping",999999)))
        USED.clear();entries=[]
        for p in final:
            e=entry(p);e["name"]=name(e["name"]);entries.append(e)
        cfg={"proxies":entries,"proxy-groups":[{"name":GROUP,"type":"select","proxies":["DIRECT"]+[x["name"] for x in entries]}],"rules":[f"MATCH,{GROUP}"]}
        atomic_yaml(op,cfg)
        report=od/(op.stem+"_report.txt");failed=od/(op.stem+"_failed.txt")
        report.write_text("\n".join([f"{k}: {v}" for k,v in st.items()]+[f"Final: {len(entries)}","Group: "+GROUP,"Groups: 1","URL-Test: OFF","Fallback: OFF","Load-Balance: OFF","Automatic switching: OFF","Post-output ping: OFF","HTTP download test: OFF","Cache TTL: 600 seconds"])+"\n",encoding="utf-8")
        failed.write_text("\n".join(fails)+("\n" if fails else ""),encoding="utf-8")
        # persist bounded cache
        items=sorted(RESULT_CACHE.items(),key=lambda x:x[1].get("time",0),reverse=True)[:MAX_CACHE_ITEMS]
        CACHE_PATH.write_text(json.dumps(dict(items),separators=(",",":")),encoding="utf-8")
        print("="*60);print("[DONE]");print("Output:",op);print("Final:",len(entries));print("Group:",GROUP);print("Groups: 1");print("Auto switch: OFF");print("Post-output ping: OFF");print("="*60)
        return 0
    finally: clear_input()

if __name__=="__main__":raise SystemExit(main())

