#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-

"""
===============================================================
 AKBAR98 - MIHOMO INDUSTRIAL BUILDER
===============================================================

Purpose
-------
High-volume proxy parser / normalizer / deduplicator / lightweight
reachability tester / scorer / Mihomo YAML builder.

Designed for:
    Android
    Termux
    Mihomo
    FlClash
    2,000 - 5,000+ proxy candidates

CORE DESIGN
-----------
1. Input editor is opened EMPTY every run.
2. Input is processed once.
3. Input file is cleared after processing.
4. No HTTP download test.
5. No bandwidth benchmark.
6. No URL-test group.
7. No fallback group.
8. No load-balance group.
9. No automatic proxy switching.
10. Exactly ONE proxy-group: manual select.
11. DNS resolution is cached.
12. TCP reachability is cached.
13. IPv4 / IPv6 are handled intelligently.
14. Deduplication uses structural fingerprints.
15. Unknown URL parameters are reported instead of silently discarded.
16. Results are cached between executions.
17. Adaptive worker count.
18. Batch processing.
19. Final YAML is validated before replacement.
20. Output writes atomically.

IMPORTANT
---------
TCP reachability != protocol validity != Internet usability.

A node passing TCP means:
    DNS resolved
    AND
    TCP connection to server:port succeeded

It does NOT prove:
    UUID/password is valid
    TLS handshake is valid
    Reality handshake is valid
    WebSocket is valid
    gRPC is valid
    remote proxy actually forwards Internet traffic

This is intentional to keep testing lightweight.

===============================================================
"""

import os
import re
import sys
import json
import time
import socket
import base64
import hashlib
import tempfile
import threading
import subprocess

from urllib.parse import (
    urlparse,
    parse_qs,
    unquote,
    quote,
)

from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)

from collections import Counter

try:
    import yaml
except ImportError:
    print("[FATAL] PyYAML is not installed.")
    print("Install with:")
    print("pip install pyyaml")
    sys.exit(1)


# ===============================================================
# VERSION / BUILD
# ===============================================================

VERSION = "AKBAR98-MIHOMO-INDUSTRIAL-1.0"

BASE_DIR = "/storage/emulated/0/Download/Akbar98"

INPUT_PATH = os.path.join(
    BASE_DIR,
    "input.txt"
)

CACHE_PATH = os.path.join(
    BASE_DIR,
    ".proxy_test_cache.json"
)

os.makedirs(
    BASE_DIR,
    exist_ok=True
)


# ===============================================================
# CONFIGURATION
# ===============================================================

# Input / cache
CACHE_TTL_SECONDS = 600
DNS_CACHE_TTL_SECONDS = 300

# TCP test
TCP_TIMEOUT = 1.35
TCP_ATTEMPTS = 2

# batch
BATCH_SIZE = 100

# workers
MIN_WORKERS = 8
MAX_WORKERS = 32

# scoring
MAX_SCORE = 100

# output
GROUP_NAME = "Mobile-Fast❤"

# No automatic switching
AUTO_SWITCH = False

# No URL test
MIHOMO_URL_TEST = False

# DNS section
DNS_ENABLED = True

# Keep only TCP reachable nodes
KEEP_TCP_REACHABLE = True


# ===============================================================
# THREAD SAFE GLOBALS
# ===============================================================

_cache_lock = threading.RLock()
_dns_lock = threading.RLock()
_name_lock = threading.RLock()

_dns_cache = {}
_test_cache = {}

_used_names = set()


# ===============================================================
# FILE HELPERS
# ===============================================================

def atomic_write_text(path, text):
    """
    Safely replace a file only after complete successful write.
    """
    directory = os.path.dirname(path)

    fd, temp_path = tempfile.mkstemp(
        prefix=".akbar98_",
        suffix=".tmp",
        dir=directory
    )

    try:
        with os.fdopen(
            fd,
            "w",
            encoding="utf-8"
        ) as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())

        os.replace(
            temp_path,
            path
        )

    except Exception:
        try:
            os.unlink(temp_path)
        except Exception:
            pass
        raise


def clear_input_file():
    """
    Always leave the next run with an empty editor file.
    """
    try:
        atomic_write_text(
            INPUT_PATH,
            ""
        )
    except Exception:
        try:
            with open(
                INPUT_PATH,
                "w",
                encoding="utf-8"
            ) as f:
                f.write("")
        except Exception:
            pass


def open_empty_input_editor():
    """
    Clear BEFORE opening nano.
    Therefore nano is never pre-filled by previous execution.
    """
    clear_input_file()

    try:
        subprocess.call(
            ["nano", INPUT_PATH]
        )
    except FileNotFoundError:
        print(
            "[WARN] nano not found."
        )
    except Exception as e:
        print(
            f"[WARN] Could not open nano: {e}"
        )


# ===============================================================
# SAFE CONVERSION
# ===============================================================

def safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        try:
            return int(float(value))
        except Exception:
            return default


def clean_string(value):
    if value is None:
        return ""

    return str(value).strip()


def b64fix(value):
    if not value:
        return ""

    s = str(value).strip()

    s = (
        s
        .replace("\r", "")
        .replace("\n", "")
        .replace(" ", "")
        .replace("-", "+")
        .replace("_", "/")
    )

    pad = len(s) % 4

    if pad:
        s += "=" * (4 - pad)

    return s


def b64decode_text(value):
    try:
        raw = base64.b64decode(
            b64fix(value),
            validate=False
        )

        return raw.decode(
            "utf-8",
            "ignore"
        )

    except Exception:
        return ""


def is_probably_base64(value):
    if not isinstance(value, str):
        return False

    s = value.strip()

    if len(s) < 16:
        return False

    if "://" in s:
        return False

    try:
        decoded = b64decode_text(s)

        if not decoded:
            return False

        indicators = (
            "vless://",
            "vmess://",
            "trojan://",
            "ss://",
            "ssr://",
            "hy://",
            "hy2://",
            "hysteria",
            "tuic://",
            "wg://",
        )

        return any(
            x in decoded.lower()
            for x in indicators
        )

    except Exception:
        return False


# ===============================================================
# NAME MANAGEMENT
# ===============================================================

def sanitize_name(value):
    value = unquote(
        clean_string(value)
    )

    value = re.sub(
        r"[\x00-\x1f\x7f]",
        "",
        value
    )

    value = re.sub(
        r'[\\/:*?"<>|]+',
        "_",
        value
    )

    value = re.sub(
        r"\s+",
        " ",
        value
    ).strip()

    if not value:
        value = "Proxy"

    return value[:180]


def reset_name_registry():
    with _name_lock:
        _used_names.clear()


def unique_name(value):
    base = sanitize_name(value)

    with _name_lock:

        if base not in _used_names:
            _used_names.add(base)
            return base

        i = 2

        while True:

            candidate = (
                f"{base} {i}"
            )

            if candidate not in _used_names:
                _used_names.add(candidate)
                return candidate

            i += 1


def stable_name(proxy):
    """
    Name generated from protocol/server/port when no reliable
    remark exists.
    """
    proto = proxy.get(
        "type",
        "proxy"
    )

    server = proxy.get(
        "server",
        "unknown"
    )

    port = safe_int(
        proxy.get("port"),
        0
    )

    return (
        f"{proto}-{server}-{port}"
    )


# ===============================================================
# URL QUERY HELPERS
# ===============================================================

def query_dict(query):
    try:
        raw = parse_qs(
            query,
            keep_blank_values=True
        )

        return {
            k: v[0] if v else ""
            for k, v in raw.items()
        }

    except Exception:
        return {}


def first_value(q, *keys, default=""):
    for key in keys:
        if key in q:
            return q[key]

    return default


# ===============================================================
# UNKNOWN PARAMETER TRACKING
# ===============================================================

KNOWN_QUERY_KEYS = {

    "vless": {
        "type",
        "encryption",
        "security",
        "sni",
        "servername",
        "host",
        "path",
        "serviceName",
        "service",
        "flow",
        "fp",
        "pbk",
        "sid",
        "spx",
        "allowInsecure",
    },

    "vmess": {
        "type",
        "security",
        "sni",
        "host",
        "path",
        "serviceName",
        "flow",
        "fp",
    },

    "trojan": {
        "security",
        "type",
        "sni",
        "host",
        "path",
        "serviceName",
        "allowInsecure",
    },

    "hysteria": {
        "sni",
        "alpn",
        "auth",
        "obfs",
        "protocol",
        "upmbps",
        "downmbps",
    },

    "hysteria2": {
        "sni",
        "alpn",
        "obfs",
        "obfs-password",
        "insecure",
    },

    "tuic": {
        "sni",
        "alpn",
        "congestion_control",
        "congestion",
        "udp_relay_mode",
        "zero_rtt",
        "zerortt",
    },

    "ss": {
    },

}


def collect_unknown_query_params(
    protocol,
    query
):
    known = KNOWN_QUERY_KEYS.get(
        protocol,
        set()
    )

    unknown = []

    for key in query.keys():

        if key not in known:
            unknown.append(key)

    return unknown


# ===============================================================
# FINGERPRINT
# ===============================================================

SECRET_FIELDS = {
    "uuid",
    "password",
    "username",
    "private_key",
    "public_key",
}


def canonicalize(value):
    """
    Deterministic recursive normalization.
    """
    if isinstance(value, dict):

        return {
            str(k): canonicalize(value[k])
            for k in sorted(
                value.keys(),
                key=lambda x: str(x)
            )
            if k != "name"
        }

    if isinstance(value, list):

        return [
            canonicalize(x)
            for x in value
        ]

    if isinstance(value, bool):
        return value

    if value is None:
        return None

    return str(value)


def proxy_fingerprint(proxy):
    """
    Full structural fingerprint.

    Name is deliberately excluded.

    Credentials and protocol parameters ARE included.
    Therefore two nodes sharing server:port but having different
    UUID/SNI/Reality settings are NOT incorrectly merged.
    """

    normalized = canonicalize(
        proxy
    )

    payload = json.dumps(
        normalized,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":")
    )

    return hashlib.sha256(
        payload.encode(
            "utf-8"
        )
    ).hexdigest()


def endpoint_fingerprint(proxy):
    """
    Endpoint-only fingerprint.

    Used for cache grouping, not identity deduplication.
    """
    data = {
        "server": proxy.get("server"),
        "port": safe_int(
            proxy.get("port")
        )
    }

    payload = json.dumps(
        data,
        sort_keys=True,
        separators=(",", ":")
    )

    return hashlib.sha256(
        payload.encode()
    ).hexdigest()


# ===============================================================
# DNS CACHE
# ===============================================================

def resolve_host(host):
    """
    Resolve both IPv4 and IPv6 where available.

    Returns:
        {
            addresses: [...],
            ipv4: [...],
            ipv6: [...]
        }
    """

    host = clean_string(host)

    if not host:
        return {
            "addresses": [],
            "ipv4": [],
            "ipv6": []
        }

    now = time.time()

    with _dns_lock:

        cached = _dns_cache.get(
            host
        )

        if cached:

            if (
                now - cached["time"]
                <= DNS_CACHE_TTL_SECONDS
            ):
                return cached["result"]

    ipv4 = []
    ipv6 = []

    try:

        infos = socket.getaddrinfo(
            host,
            None,
            socket.AF_UNSPEC,
            socket.SOCK_STREAM
        )

        for item in infos:

            family = item[0]
            sockaddr = item[4]

            if not sockaddr:
                continue

            ip = sockaddr[0]

            if family == socket.AF_INET:

                if ip not in ipv4:
                    ipv4.append(ip)

            elif family == socket.AF_INET6:

                if ip not in ipv6:
                    ipv6.append(ip)

    except Exception:
        pass

    result = {
        "addresses": (
            ipv4 + ipv6
        ),
        "ipv4": ipv4,
        "ipv6": ipv6
    }

    with _dns_lock:

        _dns_cache[host] = {
            "time": now,
            "result": result
        }

    return result


# ===============================================================
# TCP TEST
# ===============================================================

def tcp_connect_ip(
    ip,
    port,
    timeout
):
    family = (
        socket.AF_INET6
        if ":" in ip
        else socket.AF_INET
    )

    sock = None

    try:

        sock = socket.socket(
            family,
            socket.SOCK_STREAM
        )

        sock.settimeout(
            timeout
        )

        started = time.monotonic()

        sock.connect(
            (ip, int(port))
        )

        elapsed = int(
            (time.monotonic() - started)
            * 1000
        )

        return {
            "ok": True,
            "latency": elapsed,
            "ip": ip
        }

    except Exception:

        return {
            "ok": False,
            "latency": None,
            "ip": ip
        }

    finally:

        if sock is not None:

            try:
                sock.close()
            except Exception:
                pass


def tcp_reachability(
    host,
    port
):
    """
    Lightweight connection-only test.

    Strategy:
        DNS
        -> IPv4 candidates
        -> IPv6 candidates
        -> fastest successful result

    No HTTP request.
    No payload download.
    """

    dns = resolve_host(
        host
    )

    addresses = []

    # IPv4 first for broad Android compatibility.
    addresses.extend(
        dns["ipv4"]
    )

    addresses.extend(
        dns["ipv6"]
    )

    if not addresses:

        return {
            "dns": False,
            "tcp": False,
            "latency": None,
            "ip": None,
            "family": None
        }

    best = None

    for ip in addresses:

        result = tcp_connect_ip(
            ip,
            port,
            TCP_TIMEOUT
        )

        if not result["ok"]:
            continue

        if (
            best is None
            or result["latency"]
            < best["latency"]
        ):
            best = result

    if best is None:

        return {
            "dns": True,
            "tcp": False,
            "latency": None,
            "ip": None,
            "family": None
        }

    return {
        "dns": True,
        "tcp": True,
        "latency": best["latency"],
        "ip": best["ip"],
        "family": (
            "IPv6"
            if ":" in best["ip"]
            else "IPv4"
        )
    }


# ===============================================================
# TEST CACHE
# ===============================================================

def load_cache():
    global _test_cache

    try:

        with open(
            CACHE_PATH,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

        if isinstance(data, dict):

            _test_cache = data

        else:

            _test_cache = {}

    except Exception:

        _test_cache = {}


def save_cache():
    try:

        atomic_write_text(
            CACHE_PATH,
            json.dumps(
                _test_cache,
                ensure_ascii=False,
                indent=2
            )
        )

    except Exception:
        pass


def get_cached_test(
    fingerprint
):
    now = time.time()

    with _cache_lock:

        item = _test_cache.get(
            fingerprint
        )

        if not item:
            return None

        timestamp = safe_int(
            item.get(
                "time"
            ),
            0
        )

        if (
            now - timestamp
            > CACHE_TTL_SECONDS
        ):

            return None

        return item.get(
            "result"
        )


def set_cached_test(
    fingerprint,
    result
):

    with _cache_lock:

        _test_cache[
            fingerprint
        ] = {
            "time": int(
                time.time()
            ),
            "result": result
        }


# ===============================================================
# PROXY TEST
# ===============================================================

def test_proxy(proxy):

    fp = proxy_fingerprint(
        proxy
    )

    cached = get_cached_test(
        fp
    )

    if cached is not None:

        result = dict(
            cached
        )

        result["cached"] = True

        return (
            proxy,
            result
        )

    host = proxy.get(
        "server"
    )

    port = safe_int(
        proxy.get("port")
    )

    result = tcp_reachability(
        host,
        port
    )

    result["cached"] = False

    set_cached_test(
        fp,
        result
    )

    return (
        proxy,
        result
    )


# ===============================================================
# ADAPTIVE WORKERS
# ===============================================================

def choose_workers(
    count
):
    if count <= 50:
        return 8

    if count <= 250:
        return 12

    if count <= 750:
        return 16

    if count <= 1500:
        return 20

    if count <= 3000:
        return 24

    if count <= 5000:
        return 28

    return MAX_WORKERS


# ===============================================================
# SCORING
# ===============================================================

def latency_score(
    latency
):
    if latency is None:
        return 0

    if latency <= 50:
        return 30

    if latency <= 100:
        return 28

    if latency <= 150:
        return 25

    if latency <= 200:
        return 22

    if latency <= 300:
        return 18

    if latency <= 500:
        return 12

    if latency <= 800:
        return 7

    if latency <= 1200:
        return 3

    return 1


def protocol_score(
    proxy
):
    t = (
        proxy.get(
            "type",
            ""
        )
        .lower()
    )

    scores = {

        "vless": 20,
        "vmess": 18,
        "trojan": 20,
        "ss": 17,
        "ssr": 14,
        "hysteria": 20,
        "hysteria2": 20,
        "tuic": 20,
        "wireguard": 20,
        "socks5": 12,
        "http": 10,
    }

    return scores.get(
        t,
        8
    )


def configuration_score(
    proxy
):
    score = 0

    t = proxy.get(
        "type",
        ""
    ).lower()

    if proxy.get(
        "server"
    ):
        score += 3

    if 1 <= safe_int(
        proxy.get("port")
    ) <= 65535:
        score += 3

    if t in (
        "vless",
        "vmess"
    ):
        if proxy.get("uuid"):
            score += 4

    elif t == "trojan":

        if proxy.get("password"):
            score += 4

    elif t == "ss":

        if (
            proxy.get("cipher")
            and proxy.get("password")
        ):
            score += 4

    elif t in (
        "hysteria",
        "hysteria2"
    ):

        if (
            proxy.get("password")
            or proxy.get("auth")
        ):
            score += 4

    elif t == "tuic":

        if (
            proxy.get("uuid")
            and proxy.get("password")
        ):
            score += 4

    else:
        score += 2

    return min(
        score,
        10
    )


def calculate_score(
    proxy,
    test
):
    if not test.get(
        "tcp"
    ):
        return 0

    dns_points = 10

    tcp_points = 30

    latency_points = latency_score(
        test.get("latency")
    )

    protocol_points = protocol_score(
        proxy
    )

    config_points = configuration_score(
        proxy
    )

    total = (
        dns_points
        + tcp_points
        + latency_points
        + protocol_points
        + config_points
    )

    return min(
        total,
        MAX_SCORE
    )


# ===============================================================
# PARSERS
# ===============================================================

def make_base(
    name,
    ptype,
    server,
    port
):

    return {
        "name": unique_name(
            name
        ),
        "type": ptype,
        "server": clean_string(
            server
        ),
        "port": safe_int(
            port
        )
    }


def parse_vless(line):

    try:

        raw = line[
            len("vless://"):
        ]

        fragment = ""

        if "#" in raw:

            raw, fragment = raw.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        if "?" in raw:

            main, query = raw.split(
                "?",
                1
            )

        else:

            main = raw
            query = ""

        if "@" not in main:
            return None

        userinfo, address = main.split(
            "@",
            1
        )

        parsed = urlparse(
            "vless://" + userinfo
            + "@"
            + address
        )

        uid = unquote(
            parsed.username or ""
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        q = query_dict(
            query
        )

        if not (
            uid
            and host
            and port
        ):
            return None

        network = first_value(
            q,
            "type",
            "network",
            default="tcp"
        ).lower()

        security = first_value(
            q,
            "security",
            default=""
        ).lower()

        name = (
            fragment
            or q.get("remark")
            or f"vless-{host}-{tail(uid)}"
        )

        p = make_base(
            name,
            "vless",
            host,
            port
        )

        p["uuid"] = uid

        p["encryption"] = (
            q.get(
                "encryption"
            )
            or "none"
        )

        p["network"] = network
        p["udp"] = True

        if q.get("flow"):
            p["flow"] = q["flow"]

        if security in (
            "tls",
            "reality"
        ):

            p["tls"] = True

            p["servername"] = (
                q.get("sni")
                or q.get("servername")
                or q.get("host")
                or host
            )

        if network == "ws":

            ws = {
                "path": (
                    q.get(
                        "path"
                    )
                    or "/"
                )
            }

            host_header = (
                q.get("host")
                or q.get("Host")
                or ""
            )

            if host_header:

                ws["headers"] = {
                    "Host":
                    host_header
                }

            p["ws-opts"] = ws

        if network == "grpc":

            service = (
                q.get(
                    "serviceName"
                )
                or q.get(
                    "service"
                )
                or ""
            )

            if service:

                p["grpc-opts"] = {
                    "grpc-service-name":
                    service
                }

        if security == "reality":

            p[
                "reality-opts"
            ] = {
                "public-key":
                    q.get(
                        "pbk",
                        ""
                    ),
                "short-id":
                    q.get(
                        "sid",
                        ""
                    )
            }

        p["_unknown_params"] = (
            collect_unknown_query_params(
                "vless",
                q
            )
        )

        return p

    except Exception:

        return None


def parse_vmess(line):

    try:

        raw = line[
            len("vmess://"):
        ].strip()

        decoded = b64decode_text(
            raw
        )

        if not decoded:
            return None

        data = json.loads(
            decoded
        )

        host = (
            data.get("add")
            or data.get("address")
            or data.get("server")
            or ""
        )

        port = safe_int(
            data.get("port"),
            0
        )

        uid = (
            data.get("id")
            or data.get("uuid")
            or ""
        )

        if not (
            host
            and port
            and uid
        ):
            return None

        name = (
            data.get("ps")
            or f"vmess-{host}-{tail(uid)}"
        )

        p = make_base(
            name,
            "vmess",
            host,
            port
        )

        p["uuid"] = uid

        p["alterId"] = safe_int(
            data.get(
                "aid",
                data.get(
                    "alterId",
                    0
                )
            )
        )

        p["cipher"] = (
            data.get("scy")
            or data.get("cipher")
            or "auto"
        )

        p["network"] = (
            data.get("net")
            or "tcp"
        ).lower()

        p["udp"] = True

        tls_value = str(
            data.get(
                "tls",
                ""
            )
        ).lower()

        if tls_value in (
            "tls",
            "true"
        ):

            p["tls"] = True

            p["servername"] = (
                data.get("sni")
                or data.get("host")
                or host
            )

        if p["network"] == "ws":

            ws = {
                "path":
                    data.get(
                        "path"
                    )
                    or "/"
            }

            host_header = (
                data.get("host")
                or ""
            )

            if host_header:

                ws["headers"] = {
                    "Host":
                    host_header
                }

            p["ws-opts"] = ws

        if p["network"] == "grpc":

            service = (
                data.get(
                    "serviceName"
                )
                or ""
            )

            if service:

                p["grpc-opts"] = {
                    "grpc-service-name":
                    service
                }

        return p

    except Exception:

        return None


def parse_trojan(line):

    try:

        parsed = urlparse(
            line
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        password = (
            unquote(
                parsed.username
                or ""
            )
        )

        if not (
            host
            and password
        ):
            return None

        q = parse_qs(
            parsed.query,
            keep_blank_values=True
        )

        q2 = {
            k: (
                v[0]
                if v
                else ""
            )
            for k, v in q.items()
        }

        name = (
            unquote(
                parsed.fragment
                or ""
            )
            or f"trojan-{host}"
        )

        p = make_base(
            name,
            "trojan",
            host,
            port
        )

        p["password"] = password
        p["network"] = (
            q2.get(
                "type"
            )
            or "tcp"
        )

        p["udp"] = True

        if q2.get("sni"):
            p["sni"] = q2["sni"]

        if p["network"] == "ws":

            p["ws-opts"] = {
                "path":
                    q2.get(
                        "path",
                        "/"
                    ),
            }

            if q2.get("host"):

                p[
                    "ws-opts"
                ][
                    "headers"
                ] = {
                    "Host":
                    q2["host"]
                }

        p["_unknown_params"] = (
            collect_unknown_query_params(
                "trojan",
                q2
            )
        )

        return p

    except Exception:

        return None


def parse_ss(line):

    try:

        raw = line[
            len("ss://"):
        ]

        fragment = ""

        if "#" in raw:

            raw, fragment = raw.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        # SIP002:
        # method:password@host:port
        if "@" in raw:

            userinfo, address = raw.rsplit(
                "@",
                1
            )

            decoded_user = b64decode_text(
                userinfo
            )

            if (
                decoded_user
                and ":"
                in decoded_user
            ):

                method, password = (
                    decoded_user.split(
                        ":",
                        1
                    )
                )

            elif ":" in userinfo:

                method, password = (
                    userinfo.split(
                        ":",
                        1
                    )
                )

            else:

                return None

        else:

            decoded = b64decode_text(
                raw
            )

            if "@" not in decoded:
                return None

            userinfo, address = (
                decoded.rsplit(
                    "@",
                    1
                )
            )

            if ":" not in userinfo:
                return None

            method, password = (
                userinfo.split(
                    ":",
                    1
                )
            )

        # IPv6-safe endpoint parsing
        if address.startswith("["):

            end = address.find("]")

            if end < 0:
                return None

            host = address[
                1:end
            ]

            remain = address[
                end + 1:
            ]

            if remain.startswith(":"):
                port = safe_int(
                    remain[1:]
                )
            else:
                port = 8388

        else:

            host, port_text = address.rsplit(
                ":",
                1
            )

            port = safe_int(
                port_text
            )

        if not (
            method
            and password
            and host
            and 1 <= port <= 65535
        ):
            return None

        name = (
            fragment
            or f"ss-{host}-{port}"
        )

        p = make_base(
            name,
            "ss",
            host,
            port
        )

        p["cipher"] = method
        p["password"] = password
        p["udp"] = True

        return p

    except Exception:

        return None


def parse_ssr(line):

    try:

        raw = line[
            len("ssr://"):
        ]

        decoded = b64decode_text(
            raw
        )

        if not decoded:
            return None

        main, sep, query = (
            decoded.partition(
                "/?"
            )
        )

        parts = main.split(
            ":",
            5
        )

        if len(parts) != 6:
            return None

        server = parts[0]
        port = safe_int(
            parts[1]
        )

        protocol = parts[2]
        method = parts[3]
        obfs = parts[4]

        password = b64decode_text(
            parts[5]
        )

        if not (
            server
            and 1 <= port <= 65535
            and password
        ):
            return None

        q = {}

        if sep and query:

            params = parse_qs(
                query,
                keep_blank_values=True
            )

            for key, values in params.items():

                value = (
                    values[0]
                    if values
                    else ""
                )

                decoded_value = (
                    b64decode_text(
                        value
                    )
                )

                q[key] = (
                    decoded_value
                    if decoded_value
                    else value
                )

        name = (
            q.get("remarks")
            or f"ssr-{server}-{port}"
        )

        p = make_base(
            name,
            "ssr",
            server,
            port
        )

        p["cipher"] = method
        p["password"] = password
        p["protocol"] = protocol
        p["obfs"] = obfs
        p["udp"] = True

        if q.get(
            "obfsparam"
        ):
            p["obfs-param"] = q[
                "obfsparam"
            ]

        if q.get(
            "protoparam"
        ):
            p["protocol-param"] = q[
                "protoparam"
            ]

        return p

    except Exception:

        return None


def parse_hysteria(line):

    try:

        raw = line[
            len("hy://"):
        ]

        if "?" in raw:

            main, query = raw.split(
                "?",
                1
            )

        else:

            main = raw
            query = ""

        fragment = ""

        if "#" in main:

            main, fragment = (
                main.split(
                    "#",
                    1
                )
            )

            fragment = unquote(
                fragment
            )

        if "@" in main:

            auth, address = main.split(
                "@",
                1
            )

        else:

            auth = ""
            address = main

        parsed = urlparse(
            "dummy://"
            + address
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        if not host:
            return None

        q = query_dict(
            query
        )

        name = (
            fragment
            or f"hysteria-{host}"
        )

        p = make_base(
            name,
            "hysteria",
            host,
            port
        )

        if auth:
            p["auth"] = unquote(
                auth
            )

        if q.get("sni"):
            p["sni"] = q["sni"]

        if q.get("alpn"):
            p["alpn"] = [
                x.strip()
                for x in q["alpn"].split(",")
                if x.strip()
            ]

        if q.get("obfs"):
            p["obfs"] = q["obfs"]

        if q.get("protocol"):
            p["protocol"] = q[
                "protocol"
            ]

        p["udp"] = True

        p["_unknown_params"] = (
            collect_unknown_query_params(
                "hysteria",
                q
            )
        )

        return p

    except Exception:

        return None


def parse_hysteria2(line):

    try:

        if line.startswith(
            "hysteria2://"
        ):

            raw = line[
                len("hysteria2://"):
            ]

        else:

            raw = line[
                len("hy2://"):
            ]

        fragment = ""

        if "#" in raw:

            raw, fragment = raw.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        if "?" in raw:

            main, query = raw.split(
                "?",
                1
            )

        else:

            main = raw
            query = ""

        if "@" in main:

            auth, address = main.split(
                "@",
                1
            )

        else:

            auth = ""
            address = main

        parsed = urlparse(
            "dummy://"
            + address
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        if not host:
            return None

        p = make_base(
            fragment
            or f"hysteria2-{host}",
            "hysteria2",
            host,
            port
        )

        p["password"] = unquote(
            auth
        )

        q = query_dict(
            query
        )

        if q.get("sni"):
            p["sni"] = q["sni"]

        if q.get("alpn"):
            p["alpn"] = [
                x.strip()
                for x in q["alpn"].split(",")
                if x.strip()
            ]

        if q.get("obfs"):
            p["obfs"] = q["obfs"]

        if q.get(
            "obfs-password"
        ):
            p[
                "obfs-password"
            ] = q[
                "obfs-password"
            ]

        p["udp"] = True

        p["_unknown_params"] = (
            collect_unknown_query_params(
                "hysteria2",
                q
            )
        )

        return p

    except Exception:

        return None


def parse_tuic(line):

    try:

        raw = line[
            len("tuic://"):
        ]

        fragment = ""

        if "#" in raw:

            raw, fragment = raw.split(
                "#",
                1
            )

            fragment = unquote(
                fragment
            )

        if "?" in raw:

            main, query = raw.split(
                "?",
                1
            )

        else:

            main = raw
            query = ""

        if "@" not in main:
            return None

        credentials, address = (
            main.split(
                "@",
                1
            )
        )

        if ":" not in credentials:
            return None

        uuid, password = (
            credentials.split(
                ":",
                1
            )
        )

        parsed = urlparse(
            "dummy://"
            + address
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 443
        )

        if not (
            uuid
            and password
            and host
        ):
            return None

        q = query_dict(
            query
        )

        p = make_base(
            fragment
            or f"tuic-{host}",
            "tuic",
            host,
            port
        )

        p["uuid"] = unquote(
            uuid
        )

        p["password"] = unquote(
            password
        )

        p["congestion-controller"] = (
            q.get(
                "congestion_control"
            )
            or q.get(
                "congestion"
            )
            or "bbr"
        )

        if q.get("sni"):
            p["sni"] = q["sni"]

        if q.get("alpn"):
            p["alpn"] = [
                x.strip()
                for x in q["alpn"].split(",")
                if x.strip()
            ]

        if (
            q.get("zero_rtt")
            or q.get("zerortt")
        ):
            p["zeroRTT"] = True

        p["udp"] = True

        p["_unknown_params"] = (
            collect_unknown_query_params(
                "tuic",
                q
            )
        )

        return p

    except Exception:

        return None


def parse_http(line):

    try:

        parsed = urlparse(
            line
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 80
        )

        if not host:
            return None

        p = make_base(
            unquote(
                parsed.fragment
                or ""
            )
            or f"http-{host}",
            "http",
            host,
            port
        )

        if parsed.username:
            p["username"] = unquote(
                parsed.username
            )

        if parsed.password:
            p["password"] = unquote(
                parsed.password
            )

        p["udp"] = False

        return p

    except Exception:

        return None


def parse_socks(line):

    try:

        parsed = urlparse(
            line
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 1080
        )

        if not host:
            return None

        p = make_base(
            unquote(
                parsed.fragment
                or ""
            )
            or f"socks5-{host}",
            "socks5",
            host,
            port
        )

        if parsed.username:
            p["username"] = unquote(
                parsed.username
            )

        if parsed.password:
            p["password"] = unquote(
                parsed.password
            )

        p["udp"] = True

        return p

    except Exception:

        return None


def parse_wireguard(line):

    try:

        if line.startswith(
            "wg://"
        ):

            parsed = urlparse(
                line
            )

            host = (
                parsed.hostname
                or ""
            )

            port = (
                parsed.port
                or 51820
            )

            q = parse_qs(
                parsed.query
            )

            public_key = (
                parsed.username
                or ""
            )

            p = make_base(
                unquote(
                    parsed.fragment
                    or ""
                )
                or f"wg-{host}",
                "wireguard",
                host,
                port
            )

            if public_key:
                p[
                    "public_key"
                ] = unquote(
                    public_key
                )

            if q.get(
                "privateKey"
            ):
                p[
                    "private_key"
                ] = q[
                    "privateKey"
                ][0]

            if q.get(
                "address"
            ):
                p["address"] = q[
                    "address"
                ][0]

            if q.get("mtu"):
                p["mtu"] = safe_int(
                    q["mtu"][0],
                    1280
                )

            p["udp"] = True

            return p

        # WireGuard config block
        if (
            "[Interface]"
            not in line
            or "[Peer]"
            not in line
        ):
            return None

        endpoint = re.search(
            r"(?im)^\s*Endpoint\s*=\s*([^\s]+)"
            ,
            line
        )

        public = re.search(
            r"(?im)^\s*PublicKey\s*=\s*([A-Za-z0-9+/=]+)"
            ,
            line
        )

        if not endpoint:
            return None

        endpoint_value = (
            endpoint.group(1)
        )

        parsed = urlparse(
            "dummy://"
            + endpoint_value
        )

        host = (
            parsed.hostname
            or ""
        )

        port = (
            parsed.port
            or 51820
        )

        if not host:
            return None

        p = make_base(
            f"wg-{host}",
            "wireguard",
            host,
            port
        )

        if public:
            p[
                "public_key"
            ] = public.group(1)

        private = re.search(
            r"(?im)^\s*PrivateKey\s*=\s*([A-Za-z0-9+/=]+)",
            line
        )

        if private:
            p[
                "private_key"
            ] = private.group(1)

        address = re.search(
            r"(?im)^\s*Address\s*=\s*([^\r\n]+)",
            line
        )

        if address:
            p[
                "address"
            ] = address.group(1).strip()

        p["udp"] = True

        return p

    except Exception:

        return None


# ===============================================================
# JSON / YAML PARSERS
# ===============================================================

def parse_json_node(
    obj
):
    result = []

    if not isinstance(
        obj,
        dict
    ):
        return result

    outbounds = (
        obj.get("outbounds")
        or obj.get("proxies")
        or obj.get("proxy")
        or []
    )

    if isinstance(
        outbounds,
        dict
    ):
        outbounds = [
            outbounds
        ]

    if not isinstance(
        outbounds,
        list
    ):
        return result

    for item in outbounds:

        if not isinstance(
            item,
            dict
        ):
            continue

        proto = (
            item.get(
                "protocol"
            )
            or item.get(
                "type"
            )
            or ""
        ).lower()

        # VLESS / VMESS
        if proto in (
            "vless",
            "vmess"
        ):

            settings = (
                item.get(
                    "settings"
                )
                or {}
            )

            stream = (
                item.get(
                    "streamSettings"
                )
                or {}
            )

            servers = (
                settings.get(
                    "vnext"
                )
                or settings.get(
                    "servers"
                )
                or []
            )

            if not servers:
                continue

            first = servers[0]

            users = (
                first.get(
                    "users"
                )
                or [{}]
            )

            user = (
                users[0]
                if users
                else {}
            )

            server = (
                first.get(
                    "address"
                )
                or first.get(
                    "server"
                )
                or item.get(
                    "address"
                )
                or ""
            )

            port = safe_int(
                first.get(
                    "port"
                )
                or item.get(
                    "port"
                )
                or 0
            )

            uid = (
                user.get("id")
                or user.get("uuid")
                or ""
            )

            if not (
                server
                and port
            ):
                continue

            name = (
                item.get("tag")
                or f"{proto}-{server}"
            )

            p = make_base(
                name,
                proto,
                server,
                port
            )

            if uid:
                p["uuid"] = uid

            p["network"] = (
                stream.get(
                    "network"
                )
                or "tcp"
            )

            p["udp"] = True

            if proto == "vless":

                p[
                    "encryption"
                ] = "none"

                if user.get(
                    "flow"
                ):
                    p["flow"] = user[
                        "flow"
                    ]

            else:

                p[
                    "alterId"
                ] = safe_int(
                    user.get(
                        "alterId",
                        user.get(
                            "aid",
                            0
                        )
                    )
                )

                p[
                    "cipher"
                ] = (
                    user.get(
                        "cipher"
                    )
                    or user.get(
                        "security"
                    )
                    or "auto"
                )

            security = (
                stream.get(
                    "security"
                )
                or ""
            ).lower()

            if security in (
                "tls",
                "reality"
            ):

                p["tls"] = True

                tls_settings = (
                    stream.get(
                        "tlsSettings"
                    )
                    or {}
                )

                p[
                    "servername"
                ] = (
                    tls_settings.get(
                        "serverName"
                    )
                    or server
                )

            if p["network"] == "ws":

                ws = (
                    stream.get(
                        "wsSettings"
                    )
                    or {}
                )

                p[
                    "ws-opts"
                ] = {
                    "path":
                        ws.get(
                            "path",
                            "/"
                        )
                }

                headers = ws.get(
                    "headers"
                )

                if headers:
                    p[
                        "ws-opts"
                    ][
                        "headers"
                    ] = headers

            if p["network"] == "grpc":

                grpc = (
                    stream.get(
                        "grpcSettings"
                    )
                    or {}
                )

                service = (
                    grpc.get(
                        "serviceName"
                    )
                    or ""
                )

                if service:

                    p[
                        "grpc-opts"
                    ] = {
                        "grpc-service-name":
                            service
                    }

            result.append(
                p
            )

        # Trojan
        elif proto == "trojan":

            settings = (
                item.get(
                    "settings"
                )
                or {}
            )

            servers = (
                settings.get(
                    "servers"
                )
                or []
            )

            if not servers:
                continue

            s = servers[0]

            server = (
                s.get(
                    "address"
                )
                or s.get(
                    "server"
                )
                or ""
            )

            port = safe_int(
                s.get(
                    "port"
                )
                or 443
            )

            password = (
                s.get(
                    "password"
                )
                or ""
            )

            if not (
                server
                and password
            ):
                continue

            p = make_base(
                item.get(
                    "tag"
                )
                or f"trojan-{server}",
                "trojan",
                server,
                port
            )

            p[
                "password"
            ] = password

            stream = (
                item.get(
                    "streamSettings"
                )
                or {}
            )

            tls = (
                stream.get(
                    "tlsSettings"
                )
                or {}
            )

            if tls.get(
                "serverName"
            ):
                p[
                    "sni"
                ] = tls[
                    "serverName"
                ]

            p["udp"] = True

            result.append(
                p
            )

        # Shadowsocks
        elif proto in (
            "shadowsocks",
            "ss"
        ):

            settings = (
                item.get(
                    "settings"
                )
                or {}
            )

            servers = (
                settings.get(
                    "servers"
                )
                or []
            )

            if not servers:
                continue

            s = servers[0]

            server = (
                s.get(
                    "address"
                )
                or s.get(
                    "server"
                )
                or ""
            )

            port = safe_int(
                s.get(
                    "port"
                )
                or 0
            )

            cipher = (
                s.get(
                    "method"
                )
                or s.get(
                    "cipher"
                )
                or ""
            )

            password = (
                s.get(
                    "password"
                )
                or s.get(
                    "passwd"
                )
                or ""
            )

            if not (
                server
                and port
                and cipher
                and password
            ):
                continue

            p = make_base(
                item.get(
                    "tag"
                )
                or f"ss-{server}",
                "ss",
                server,
                port
            )

            p["cipher"] = cipher
            p["password"] = password
            p["udp"] = True

            result.append(
                p
            )

    return result


def parse_yaml_nodes(
    text
):
    result = []

    try:

        documents = yaml.safe_load_all(
            text
        )

        for doc in documents:

            if not isinstance(
                doc,
                dict
            ):
                continue

            proxies = (
                doc.get(
                    "proxies"
                )
                or doc.get(
                    "proxy"
                )
                or []
            )

            if isinstance(
                proxies,
                dict
            ):
                proxies = [
                    proxies
                ]

            if not isinstance(
                proxies,
                list
            ):
                continue

            for proxy in proxies:

                if not isinstance(
                    proxy,
                    dict
                ):
                    continue

                if not (
                    proxy.get(
                        "type"
                    )
                    and proxy.get(
                        "server"
                    )
                ):
                    continue

                copied = dict(
                    proxy
                )

                result.append(
                    copied
                )

    except Exception:
        pass

    return result


# ===============================================================
# JSON FRAGMENT EXTRACTION
# ===============================================================

def extract_json_objects(
    text
):
    objects = []

    depth = 0
    start = None
    in_string = False
    escape = False

    for index, char in enumerate(
        text
    ):

        if char == '"' and not escape:
            in_string = not in_string

        if in_string:
            escape = (
                char == "\\"
                and not escape
            )
            continue

        escape = False

        if char == "{":

            if depth == 0:
                start = index

            depth += 1

        elif char == "}":

            if depth > 0:

                depth -= 1

                if (
                    depth == 0
                    and start is not None
                ):

                    objects.append(
                        text[
                            start:index + 1
                        ]
                    )

                    start = None

    return objects


# ===============================================================
# SINGLE LINE ROUTER
# ===============================================================

def parse_line(
    line
):
    line = line.strip()

    if not line:
        return []

    lower = line.lower()

    parser_map = [

        ("vless://", parse_vless),

        ("vmess://", parse_vmess),

        ("trojan://", parse_trojan),

        ("ss://", parse_ss),

        ("ssr://", parse_ssr),

        ("hy://", parse_hysteria),

        ("hysteria2://", parse_hysteria2),

        ("hy2://", parse_hysteria2),

        ("tuic://", parse_tuic),

        ("wg://", parse_wireguard),

        ("http://", parse_http),

        ("https://", parse_http),

        ("socks://", parse_socks),

        ("socks5://", parse_socks),

    ]

    for prefix, parser in parser_map:

        if lower.startswith(
            prefix
        ):

            p = parser(
                line
            )

            return (
                [p]
                if p
                else []
            )

    # WireGuard block
    if (
        "[Interface]"
        in line
        and "[Peer]"
        in line
    ):

        p = parse_wireguard(
            line
        )

        return (
            [p]
            if p
            else []
        )

    # JSON
    if (
        line.startswith("{")
        and line.endswith("}")
    ):

        try:

            return parse_json_node(
                json.loads(
                    line
                )
            )

        except Exception:
            return []

    # Base64 subscription
    if is_probably_base64(
        line
    ):

        decoded = b64decode_text(
            line
        )

        return parse_any(
            decoded,
            allow_base64=False
        )

    return []


# ===============================================================
# WHOLE INPUT PARSER
# ===============================================================

def parse_any(
    text,
    allow_base64=True
):
    result = []

    if not text or not text.strip():
        return result

    # YAML / Clash
    result.extend(
        parse_yaml_nodes(
            text
        )
    )

    # JSON fragments
    for fragment in extract_json_objects(
        text
    ):

        try:

            obj = json.loads(
                fragment
            )

            result.extend(
                parse_json_node(
                    obj
                )
            )

        except Exception:
            pass

    # individual lines
    for line in text.splitlines():

        line = line.strip()

        if not line:
            continue

        # avoid duplicate YAML object lines
        parsed = parse_line(
            line
        )

        result.extend(
            parsed
        )

    return result


# ===============================================================
# NORMALIZATION
# ===============================================================

def normalize_proxy(
    proxy
):

    if not isinstance(
        proxy,
        dict
    ):
        return None

    p = dict(
        proxy
    )

    ptype = clean_string(
        p.get("type")
    ).lower()

    server = clean_string(
        p.get("server")
    )

    port = safe_int(
        p.get("port")
    )

    if not ptype:
        return None

    if not server:
        return None

    if not (
        1 <= port <= 65535
    ):
        return None

    p["type"] = ptype
    p["server"] = server
    p["port"] = port

    if not p.get("name"):
        p["name"] = stable_name(
            p
        )

    return p


# ===============================================================
# VALIDATION
# ===============================================================

SUPPORTED_TYPES = {
    "vless",
    "vmess",
    "trojan",
    "ss",
    "ssr",
    "hysteria",
    "hysteria2",
    "tuic",
    "wireguard",
    "http",
    "socks5",
}


def validate_proxy(
    proxy
):

    if not isinstance(
        proxy,
        dict
    ):
        return False

    ptype = (
        clean_string(
            proxy.get("type")
        ).lower()
    )

    if ptype not in SUPPORTED_TYPES:
        return False

    if not proxy.get(
        "server"
    ):
        return False

    port = safe_int(
        proxy.get("port")
    )

    if not (
        1 <= port <= 65535
    ):
        return False

    if ptype in (
        "vless",
        "vmess"
    ):

        if not proxy.get(
            "uuid"
        ):
            return False

    elif ptype == "trojan":

        if not proxy.get(
            "password"
        ):
            return False

    elif ptype == "ss":

        if not (
            proxy.get(
                "cipher"
            )
            and proxy.get(
                "password"
            )
        ):
            return False

    elif ptype == "ssr":

        if not (
            proxy.get(
                "cipher"
            )
            and proxy.get(
                "password"
            )
        ):
            return False

    elif ptype == "tuic":

        if not (
            proxy.get(
                "uuid"
            )
            and proxy.get(
                "password"
            )
        ):
            return False

    elif ptype == "hysteria2":

        if not proxy.get(
            "password"
        ):
            return False

    return True


# ===============================================================
# DEDUPLICATION
# ===============================================================

def deduplicate(
    proxies
):

    unique = []
    seen = set()
    duplicate_count = 0

    for proxy in proxies:

        fp = proxy_fingerprint(
            proxy
        )

        if fp in seen:

            duplicate_count += 1
            continue

        seen.add(fp)
        unique.append(
            proxy
        )

    return (
        unique,
        duplicate_count
    )


# ===============================================================
# CLASH/Mihomo NORMALIZER
# ===============================================================

def mihomo_entry(
    proxy
):

    p = proxy

    t = p[
        "type"
    ].lower()

    base = {
        "name":
            p["name"],
        "type":
            t,
        "server":
            p["server"],
        "port":
            safe_int(
                p["port"]
            )
    }

    # ---------------- VLESS ----------------

    if t == "vless":

        base["uuid"] = p[
            "uuid"
        ]

        base["encryption"] = (
            p.get(
                "encryption"
            )
            or "none"
        )

        for key in (
            "flow",
            "network",
            "tls",
            "servername",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

        if p.get(
            "ws-opts"
        ):
            base[
                "ws-opts"
            ] = p[
                "ws-opts"
            ]

        if p.get(
            "grpc-opts"
        ):
            base[
                "grpc-opts"
            ] = p[
                "grpc-opts"
            ]

        if p.get(
            "reality-opts"
        ):
            base[
                "reality-opts"
            ] = p[
                "reality-opts"
            ]

    # ---------------- VMESS ----------------

    elif t == "vmess":

        base["uuid"] = p[
            "uuid"
        ]

        base["alterId"] = safe_int(
            p.get(
                "alterId",
                0
            )
        )

        base["cipher"] = (
            p.get(
                "cipher"
            )
            or "auto"
        )

        for key in (
            "network",
            "tls",
            "servername",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

        if p.get(
            "ws-opts"
        ):
            base[
                "ws-opts"
            ] = p[
                "ws-opts"
            ]

        if p.get(
            "grpc-opts"
        ):
            base[
                "grpc-opts"
            ] = p[
                "grpc-opts"
            ]

    # ---------------- TROJAN ----------------

    elif t == "trojan":

        base[
            "password"
        ] = p[
            "password"
        ]

        base[
            "udp"
        ] = p.get(
            "udp",
            True
        )

        if p.get(
            "network"
        ):
            base[
                "network"
            ] = p[
                "network"
            ]

        if p.get(
            "sni"
        ):
            base[
                "sni"
            ] = p[
                "sni"
            ]

        if p.get(
            "ws-opts"
        ):
            base[
                "ws-opts"
            ] = p[
                "ws-opts"
            ]

    # ---------------- SS ----------------

    elif t == "ss":

        base[
            "cipher"
        ] = p[
            "cipher"
        ]

        base[
            "password"
        ] = p[
            "password"
        ]

        base[
            "udp"
        ] = p.get(
            "udp",
            True
        )

    # ---------------- SSR ----------------

    elif t == "ssr":

        for key in (
            "cipher",
            "password",
            "protocol",
            "obfs",
            "obfs-param",
            "protocol-param",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

    # ---------------- HYSTERIA ----------------

    elif t == "hysteria":

        for key in (
            "auth",
            "password",
            "protocol",
            "obfs",
            "sni",
            "alpn",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

    # ---------------- HYSTERIA2 ----------------

    elif t == "hysteria2":

        base[
            "password"
        ] = p[
            "password"
        ]

        for key in (
            "sni",
            "alpn",
            "obfs",
            "obfs-password",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

    # ---------------- TUIC ----------------

    elif t == "tuic":

        base[
            "uuid"
        ] = p[
            "uuid"
        ]

        base[
            "password"
        ] = p[
            "password"
        ]

        for key in (
            "congestion-controller",
            "alpn",
            "sni",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

        if p.get(
            "zeroRTT"
        ):
            base[
                "zeroRTT"
            ] = True

    # ---------------- WIREGUARD ----------------

    elif t == "wireguard":

        for key in (
            "private_key",
            "public_key",
            "address",
            "mtu",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

    # ---------------- HTTP ----------------

    elif t == "http":

        for key in (
            "username",
            "password",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

    # ---------------- SOCKS5 ----------------

    elif t == "socks5":

        for key in (
            "username",
            "password",
            "udp",
        ):

            if key in p:
                base[key] = p[key]

    return base


# ===============================================================
# FINAL ENTRY VALIDATOR
# ===============================================================

def validate_mihomo_entry(
    entry
):

    if not isinstance(
        entry,
        dict
    ):
        return False

    if not entry.get(
        "name"
    ):
        return False

    if not entry.get(
        "type"
    ):
        return False

    if not entry.get(
        "server"
    ):
        return False

    if not (
        1 <= safe_int(
            entry.get("port")
        ) <= 65535
    ):
        return False

    return True


# ===============================================================
# FINAL YAML VALIDATOR
# ===============================================================

def validate_final_config(
    config
):

    if not isinstance(
        config,
        dict
    ):
        return False, "root"

    proxies = config.get(
        "proxies"
    )

    groups = config.get(
        "proxy-groups"
    )

    rules = config.get(
        "rules"
    )

    if not isinstance(
        proxies,
        list
    ):
        return False, "proxies"

    if not isinstance(
        groups,
        list
    ):
        return False, "proxy-groups"

    if len(groups) != 1:
        return False, "group-count"

    if not isinstance(
        rules,
        list
    ):
        return False, "rules"

    names = set()

    for proxy in proxies:

        if not validate_mihomo_entry(
            proxy
        ):
            return False, "proxy-entry"

        name = proxy[
            "name"
        ]

        if name in names:
            return False, "duplicate-name"

        names.add(
            name
        )

    group = groups[0]

    if group.get(
        "name"
    ) != GROUP_NAME:
        return False, "group-name"

    if group.get(
        "type"
    ) != "select":
        return False, "group-type"

    members = group.get(
        "proxies"
    )

    if not isinstance(
        members,
        list
    ):
        return False, "group-members"

    for member in members:

        if member in (
            "DIRECT",
        ):
            continue

        if member not in names:
            return False, (
                "missing-member:"
                + str(member)
            )

    return True, "OK"


# ===============================================================
# REPORT HELPERS
# ===============================================================

def write_report(
    path,
    lines
):

    try:

        atomic_write_text(
            path,
            "\n".join(
                lines
            )
            + "\n"
        )

    except Exception as e:

        print(
            f"[WARN] Report write failed: {e}"
        )


# ===============================================================
# TESTING ENGINE
# ===============================================================

def run_tests(
    proxies
):

    total = len(
        proxies
    )

    workers = choose_workers(
        total
    )

    print()
    print(
        f"[TEST] Candidates : {total}"
    )

    print(
        f"[TEST] Workers    : {workers}"
    )

    print(
        f"[TEST] Batch size : {BATCH_SIZE}"
    )

    print(
        "[TEST] Method     : DNS + TCP only"
    )

    print(
        "[TEST] HTTP       : OFF"
    )

    print(
        "[TEST] Download   : OFF"
    )

    print()

    alive = []
    test_records = []

    for start in range(
        0,
        total,
        BATCH_SIZE
    ):

        batch = proxies[
            start:
            start + BATCH_SIZE
        ]

        batch_alive = []

        with ThreadPoolExecutor(
            max_workers=min(
                workers,
                len(batch)
            )
        ) as executor:

            futures = [
                executor.submit(
                    test_proxy,
                    proxy
                )
                for proxy in batch
            ]

            for future in as_completed(
                futures
            ):

                try:

                    proxy, result = (
                        future.result()
                    )

                    score = calculate_score(
                        proxy,
                        result
                    )

                    record = {
                        "fingerprint":
                            proxy_fingerprint(
                                proxy
                            ),
                        "name":
                            proxy.get(
                                "name"
                            ),
                        "type":
                            proxy.get(
                                "type"
                            ),
                        "server":
                            proxy.get(
                                "server"
                            ),
                        "port":
                            proxy.get(
                                "port"
                            ),
                        "dns":
                            result.get(
                                "dns"
                            ),
                        "tcp":
                            result.get(
                                "tcp"
                            ),
                        "latency":
                            result.get(
                                "latency"
                            ),
                        "ip":
                            result.get(
                                "ip"
                            ),
                        "family":
                            result.get(
                                "family"
                            ),
                        "cached":
                            result.get(
                                "cached"
                            ),
                        "score":
                            score
                    }

                    test_records.append(
                        record
                    )

                    proxy[
                        "_test"
                    ] = result

                    proxy[
                        "_score"
                    ] = score

                    if result.get(
                        "tcp"
                    ):

                        batch_alive.append(
                            proxy
                        )

                except Exception:
                    pass

        alive.extend(
            batch_alive
        )

        processed = min(
            start + len(batch),
            total
        )

        print(
            f"[TEST] {processed}/{total} "
            f"| reachable={len(alive)}"
        )

    return (
        alive,
        test_records
    )


# ===============================================================
# REPORT BUILDING
# ===============================================================

def make_reports(
    parsed,
    unique,
    alive,
    records,
    duplicate_count,
    output_dir
):

    report_path = os.path.join(
        output_dir,
        "output_report.txt"
    )

    failed_path = os.path.join(
        output_dir,
        "output_failed.txt"
    )

    duplicate_path = os.path.join(
        output_dir,
        "output_duplicates.txt"
    )

    unknown_path = os.path.join(
        output_dir,
        "output_unknown_params.txt"
    )

    counters = Counter()

    for r in records:

        if r["dns"]:
            counters[
                "DNS_OK"
            ] += 1
        else:
            counters[
                "DNS_FAIL"
            ] += 1

        if r["tcp"]:
            counters[
                "TCP_OK"
            ] += 1
        else:
            counters[
                "TCP_FAIL"
            ] += 1

        if r["cached"]:
            counters[
                "CACHE_HIT"
            ] += 1

    report = [

        "=" * 70,

        VERSION,

        "=" * 70,

        f"Input parsed              : {len(parsed)}",
        f"Unique after dedupe       : {len(unique)}",
        f"Duplicates removed        : {duplicate_count}",
        f"TCP reachable             : {len(alive)}",
        f"TCP unreachable           : {len(unique)-len(alive)}",

        "",

        f"DNS OK                    : {counters['DNS_OK']}",
        f"DNS FAIL                  : {counters['DNS_FAIL']}",
        f"TCP OK                    : {counters['TCP_OK']}",
        f"TCP FAIL                  : {counters['TCP_FAIL']}",
        f"Cache hits                : {counters['CACHE_HIT']}",

        "",

        f"DNS cache TTL             : {DNS_CACHE_TTL_SECONDS}s",
        f"TCP result cache TTL      : {CACHE_TTL_SECONDS}s",

        "",

        "HTTP test                 : OFF",
        "Download test             : OFF",
        "Post-output ping          : OFF",
        "URL-Test                  : OFF",
        "Fallback                  : OFF",
        "Load-balance              : OFF",
        "Automatic switching       : OFF",

        "",

        f"Final group               : {GROUP_NAME}",
        "Group type                : select",

        "=" * 70,
    ]

    write_report(
        report_path,
        report
    )

    # Failed
    failed_lines = [
        "FAILED / UNREACHABLE",
        "=" * 70
    ]

    for r in records:

        if not r["tcp"]:

            failed_lines.append(
                json.dumps(
                    r,
                    ensure_ascii=False
                )
            )

    write_report(
        failed_path,
        failed_lines
    )

    # Duplicates
    duplicate_lines = [
        "DUPLICATE SUMMARY",
        "=" * 70,
        f"Removed: {duplicate_count}",
    ]

    write_report(
        duplicate_path,
        duplicate_lines
    )

    # Unknown parameters
    unknown_lines = [
        "UNKNOWN PARAMETER REPORT",
        "=" * 70
    ]

    found_unknown = False

    for proxy in unique:

        unknown = proxy.get(
            "_unknown_params",
            []
        )

        if unknown:

            found_unknown = True

            unknown_lines.append(
                f"{proxy.get('name')} | "
                f"{proxy.get('type')} | "
                f"{', '.join(unknown)}"
            )

    if not found_unknown:

        unknown_lines.append(
            "No unknown URL parameters detected."
        )

    write_report(
        unknown_path,
        unknown_lines
    )


# ===============================================================
# OUTPUT CLEANING
# ===============================================================

def remove_internal_fields(
    proxy
):

    p = {}

    for key, value in proxy.items():

        if key.startswith(
            "_"
        ):
            continue

        p[key] = value

    return p


# ===============================================================
# BUILD FINAL CONFIG
# ===============================================================

def build_config(
    alive
):

    # Sort:
    # highest score first
    # then lowest latency
    # then name

    alive = sorted(
        alive,
        key=lambda p: (
            -safe_int(
                p.get(
                    "_score",
                    0
                )
            ),
            (
                p.get(
                    "_test",
                    {}
                ).get(
                    "latency"
                )
                if p.get(
                    "_test",
                    {}
                ).get(
                    "latency"
                ) is not None
                else 999999
            ),
            p.get(
                "name",
                ""
            )
        )
    )

    final_entries = []

    for proxy in alive:

        clean = remove_internal_fields(
            proxy
        )

        entry = mihomo_entry(
            clean
        )

        if validate_mihomo_entry(
            entry
        ):
            final_entries.append(
                entry
            )

    # Final name dedupe
    reset_name_registry()

    final_names = set()
    rebuilt = []

    for entry in final_entries:

        original_name = (
            entry.get(
                "name"
            )
            or "Proxy"
        )

        name = unique_name(
            original_name
        )

        entry["name"] = name

        if name in final_names:
            continue

        final_names.add(
            name
        )

        rebuilt.append(
            entry
        )

    final_entries = rebuilt

    proxy_names = [
        p["name"]
        for p in final_entries
    ]

    # ===========================================================
    # EXACTLY ONE GROUP
    # ===========================================================

    group = {

        "name":
            GROUP_NAME,

        "type":
            "select",

        "proxies":
            ["DIRECT"]
            + proxy_names
    }

    # ===========================================================
    # DNS
    # ===========================================================

    config = {

        "mixed-port":
            7890,

        "allow-lan":
            False,

        "mode":
            "rule",

        "log-level":
            "info",

        "ipv6":
            True,

        "dns": {

            "enable":
                True,

            "ipv6":
                True,

            "enhanced-mode":
                "fake-ip",

            "nameserver": [
                "https://1.1.1.1/dns-query",
                "https://8.8.8.8/dns-query",
            ],

            "fallback": [
                "https://1.0.0.1/dns-query",
                "https://8.8.4.4/dns-query",
            ],

            "fallback-filter": {
                "geoip": False
            }
        },

        "proxies":
            final_entries,

        "proxy-groups": [
            group
        ],

        "rules": [
            f"MATCH,{GROUP_NAME}"
        ]
    }

    return config


# ===============================================================
# YAML SERIALIZATION
# ===============================================================

def serialize_yaml(
    config
):

    return yaml.safe_dump(
        config,
        allow_unicode=True,
        sort_keys=False,
        default_flow_style=False,
        width=4096
    )


# ===============================================================
# FINAL YAML RELOAD VALIDATION
# ===============================================================

def validate_serialized_yaml(
    text
):

    try:

        loaded = yaml.safe_load(
            text
        )

    except Exception as e:

        return False, (
            f"YAML parse error: {e}"
        )

    ok, reason = validate_final_config(
        loaded
    )

    if not ok:

        return False, reason

    return True, "OK"


# ===============================================================
# OUTPUT PATH
# ===============================================================

def ask_output_path():

    print()

    folder = input(
        "Enter output folder name in Download: "
    ).strip()

    if not folder:
        folder = "ClashMetaExport"

    folder = re.sub(
        r'[\\/:*?"<>|]+',
        "_",
        folder
    )

    output_dir = os.path.join(
        "/storage/emulated/0/Download",
        folder
    )

    os.makedirs(
        output_dir,
        exist_ok=True
    )

    filename = input(
        "Enter output file name without extension: "
    ).strip()

    if not filename:
        filename = (
            "mihomo_"
            + time.strftime(
                "%Y%m%d_%H%M%S"
            )
        )

    filename = re.sub(
        r'[\\/:*?"<>|]+',
        "_",
        filename
    )

    if not filename.lower().endswith(
        ".yaml"
    ):
        filename += ".yaml"

    return (
        output_dir,
        os.path.join(
            output_dir,
            filename
        )
    )


# ===============================================================
# INPUT STATISTICS
# ===============================================================

def input_statistics(
    text
):

    lines = [
        x.strip()
        for x in text.splitlines()
        if x.strip()
    ]

    protocols = Counter()

    for line in lines:

        low = line.lower()

        for prefix, name in [

            ("vless://", "vless"),
            ("vmess://", "vmess"),
            ("trojan://", "trojan"),
            ("ss://", "ss"),
            ("ssr://", "ssr"),
            ("hy://", "hysteria"),
            ("hy2://", "hysteria2"),
            ("hysteria2://", "hysteria2"),
            ("tuic://", "tuic"),
            ("wg://", "wireguard"),
            ("http://", "http"),
            ("socks5://", "socks5"),

        ]:

            if low.startswith(
                prefix
            ):

                protocols[name] += 1
                break

    return (
        len(lines),
        protocols
    )


# ===============================================================
# MAIN
# ===============================================================

def main():

    print()
    print("=" * 70)
    print(
        " AKBAR98 MIHOMO INDUSTRIAL BUILDER"
    )
    print(
        VERSION
    )
    print("=" * 70)

    # -----------------------------------------------------------
    # INPUT
    # -----------------------------------------------------------

    open_empty_input_editor()

    try:

        with open(
            INPUT_PATH,
            "r",
            encoding="utf-8"
        ) as f:

            text = f.read()

    except Exception as e:

        print(
            f"[FATAL] Cannot read input: {e}"
        )

        clear_input_file()

        return 1

    # -----------------------------------------------------------
    # IMPORTANT:
    # Clear input immediately after reading.
    # Therefore next execution starts empty even if processing
    # later fails.
    # -----------------------------------------------------------

    clear_input_file()

    if not text.strip():

        print(
            "[ERROR] Input is empty."
        )

        return 1

    line_count, protocol_counts = (
        input_statistics(
            text
        )
    )

    print()
    print(
        f"[INPUT] Non-empty lines: {line_count}"
    )

    if protocol_counts:

        print(
            "[INPUT] Detected:"
        )

        for proto, count in sorted(
            protocol_counts.items()
        ):

            print(
                f"        {proto:<12} {count}"
            )

    # -----------------------------------------------------------
    # OUTPUT
    # -----------------------------------------------------------

    output_dir, output_path = (
        ask_output_path()
    )

    # -----------------------------------------------------------
    # CACHE
    # -----------------------------------------------------------

    load_cache()

    # -----------------------------------------------------------
    # RESET NAME REGISTRY
    # -----------------------------------------------------------

    reset_name_registry()

    # -----------------------------------------------------------
    # PARSE
    # -----------------------------------------------------------

    print()
    print(
        "[1/7] Parsing..."
    )

    raw = parse_any(
        text
    )

    print(
        f"[PARSE] Raw objects: {len(raw)}"
    )

    if not raw:

        print(
            "[ERROR] Nothing could be parsed."
        )

        return 1

    # -----------------------------------------------------------
    # NORMALIZE
    # -----------------------------------------------------------

    print(
        "[2/7] Normalizing..."
    )

    normalized = []

    for proxy in raw:

        p = normalize_proxy(
            proxy
        )

        if p:

            normalized.append(
                p
            )

    print(
        f"[NORMALIZE] Valid structure: "
        f"{len(normalized)}"
    )

    # -----------------------------------------------------------
    # VALIDATE
    # -----------------------------------------------------------

    print(
        "[3/7] Validating..."
    )

    validated = [
        p
        for p in normalized
        if validate_proxy(p)
    ]

    print(
        f"[VALIDATE] Accepted: "
        f"{len(validated)}"
    )

    if not validated:

        print(
            "[ERROR] No valid proxy structures."
        )

        return 1

    # -----------------------------------------------------------
    # DEDUPLICATE
    # -----------------------------------------------------------

    print(
        "[4/7] Structural deduplication..."
    )

    unique, duplicate_count = (
        deduplicate(
            validated
        )
    )

    print(
        f"[DEDUPE] Unique: "
        f"{len(unique)}"
    )

    print(
        f"[DEDUPE] Removed: "
        f"{duplicate_count}"
    )

    # -----------------------------------------------------------
    # TEST
    # -----------------------------------------------------------

    print(
        "[5/7] Lightweight reachability..."
    )

    alive, records = run_tests(
        unique
    )

    print()
    print(
        f"[RESULT] TCP reachable: "
        f"{len(alive)} / {len(unique)}"
    )

    if not alive:

        # Save cache anyway
        save_cache()

        make_reports(
            raw,
            unique,
            alive,
            records,
            duplicate_count,
            output_dir
        )

        print(
            "[ERROR] No TCP-reachable proxies."
        )

        return 1

    # -----------------------------------------------------------
    # REPORTS
    # -----------------------------------------------------------

    print(
        "[6/7] Creating reports..."
    )

    make_reports(
        raw,
        unique,
        alive,
        records,
        duplicate_count,
        output_dir
    )

    # -----------------------------------------------------------
    # BUILD
    # -----------------------------------------------------------

    print(
        "[7/7] Building final Mihomo YAML..."
    )

    config = build_config(
        alive
    )

    # -----------------------------------------------------------
    # FINAL VALIDATION
    # -----------------------------------------------------------

    ok, reason = validate_final_config(
        config
    )

    if not ok:

        print(
            f"[FATAL] Final config invalid: {reason}"
        )

        save_cache()

        return 1

    yaml_text = serialize_yaml(
        config
    )

    ok, reason = validate_serialized_yaml(
        yaml_text
    )

    if not ok:

        print(
            f"[FATAL] YAML validation failed: {reason}"
        )

        save_cache()

        return 1

    # -----------------------------------------------------------
    # ATOMIC OUTPUT
    # -----------------------------------------------------------

    try:

        atomic_write_text(
            output_path,
            yaml_text
        )

    except Exception as e:

        print(
            f"[FATAL] Output write failed: {e}"
        )

        save_cache()

        return 1

    # -----------------------------------------------------------
    # SAVE CACHE
    # -----------------------------------------------------------

    save_cache()

    # -----------------------------------------------------------
    # FINAL
    # -----------------------------------------------------------

    print()
    print("=" * 70)
    print(
        "[SUCCESS] INDUSTRIAL YAML CREATED"
    )
    print("=" * 70)

    print(
        f"Output              : {output_path}"
    )

    print(
        f"Final proxies       : {len(config['proxies'])}"
    )

    print(
        f"Proxy groups        : {len(config['proxy-groups'])}"
    )

    print(
        f"Group               : {GROUP_NAME}"
    )

    print(
        "Group type          : select"
    )

    print(
        "Automatic switching : OFF"
    )

    print(
        "URL-Test            : OFF"
    )

    print(
        "Fallback            : OFF"
    )

    print(
        "Load-Balance        : OFF"
    )

    print(
        "HTTP test           : OFF"
    )

    print(
        "Download test       : OFF"
    )

    print(
        "Post-output ping    : OFF"
    )

    print(
        "DNS cache            : ON"
    )

    print(
        "TCP cache            : ON"
    )

    print(
        "IPv4/IPv6            : ON"
    )

    print(
        "Adaptive workers     : ON"
    )

    print(
        "Batch processing     : ON"
    )

    print(
        "Structural dedupe    : ON"
    )

    print(
        "Final YAML validate  : ON"
    )

    print(
        "Input cleared        : YES"
    )

    print("=" * 70)

    print()
    print(
        "[REPORTS]"
    )

    print(
        os.path.join(
            output_dir,
            "output_report.txt"
        )
    )

    print(
        os.path.join(
            output_dir,
            "output_failed.txt"
        )
    )

    print(
        os.path.join(
            output_dir,
            "output_duplicates.txt"
        )
    )

    print(
        os.path.join(
            output_dir,
            "output_unknown_params.txt"
        )

    )

    print()
    print(
        "[DONE]"
    )

    return 0


# ===============================================================
# ENTRY POINT
# ===============================================================

if __name__ == "__main__":

    try:

        sys.exit(
            main()
        )

    except KeyboardInterrupt:

        print()
        print(
            "[STOPPED] Interrupted by user."
        )

        clear_input_file()

        sys.exit(130)

    except Exception as e:

        print()
        print(
            "[FATAL] Unexpected error:"
        )

        print(
            repr(e)
        )

        clear_input_file()

        sys.exit(1)
